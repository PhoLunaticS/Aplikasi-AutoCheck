<footer class="bg-gray-800 text-white py-4 text-center">
        <p>© 2024 Jual Mobil. All rights reserved.</p>
</footer>