<?php
require_once 'vendor/autoload.php'; 
require_once 'vendor/firebase/php-jwt/src/JWT.php';

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

$secret_key = "27c6bb9cb5e004a1ca5a8700235b011f002f1bc8b82c968d1f6b8616bbbfe475fdaf3fc9a57e0cb1dae0c26bbb360d7ba800232a1025c02a34c2e5e2f8dccaff";

session_start();
if (!isset($_SESSION['jwt'])) {
    echo "Anda harus login terlebih dahulu.";
    exit;
}

try {
    $decoded = JWT::decode($_SESSION['jwt'], new Key($secret_key, 'HS256'));
    echo "Selamat datang, " . htmlspecialchars($decoded->data->username) . "!";
} catch (Exception $e) {
    echo "Token tidak valid.";
    exit;
}
?>
