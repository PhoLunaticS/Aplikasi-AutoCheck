<?php
ini_set('memory_limit', '1024M'); 
$uri = "mongodb+srv://PhoLunaticS:OFfAdzPnGZt6I2RL@dbpp.agns3.mongodb.net/?retryWrites=true&w=majority&appName=dbpp";
$dbname = 'test';
require __DIR__ . '/../vendor/autoload.php';

try {
    $client = new MongoDB\Client($uri);
    $database = $client->$dbname;

    $collections = [
        'inspectionnotifications',
        'inspeksi_inspektors',
        'inspeksis',
        'inspeksischemas',
        'inspektors',
        'inspektorschemas',
        'jadwal_inspektorschemas',
        'jual_mobilschemas',
        'jualmobils',
        'loginschemas',
        'lokasi_mobilschemas',
        'notifications',
    ];
} catch (Exception $e) {
    die("Database connection failed: " . $e->getMessage());
}
