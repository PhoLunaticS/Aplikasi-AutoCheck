<?php
include 'connect/config.php'; 
include 'header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Mobil</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 dark:bg-gray-900">
    <header class="bg-gray-800 text-white py-4">
        <h1 class="text-center text-2xl font-bold">Jual Mobil</h1>
    </header>
    <main>
        <section class="hero-slider bg-gray-700 py-10 text-center">
            <h2 class="text-4xl text-white font-bold mb-4">Temukan Mobil Impian Anda</h2>
            <p class="text-lg text-white">Kami menyediakan berbagai jenis mobil berkualitas dengan harga terbaik.</p>
        </section>
        <section class="cars py-10">
            <div class="container mx-auto px-4">
                <h2 class="text-3xl font-semibold mb-6 text-center text-white">Mobil Tersedia</h2>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php
                    try {
                        $collection = $database->jualmobils;
                        $filter = ['statusPenjualan' => 'Aktif']; 
                        $options = ['sort' => ['createdAt' => -1]]; 
                        $cursor = $collection->find($filter, $options);

                        $found = false;
                        foreach ($cursor as $car) {
                            $found = true;
                            $maxLength = 100;
                            $deskripsi = strlen($car['deskripsi']) > $maxLength
                                ? substr($car['deskripsi'], 0, $maxLength) . '...'
                                : $car['deskripsi'];
                            $createdAt = $car['createdAt']->toDateTime()->format('d-m-Y H:i:s');
                            $carLink = "cars/index.php?id=" . urlencode((string)$car['_id']);
                            echo "
                            <div class='bg-white shadow-md rounded-lg p-4' data-category='" . htmlspecialchars($car['merkMobil']) . "'>
                                <img src='" . htmlspecialchars($car['fotoMobil']) . "' alt='Gambar " . htmlspecialchars($car['merkMobil']) . "' class='w-full h-48 object-cover rounded-md'>
                                <h3 class='text-lg font-semibold mt-4'><a href='" . htmlspecialchars($carLink) . "' class='text-blue-500'>" . htmlspecialchars($car['merkMobil']) . " " . htmlspecialchars($car['modelMobil']) . " (" . htmlspecialchars($car['tahunMobil']) . ")</a></h3>
                                <p class='text-gray-700'>Lokasi: " . htmlspecialchars($car['lokasiMobil']) . "</p>
                                <p class='text-green-600 font-bold'>Harga: Rp " . number_format((int)$car['hargaMobil'], 0, ',', '.') . "</p>
                                <p class='text-gray-600'>" . htmlspecialchars($deskripsi) . "</p>
                                <p class='text-sm text-gray-500'>Ditambahkan pada: " . htmlspecialchars($createdAt) . "</p>
                            </div>
                            ";
                        }

                        if (!$found) {
                            echo "<p class='text-center text-gray-500'>Tidak ada mobil tersedia.</p>";
                        }
                    } catch (Exception $e) {
                        echo "<p class='text-center text-red-500'>Terjadi kesalahan saat mengambil data: " . htmlspecialchars($e->getMessage()) . "</p>";
                    }
                    ?>
                </div>
            </div>
        </section>
    </main>
</body>
</html>

<?php
include 'footer.php';
?>
