<?php
session_start();
require_once '../connect/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $collection = $database->inspektors;

    $user = $collection->findOne(['username' => $username]);

    if ($user) {

        if ($user['password'] === $password) { 
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['username'] = $user['username']; 
            $_SESSION['email'] = $user['email'];
            header('Location: index.php'); 
            exit;
        } else {
            $error = 'Password salah!';
        }
    } else {
        $error = 'Username tidak ditemukan!';
    }
}
?>
<!DOCTYPE html>
<html lang="en>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin</title>
    <script src="../javascript/script.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<script src="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<body class="bg-gray-100 dark:bg-gray-900">
    <div class="container mx-auto p-6 max-w-sm">
        <h1 class="text-2xl font-bold mb-6 text-center">Login Admin</h1>
        <?php if (isset($error)) { ?>
            <div class="text-red-500 mb-4"><?php echo $error; ?></div>
        <?php } ?>
        <form action="" method="POST" class="bg-white shadow rounded p-6">
            <div class="mb-4">
                <label for="username" class="block font-medium mb-2">Username</label>
                <input type="text" id="username" name="username" class="w-full p-2 border rounded" required>
            </div>
            <div class="mb-4">
                <label for="password" class="block font-medium mb-2">Password</label>
                <input type="password" id="password" name="password" class="w-full p-2 border rounded" required>
            </div>
            <button type="submit" class="w-full bg-blue-500 text-white p-2 rounded">Login</button>
        </form>
    </div>
</body>
</html>
