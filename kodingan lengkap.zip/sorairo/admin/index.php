<?php
session_start();

require_once '../connect/config.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$collection = $database->inspeksis;

$inspeksis = $collection->find([], [
    'sort' => ['createdAt' => -1],
]);
include 'header.php';
?>

<!DOCTYPE html>
<html lang="en" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Inspeksi - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<script src="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<body class="bg-gray-100 dark:bg-gray-900">
    <div class="container mx-auto p-6">
        <h1 class="text-2xl font-bold mb-6 text-white text-center">Data Inspeksi</h1>
        <table class="w-full bg-white shadow rounded">
            <thead>
                <tr class="bg-gray-200 text-left">
                    <th class="p-3">#</th>
                    <th class="p-3">Username</th>
                    <th class="p-3">Jasa</th>
                    <th class="p-3">Nama Mobil</th>
                    <th class="p-3">Harga Mobil</th>
                    <th class="p-3">Alamat</th>
                    <th class="p-3">Harga Jasa</th>
                    <th class="p-3">Status</th>
                    <th class="p-3">Tanggal</th>
                    <th class="p-3">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $i = 1;
                foreach ($inspeksis as $inspeksi) {
                    echo "<tr class='border-b'>";
                    echo "<td class='p-3'>{$i}</td>";
                    echo "<td class='p-3'>{$inspeksi['username']}</td>";
                    echo "<td class='p-3'>{$inspeksi['jasa']}</td>";
                    echo "<td class='p-3'>{$inspeksi['nama_mobil']}</td>";
                    echo "<td class='p-3'>Rp " . number_format($inspeksi['harga_mobil'], 0, ',', '.') . "</td>";
                    echo "<td class='p-3'>{$inspeksi['alamat']}</td>";
                    echo "<td class='p-3'>Rp " . number_format($inspeksi['harga'], 0, ',', '.') . "</td>";
                    echo "<td class='p-3'>{$inspeksi['status']}</td>";
                    echo "<td class='p-3'>" . date('Y-m-d H:i:s', $inspeksi['date']->toDateTime()->getTimestamp()) . "</td>";
                    echo "<td class='p-3'>";
                    echo "<a href='edit_inspeksi.php?id={$inspeksi['_id']}' class='text-blue-500 hover:underline'>Edit</a> | ";
                    echo "<a href='delete_inspeksi.php?id={$inspeksi['_id']}' class='text-red-500 hover:underline'>Hapus</a>";
                    echo "</td>";
                    echo "</tr>";
                    $i++;
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
