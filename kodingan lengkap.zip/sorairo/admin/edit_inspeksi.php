<?php
session_start();
require_once '../connect/config.php';
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

if (!isset($_GET['id']) || empty($_GET['id'])) {
    die('ID tidak ditemukan.');
}

$collection = $database->inspeksis;

$id = new MongoDB\BSON\ObjectId($_GET['id']);
$inspeksi = $collection->findOne(['_id' => $id]);

if (!$inspeksi) {
    die('Data inspeksi tidak ditemukan.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = htmlspecialchars($_POST['username']);
    $jasa = htmlspecialchars($_POST['jasa']);
    $nama_mobil = htmlspecialchars($_POST['nama_mobil']);
    $harga_mobil = (int) $_POST['harga_mobil'];
    $alamat = htmlspecialchars($_POST['alamat']);
    $harga = (int) $_POST['harga'];
    $status = htmlspecialchars($_POST['status']);
    $collection->updateOne(
        ['_id' => $id],
        ['$set' => [
            'username' => $username,
            'jasa' => $jasa,
            'nama_mobil' => $nama_mobil,
            'harga_mobil' => $harga_mobil,
            'alamat' => $alamat,
            'harga' => $harga,
            'status' => $status
        ]]
    );
    header('Location: index.php');
    exit;
}
include 'header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Inspeksi</title>
    <link href="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<script src="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<body class="bg-gray-100 dark:bg-gray-900">
    <div class="container mx-auto p-6 max-w-4xl">
        <h1 class="text-2xl font-bold mb-6 text-white" >Edit Inspeksi</h1>
        <form action="" method="POST" class="bg-white shadow rounded p-6">
            <div class="flex items-center mb-4">
                <label for="username" class="w-1/4 font-medium">Username</label>
                <input type="text" id="username" name="username" class="w-3/4 p-2 border rounded" value="<?php echo $inspeksi['username']; ?>" required>
            </div>
            <div class="flex items-center mb-4">
                <label for="jasa" class="w-1/4 font-medium">Jasa</label>
                <input type="text" id="jasa" name="jasa" class="w-3/4 p-2 border rounded" value="<?php echo $inspeksi['jasa']; ?>" required>
            </div>
            <div class="flex items-center mb-4">
                <label for="nama_mobil" class="w-1/4 font-medium">Nama Mobil</label>
                <input type="text" id="nama_mobil" name="nama_mobil" class="w-3/4 p-2 border rounded" value="<?php echo $inspeksi['nama_mobil']; ?>" required>
            </div>
            <div class="flex items-center mb-4">
                <label for="harga_mobil" class="w-1/4 font-medium">Harga Mobil</label>
                <input type="number" id="harga_mobil" name="harga_mobil" class="w-3/4 p-2 border rounded" value="<?php echo $inspeksi['harga_mobil']; ?>" required>
            </div>
            <div class="flex items-center mb-4">
                <label for="alamat" class="w-1/4 font-medium">Alamat</label>
                <input type="text" id="alamat" name="alamat" class="w-3/4 p-2 border rounded" value="<?php echo $inspeksi['alamat']; ?>" required>
            </div>
            <div class="flex items-center mb-4">
                <label for="harga" class="w-1/4 font-medium">Harga Jasa</label>
                <input type="number" id="harga" name="harga" class="w-3/4 p-2 border rounded" value="<?php echo $inspeksi['harga']; ?>" required>
            </div>
            <div class="flex items-center mb-4">
                <label for="status" class="w-1/4 font-medium">Status</label>
                <select id="status" name="status" class="w-3/4 p-2 border rounded" required>
                    <option value="Pending" <?php echo $inspeksi['status'] === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                    <option value="Dibatalkan" <?php echo $inspeksi['status'] === 'Dibatalkan' ? 'selected' : ''; ?>>Dibatalkan</option>
                    <option value="Selesai" <?php echo $inspeksi['status'] === 'Selesai' ? 'selected' : ''; ?>>Selesai</option>
                    <option value="Dikerjakan" <?php echo $inspeksi['status'] === 'Dikerjakan' ? 'selected' : ''; ?>>Dikerjakan</option>
                </select>
            </div>
            <div class="flex justify-end">
                <button type="submit" class="bg-blue-500 text-white px-6 py-2 rounded">Update</button>
            </div>
        </form>
    </div>
</body>
</html>

