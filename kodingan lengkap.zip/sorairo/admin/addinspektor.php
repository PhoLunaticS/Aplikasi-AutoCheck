<?php
require '../vendor/autoload.php'; 
require '../connect/config.php';


$collection = $database->inspektors;


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $telp = $_POST['telp'];
    $lokasi = $_POST['lokasi'];

    $newInspector = [
        "username" => $username,
        "email" => $email,
        "password" => password_hash($password, PASSWORD_BCRYPT),
        "telp" => $telp,
        "lokasi" => $lokasi,
        "__v" => 0
    ];

    try {
        $result = $collection->insertOne($newInspector);
        $successMessage = "Data inspektor berhasil ditambahkan dengan ID: " . $result->getInsertedId();
    } catch (Exception $e) {
        $errorMessage = "Terjadi kesalahan: " . $e->getMessage();
    }
}
include 'header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Inspektor</title>
    <link href="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<script src="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<body class="bg-gray-100 dark:bg-gray-900 ">
    <div class="container mx-auto p-6">
        <h1 class="text-2xl font-bold mb-4 text-white">Tambah Inspektor</h1>

        <?php if (!empty($successMessage)): ?>
            <div class="bg-green-100 text-green-700 p-4 rounded mb-4">
                <?php echo $successMessage; ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($errorMessage)): ?>
            <div class="bg-red-100 text-red-700 p-4 rounded mb-4">
                <?php echo $errorMessage; ?>
            </div>
        <?php endif; ?>

        <form action="" method="POST" class="bg-white p-6 rounded shadow-md">
            <div class="mb-4">
                <label for="username" class="block text-gray-700 font-medium">Username</label>
                <input type="text" name="username" id="username" class="w-full p-2 border border-gray-300 rounded" required>
            </div>

            <div class="mb-4">
                <label for="email" class="block text-gray-700 font-medium">Email</label>
                <input type="email" name="email" id="email" class="w-full p-2 border border-gray-300 rounded" required>
            </div>

            <div class="mb-4">
                <label for="password" class="block text-gray-700 font-medium">Password</label>
                <input type="password" name="password" id="password" class="w-full p-2 border border-gray-300 rounded" required>
            </div>

            <div class="mb-4">
                <label for="telp" class="block text-gray-700 font-medium">No. Telepon</label>
                <input type="text" name="telp" id="telp" class="w-full p-2 border border-gray-300 rounded" required>
            </div>

            <div class="mb-4">
                <label for="lokasi" class="block text-gray-700 font-medium">Lokasi</label>
                <input type="text" name="lokasi" id="lokasi" class="w-full p-2 border border-gray-300 rounded" required>
            </div>

            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Tambah Inspektor</button>
        </form>
    </div>
</body>
</html>
