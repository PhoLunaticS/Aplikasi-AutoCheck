<?php
session_start();
include 'header.php';
require_once '../connect/config.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$collection = $database->jualmobils;
$successMessage = '';
$errorMessage = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userEmail = htmlspecialchars($_POST['userEmail']);
    $modelMobil = htmlspecialchars($_POST['modelMobil']);
    $merkMobil = htmlspecialchars($_POST['merkMobil']);
    $tahunMobil = (int) $_POST['tahunMobil'];
    $lokasiMobil = htmlspecialchars($_POST['lokasiMobil']);
    $hargaMobil = (int) $_POST['hargaMobil'];
    $deskripsi = htmlspecialchars($_POST['deskripsi']);
    $fotoMobil = htmlspecialchars($_POST['fotoMobil']);
    $statusPenjualan = htmlspecialchars($_POST['statusPenjualan']);

    $newMobil = [
        'userEmail' => $userEmail,
        'modelMobil' => $modelMobil,
        'merkMobil' => $merkMobil,
        'tahunMobil' => $tahunMobil,
        'lokasiMobil' => $lokasiMobil,
        'hargaMobil' => $hargaMobil,
        'deskripsi' => $deskripsi,
        'fotoMobil' => $fotoMobil,
        'statusPenjualan' => $statusPenjualan,
        'createdAt' => new MongoDB\BSON\UTCDateTime(),
        'updatedAt' => new MongoDB\BSON\UTCDateTime()
    ];

    try {
        $result = $collection->insertOne($newMobil);
        if ($result->getInsertedCount() > 0) {
            $successMessage = "Mobil berhasil ditambahkan!";
        } else {
            $errorMessage = "Gagal menambahkan mobil. Coba lagi.";
        }
    } catch (Exception $e) {
        $errorMessage = "Terjadi kesalahan: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Mobil</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<script src="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<body class="bg-gray-100 dark:bg-gray-900">
    <div class="container mx-auto p-6 max-w-full">
        <h1 class="text-2xl font-bold mb-6 text-white">Tambah Mobil</h1>
    
        <?php if ($successMessage): ?>
            <div class="bg-green-100 text-green-700 p-4 rounded mb-4">
                <?php echo $successMessage; ?>
            </div>
        <?php endif; ?>

        <?php if ($errorMessage): ?>
            <div class="bg-red-100 text-red-700 p-4 rounded mb-4">
                <?php echo $errorMessage; ?>
            </div>
        <?php endif; ?>

        <form action="" method="POST" class="bg-white shadow rounded p-6 grid grid-cols-2 gap-6">
            <div class="mb-4">
                <label for="userEmail" class="block font-medium mb-2">Email Pengguna</label>
                <input type="email" id="userEmail" name="userEmail" class="w-full p-2 border rounded" required>
            </div>
            <div class="mb-4">
                <label for="modelMobil" class="block font-medium mb-2">Model Mobil</label>
                <input type="text" id="modelMobil" name="modelMobil" class="w-full p-2 border rounded" required>
            </div>
            <div class="mb-4">
                <label for="merkMobil" class="block font-medium mb-2">Merk Mobil</label>
                <input type="text" id="merkMobil" name="merkMobil" class="w-full p-2 border rounded" required>
            </div>
            <div class="mb-4">
                <label for="tahunMobil" class="block font-medium mb-2">Tahun Mobil</label>
                <input type="number" id="tahunMobil" name="tahunMobil" class="w-full p-2 border rounded" required>
            </div>
            <div class="mb-4">
                <label for="lokasiMobil" class="block font-medium mb-2">Lokasi Mobil</label>
                <input type="text" id="lokasiMobil" name="lokasiMobil" class="w-full p-2 border rounded" required>
            </div>
            <div class="mb-4">
                <label for="hargaMobil" class="block font-medium mb-2">Harga Mobil</label>
                <input type="number" id="hargaMobil" name="hargaMobil" class="w-full p-2 border rounded" required>
            </div>
            <div class="mb-4">
                <label for="deskripsi" class="block font-medium mb-2">Deskripsi</label>
                <textarea id="deskripsi" name="deskripsi" class="w-full p-2 border rounded" required style="text-transform: none;"></textarea>
            </div>

            <div class="mb-4">
                <label for="fotoMobil" class="block font-medium mb-2">URL Foto Mobil</label>
                <input type="url" id="fotoMobil" name="fotoMobil" class="w-full p-2 border rounded" required>
            </div>
            <div class="mb-4">
                <label for="statusPenjualan" class="block font-medium mb-2">Status Penjualan</label>
                <select id="statusPenjualan" name="statusPenjualan" class="w-full p-2 border rounded" required>
                    <option value="Aktif">Aktif</option>
                    <option value="Tidak Aktif">Tidak Aktif</option>
                </select>
            </div>
            <div class="col-span-2">
                <button type="submit" class="w-full bg-blue-500 text-white p-2 rounded">Tambah Mobil</button>
            </div>
        </form>
    </div>
</body>
</html>
