<?php
require_once 'connect/config.php';
require_once 'vendor/autoload.php'; 
require_once 'vendor/firebase/php-jwt/src/JWT.php';
include 'header.php'; 

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

$secret_key = "27c6bb9cb5e004a1ca5a8700235b011f002f1bc8b82c968d1f6b8616bbbfe475fdaf3fc9a57e0cb1dae0c26bbb360d7ba800232a1025c02a34c2e5e2f8dccaff";
$issuer_claim = "localhost"; 
$audience_claim = "localhost"; 
$jwt_expire = 3600; 

function validate_jwt($token, $secret_key) {
    try {
        $decoded = JWT::decode($token, new Key($secret_key, 'HS256'));
        return $decoded;
    } catch (Exception $e) {
        return null;
    }
}
function fetch_user_from_mongo($database, $username, $password) {
    $collection = $database->member;
    $filter = ['username' => $username];
    $user = $collection->findOne($filter);

    if ($user && password_verify($password, $user['password'])) {
        return $user;
    }
    return null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        echo "Username atau password tidak boleh kosong.";
        exit;
    }
    $user = fetch_user_from_mongo($database, $username, $password);

    if (!$user) {
        echo "Username atau password salah.";
        exit;
    }

    $issued_at = time();
    $expiration_time = $issued_at + $jwt_expire;

    $payload = [
        "iss" => $issuer_claim,
        "aud" => $audience_claim,
        "iat" => $issued_at,
        "exp" => $expiration_time,
        "data" => [
            "id" => (string) $user['_id'], 
            "username" => $user['username']
        ]
    ];

    $jwt = JWT::encode($payload, $secret_key, 'HS256');

    session_start();
    $_SESSION['jwt'] = $jwt;

    header("Location: member.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css">
</head>
<body class="bg-gray-50 dark:bg-gray-900">
    <section class="bg-gray-50 dark:bg-gray-900">
        <div class="flex flex-col items-center justify-center px-1 py-8 mx-12 md:h-screen lg:py-0">
            <div class="w-full bg-gray-200 rounded-lg shadow dark:border md:mt-0 sm:max-w-md xl:p-0 dark:bg-gray-800 dark:border-gray-700">
                <div class="p-6 space-y-4 md:space-y-6 sm:p-8">
                    <h1 class="text-xl font-bold leading-tight tracking-tight text-gray-900 md:text-2xl dark:text-white">
                        Sign in to your account
                    </h1>
                    <form method="POST" action="login.php">
                        <div>
                            <label for="username" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Your username</label>
                            <input type="text" name="username" id="username" class="bg-gray-50 border border-gray-300 text-gray-900 rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Your username" required>
                        </div>
                        <div>
                            <label for="password" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Password</label>
                            <input type="password" name="password" id="password" placeholder="••••••••" class="bg-gray-50 border border-gray-300 text-gray-900 rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <button type="submit" class="w-full text-white bg-primary-600 hover:bg-primary-700 focus:ring-4 focus:outline-none focus:ring-primary-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800">Sign in</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
</body>
</html>

<?php include 'footer.php'; ?>