<?php
include 'connect/config.php';
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Header Example</title>
</head>
<body class="bg-gray-50 dark:bg-gray-900">

<header>
    <nav class="bg-gray-100 border-gray-200 px-4 lg:px-6 py-3 dark:bg-gray-800">
        <div class="container flex flex-wrap justify-between items-center mx-auto">
            <!-- Logo -->
            <a href="index.php" class="flex items-center">
                <img src="asset/c__1_-removebg-preview-removebg-preview.png" class="h-10 mr-3 sm:h-12" alt="Logo" />
            </a>
            <!-- Navigation Links -->
            <div class="hidden lg:flex lg:items-center lg:space-x-8">
                <a href="index.php" class="text-gray-900 dark:text-white hover:text-primary-700 dark:hover:text-primary-500 font-medium">Home</a>
                <a href="about.php" class="text-gray-700 dark:text-gray-400 hover:text-primary-700 dark:hover:text-primary-500 font-medium">Company</a>
            </div>
            <!-- Buttons -->
            <div class="flex items-center space-x-4">
                <a href="login.php" class="text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 focus:ring-4 focus:ring-gray-300 dark:focus:ring-gray-600 font-medium rounded-lg text-sm px-4 py-2">Log in</a>
                <a href="register.php" class="text-white bg-primary-700 hover:bg-primary-800 focus:ring-4 focus:ring-primary-300 dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800 font-medium rounded-lg text-sm px-4 py-2">Get started</a>
            </div>
            <!-- Mobile Menu Button -->
            <button data-collapse-toggle="mobile-menu" type="button" class="inline-flex items-center p-2 ml-1 text-sm text-gray-500 rounded-lg lg:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600" aria-controls="mobile-menu" aria-expanded="false">
                <span class="sr-only">Open main menu</span>
                <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clip-rule="evenodd"></path></svg>
            </button>
        </div>
        <!-- Mobile Menu -->
        <div class="hidden lg:hidden" id="mobile-menu">
            <ul class="flex flex-col mt-4 space-y-2 font-medium">
                <li><a href="index.php" class="text-gray-900 dark:text-white hover:text-primary-700 dark:hover:text-primary-500">Home</a></li>
                <li><a href="about.php" class="text-gray-700 dark:text-gray-400 hover:text-primary-700 dark:hover:text-primary-500">Company</a></li>
            </ul>
        </div>
    </nav>
</header>

<script src="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</body>
</html>
