package com.example.pui2

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProvider

class menu_login_inspektor : AppCompatActivity() {
    private lateinit var viewModel: LoginInspektorViewModel
    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var loginButton: Button
    private lateinit var progressBar: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu_login_inspektor)

        initView()
        initViewModel()
        observeLoginResult()
    }


    private fun initView() {
        emailEditText = findViewById(R.id.editTextTextEmailAddress)
        passwordEditText = findViewById(R.id.editTextTextPassword)
        loginButton = findViewById(R.id.btn_Login)
        progressBar = findViewById(R.id.progressBar)

        loginButton.setOnClickListener { loginUser() }
    }

    private fun initViewModel() {
        val apiService = RetrofitClient.getInstance(this).getApiService()
        viewModel = ViewModelProvider(
            this,
            LoginInspektorViewModelFactory(applicationContext, apiService)
        )[LoginInspektorViewModel::class.java]
    }

    private fun loginUser() {
        val email = emailEditText.text.toString().trim()
        val password = passwordEditText.text.toString().trim()

        if (validateInput(email, password)) {
            viewModel.loginInspektor(email, password)
        }
    }

    private fun validateInput(email: String, password: String): Boolean {
        return when {
            email.isEmpty() -> {
                Toast.makeText(this, "Email tidak boleh kosong", Toast.LENGTH_SHORT).show()
                false
            }
            !Patterns.EMAIL_ADDRESS.matcher(email).matches() -> {
                Toast.makeText(this, "Format email tidak valid", Toast.LENGTH_SHORT).show()
                false
            }
            password.isEmpty() -> {
                Toast.makeText(this, "Password tidak boleh kosong", Toast.LENGTH_SHORT).show()
                false
            }
            password.length < 6 -> {
                Toast.makeText(this, "Password minimal 6 karakter", Toast.LENGTH_SHORT).show()
                false
            }
            else -> true
        }
    }

    private fun observeLoginResult() {
        viewModel.loginResult.observe(this) { result ->
            when (result) {
                is ApiResult.Loading -> {
                    progressBar.visibility = View.VISIBLE
                    loginButton.isEnabled = false
                }
                is ApiResult.Success -> {
                    progressBar.visibility = View.GONE

                    // Tambahkan toast login berhasil
                    Toast.makeText(this, "Login Berhasil!", Toast.LENGTH_SHORT).show()

                    saveLoginStatus(result.data.token)
                    navigateToBeranda()
                }
                is ApiResult.Error -> {
                    progressBar.visibility = View.GONE
                    loginButton.isEnabled = true
                    showErrorDialog(result.message)
                }
            }
        }
    }

    private fun saveLoginStatus(token: String) {
        getSharedPreferences("InspektorApp", Context.MODE_PRIVATE)
            .edit()
            .putBoolean("IS_LOGGED_IN", true)
            .putString("TOKEN", token)
            .apply()
    }

    private fun showErrorDialog(message: String) {
        AlertDialog.Builder(this)
            .setTitle("Login Gagal")
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun navigateToBeranda() {
        val intent = Intent(this, menu_beranda_inspektor::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}
