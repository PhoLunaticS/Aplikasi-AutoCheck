package com.example.pui2

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.HttpException
import retrofit2.Response
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.SocketTimeoutException

class menu_jual_mobil : AppCompatActivity() {
    private lateinit var btnUploadFoto: Button
    private lateinit var hargaMobilInput: EditText
    private lateinit var lokasiMobilInput: EditText
    private lateinit var buttonKirim: Button
    private lateinit var editTextModelMobil: EditText
    private lateinit var editTextMerkMobil: EditText
    private lateinit var editTextTahunMobil: EditText
    private lateinit var editTextDeskripsi: EditText

    private var selectedImageFile: File? = null

    companion object {
        private const val TAG = "JualMobilActivity"
        private const val PICK_IMAGE_REQUEST = 1
        private const val MAX_FILE_SIZE = 5 * 1024 * 1024 // 5MB
    }

    private fun logActivityLifecycle(message: String) {
        Log.d(TAG, "Lifecycle: $message")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        logActivityLifecycle("onCreate")
        setContentView(R.layout.activity_menu_jual_mobil)
        initializeViews()
    }

    private fun initializeViews() {
        // Inisialisasi view
        editTextModelMobil = findViewById(R.id.editTextmodel_mobil)
        editTextMerkMobil = findViewById(R.id.editTextmerk_mobil)
        editTextTahunMobil = findViewById(R.id.editTexttahun_mobil)
        editTextDeskripsi = findViewById(R.id.editTextDeskripsi)
        lokasiMobilInput = findViewById(R.id.editTextalamat)
        hargaMobilInput = findViewById(R.id.editTextharga_mobil)
        buttonKirim = findViewById(R.id.btnkirim_jual_mobil)
        btnUploadFoto = findViewById(R.id.btnUploadFoto)

        // Set listeners
        btnUploadFoto.setOnClickListener { openGallery() }
        buttonKirim.setOnClickListener { validateAndSubmit() }
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        intent.type = "image/*"
        startActivityForResult(Intent.createChooser(intent, "Pilih Foto"), PICK_IMAGE_REQUEST)
    }

    private fun validateAndSubmit() {
        // Ambil nilai input
        val modelMobil = editTextModelMobil.text.toString().trim()
        val merkMobil = editTextMerkMobil.text.toString().trim()
        val tahunMobil = editTextTahunMobil.text.toString().trim()
        val lokasiMobil = lokasiMobilInput.text.toString().trim()
        val hargaMobil = hargaMobilInput.text.toString().trim()
        val deskripsi = editTextDeskripsi.text.toString().trim()

        // Validasi input
        if (validateInputFields(
                modelMobil,
                merkMobil,
                tahunMobil,
                lokasiMobil,
                hargaMobil,
                deskripsi
            )
        ) {
            uploadMobilData(modelMobil, merkMobil, tahunMobil, lokasiMobil, hargaMobil, deskripsi)
        }
    }

    private fun uploadMobilData(
        modelMobil: String,
        merkMobil: String,
        tahunMobil: String,
        lokasiMobil: String,
        hargaMobil: String,
        deskripsi: String
    ) {
        // Enhanced Logging Diagnostic
        Log.d(TAG, "===== UPLOAD MOBIL DIAGNOSTIC =====")

        // Log detil input dengan validasi tambahan
        val inputDiagnostic = mapOf(
            "Model Mobil" to modelMobil,
            "Merk Mobil" to merkMobil,
            "Tahun Mobil" to tahunMobil,
            "Lokasi Mobil" to lokasiMobil,
            "Harga Mobil" to hargaMobil,
            "Deskripsi" to deskripsi
        )

        // Validasi komprehensif sebelum upload
        val validationErrors = mutableListOf<String>()

        inputDiagnostic.forEach { (key, value) ->
            Log.d(TAG, "$key: $value")
            Log.d(TAG, "$key Length: ${value.length}")

            // Contoh validasi
            if (value.isBlank()) {
                validationErrors.add("$key tidak boleh kosong")
            }
        }

        // Cek file gambar
        val compressedImageFile = selectedImageFile?.let {
            Log.d(TAG, "Image File Diagnostic:")
            Log.d(TAG, "Original File Path: ${it.absolutePath}")
            Log.d(TAG, "Original File Size: ${it.length()} bytes")

            compressImage(it).also { compressed ->
                Log.d(TAG, "Compressed File Path: ${compressed.absolutePath}")
                Log.d(TAG, "Compressed File Size: ${compressed.length()} bytes")
            }
        }

        // Tambahkan validasi file gambar
        if (compressedImageFile == null) {
            validationErrors.add("Gambar mobil harus dipilih")
        }

        // Hentikan proses jika ada error validasi
        if (validationErrors.isNotEmpty()) {
            Log.e(TAG, "Validation Errors: $validationErrors")
            validationErrors.forEach { error ->
                Toast.makeText(this@menu_jual_mobil, error, Toast.LENGTH_SHORT).show()
            }
            return
        }

        // Nonaktifkan tombol kirim untuk mencegah multi-submit
        buttonKirim.isEnabled = false

        lifecycleScope.launch {
            try {
                val response = withContext(Dispatchers.IO) {
                    val apiService = RetrofitClient.getInstance(this@menu_jual_mobil).getApiService()

                    // Enhanced error handling untuk file
                    val requestFile = compressedImageFile?.let { file ->
                        file.asRequestBody("image/jpeg".toMediaTypeOrNull())
                    } ?: run {
                        Log.e(TAG, "Critical Error: Image file is null after validation")
                        throw IllegalStateException("Gambar tidak valid")
                    }

                    // Buat MultipartBody dengan logging tambahan
                    val photoPart = MultipartBody.Part.createFormData(
                        "image",  // Pastikan sesuai dengan nama field di backend
                        compressedImageFile.name,
                        requestFile
                    )

                    // Log detil request parts
                    Log.d(TAG, "Request Parts Diagnostic:")
                    Log.d(TAG, "Photo Part Name: ${photoPart.body.contentType()}")
                    Log.d(TAG, "Photo Part Size: ${photoPart.body.contentLength()} bytes")

                    // Tambahkan timeout dan error handling
                    try {
                        val apiResponse = apiService.jualMobil(
                            modelMobil.toRequestBody("text/plain".toMediaTypeOrNull()),
                            merkMobil.toRequestBody("text/plain".toMediaTypeOrNull()),
                            tahunMobil.toRequestBody("text/plain".toMediaTypeOrNull()),
                            lokasiMobil.toRequestBody("text/plain".toMediaTypeOrNull()),
                            hargaMobil.toRequestBody("text/plain".toMediaTypeOrNull()),
                            deskripsi.toRequestBody("text/plain".toMediaTypeOrNull()),
                            photoPart
                        )

                        // Log response details
                        Log.d(TAG, "API Response Received")
                        apiResponse
                    } catch (e: Exception) {
                        Log.e(TAG, "API Call Error", e)
                        // Log detail error
                        when (e) {
                            is HttpException -> {
                                Log.e(TAG, "HTTP Error Code: ${e.code()}")
                                Log.e(TAG, "Error Body: ${e.response()?.errorBody()?.string()}")
                            }
                            is SocketTimeoutException -> {
                                Log.e(TAG, "Network Timeout")
                            }
                            is IOException -> {
                                Log.e(TAG, "Network Error: ${e.message}")
                            }
                            else -> {
                                Log.e(TAG, "Unexpected Error: ${e.message}")
                            }
                        }
                        throw e
                    }
                }

                // Proses response
                handleApiResponse(response)
            } catch (e: Exception) {
                Log.e(TAG, "Upload Process Error", e)
                handleUploadError(e)

                // Tampilkan pesan error yang lebih informatif
                val errorMessage = when (e) {
                    is IllegalStateException -> "Silakan pilih gambar terlebih dahulu"
                    is HttpException -> "Gagal mengunggah. Periksa koneksi internet"
                    else -> "Terjadi kesalahan tidak terduga"
                }
                Toast.makeText(this@menu_jual_mobil, errorMessage, Toast.LENGTH_SHORT).show()
            } finally {
                // Pastikan tombol selalu aktif kembali
                buttonKirim.isEnabled = true
            }
        }
    }

    private fun validateFileSize(file: File): Boolean {
        val fileSize = file.length()
        return fileSize <= MAX_FILE_SIZE
    }

    private fun validateInputFields(
        modelMobil: String,
        merkMobil: String,
        tahunMobil: String,
        lokasiMobil: String,
        hargaMobil: String,
        deskripsi: String
    ): Boolean {
        if (selectedImageFile == null) {
            Toast.makeText(this, "Harap pilih foto mobil", Toast.LENGTH_SHORT).show()
            return false
        }

        if (!validateFileSize(selectedImageFile!!)) {
            Toast.makeText(this, "Ukuran foto maksimal 5MB", Toast.LENGTH_SHORT).show()
            return false
        }

        if (modelMobil.isEmpty() || merkMobil.isEmpty() || tahunMobil.isEmpty() ||
            lokasiMobil.isEmpty() || hargaMobil.isEmpty() || deskripsi.isEmpty()
        ) {
            Toast.makeText(this, "Harap isi semua field", Toast.LENGTH_SHORT).show()
            return false
        }

        return true
    }

    private fun compressImage(file: File): File {
        return try {
            val originalBitmap = BitmapFactory.decodeFile(file.path)
            val resizedBitmap = if (originalBitmap.width > 1024 || originalBitmap.height > 1024) {
                val ratio = originalBitmap.width.toFloat() / originalBitmap.height.toFloat()
                val newWidth = 1024
                val newHeight = (newWidth / ratio).toInt()
                Bitmap.createScaledBitmap(originalBitmap, newWidth, newHeight, true)
            } else {
                originalBitmap
            }

            val outputStream = ByteArrayOutputStream()
            resizedBitmap.compress(Bitmap.CompressFormat.JPEG, 70, outputStream)

            val compressedFile = File(cacheDir, "compressed_${file.name}")
            compressedFile.createNewFile()
            FileOutputStream(compressedFile).use { fileOut ->
                fileOut.write(outputStream.toByteArray())
            }

            compressedFile
        } catch (e: Exception) {
            file
        }
    }

    private fun handleApiResponse(response: Response<JualMobilResponse>) {
        Log.d(TAG, "===== RESPONSE ANALYSIS =====")

        // Analisis detail response
        val responseBody = response.body()

        when {
            // Sukses berdasarkan pesan
            responseBody?.message?.contains("berhasil", ignoreCase = true) == true -> {
                Log.i(TAG, "Upload Successful (Message-based)")
                Toast.makeText(this, responseBody.message, Toast.LENGTH_SHORT).show()
                pindahKeMenuUtama()
            }

            // Sukses berdasarkan HTTP status
            response.isSuccessful -> {
                Log.i(TAG, "Upload Successful (HTTP Status)")
                Toast.makeText(this, responseBody?.message ?: "Upload berhasil", Toast.LENGTH_SHORT).show()
                pindahKeMenuUtama()
            }

            // Gagal
            else -> {
                Log.e(TAG, "Upload Failed")
                Toast.makeText(this,
                    responseBody?.message ?: "Gagal mengunggah",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun handleUploadError(e: Exception) {
        Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK) {
            data?.data?.let { uri ->
                val file = getFileFromUri(uri)
                if (file != null) {
                    selectedImageFile = file
                    btnUploadFoto.text = "Foto Terpilih"
                }
            }
        }
    }

    private fun getFileFromUri(uri: Uri): File? {
        return try {
            val inputStream = contentResolver.openInputStream(uri)
            val tempFile = File(cacheDir, "temp_image_${System.currentTimeMillis()}.jpg")
            tempFile.createNewFile()

            inputStream?.use { input ->
                tempFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            }

            tempFile
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal memilih foto", Toast.LENGTH_SHORT).show()
            null
        }
    }

    private fun pindahKeMenuUtama() {
        val intent = Intent(this, Menu_beranda::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
        finish()
    }
}