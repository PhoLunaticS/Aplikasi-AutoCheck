package com.example.pui2

import NotifikasiViewModel
import android.app.Application
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Locale

class NotifikasiAdapter(
    private val onItemClick: (Notifikasi) -> Unit
) : ListAdapter<Notifikasi, NotifikasiAdapter.BaseViewHolder>(NotifikasiDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return NotifikasiViewHolder(
            inflater.inflate(R.layout.item_notifikasi, parent, false),
            onItemClick
        )
    }

    override fun onBindViewHolder(holder: BaseViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    abstract class BaseViewHolder(
        itemView: View,
        private val onItemClick: (Notifikasi) -> Unit
    ) : RecyclerView.ViewHolder(itemView) {
        protected val tvTitle: TextView = itemView.findViewById(R.id.tvJudul)
        protected val tvDescription: TextView = itemView.findViewById(R.id.tvDeskripsi)
        protected val tvDetailMobil: TextView = itemView.findViewById(R.id.tvDetailMobil)
        protected val tvNomorPenjual: TextView = itemView.findViewById(R.id.tvNomorPenjual)
        protected val tvHargaInspeksi: TextView = itemView.findViewById(R.id.tvHargaInspeksi)
        protected val tvDate: TextView = itemView.findViewById(R.id.tvTanggal)
        protected val tvStatus: TextView = itemView.findViewById(R.id.tvStatus)

        open fun bind(notifikasi: Notifikasi) {
            // Menggunakan nama properti yang benar
            tvTitle.text = notifikasi.title
            tvDescription.text = notifikasi.description
            tvStatus.text = notifikasi.status
            tvDate.text = formatDate(notifikasi.createdAt)

            // Menampilkan detail pesanan
            val detail = notifikasi.details // Menggunakan 'details' sesuai dengan data class
            tvDetailMobil.text = "${detail.merkMobil} ${detail.namaMobil} - Rp ${detail.hargaMobil}"
            tvNomorPenjual.text = "Nomor Penjual: ${detail.nomorPenjual}"
            tvHargaInspeksi.text = "Total Pembayaran: Rp ${detail.totalPembayaran}"

            itemView.setOnClickListener { onItemClick(notifikasi) }
        }

        // Mengonversi string tanggal ke format yang diinginkan
        protected fun formatDate(dateString: String): String {
            val sdfInput = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.getDefault())
            val sdfOutput = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault())
            val date = sdfInput.parse(dateString) // Mengonversi string ke Date
            return sdfOutput.format(date) // Mengembalikan string yang diformat
        }
    }

    class NotifikasiViewHolder(
        itemView: View,
        onItemClick: (Notifikasi) -> Unit
    ) : BaseViewHolder(itemView, onItemClick) {
        // Jika Anda ingin menambahkan logika khusus untuk NotifikasiViewHolder, lakukan di sini
    }

    class NotifikasiDiffCallback : DiffUtil.ItemCallback<Notifikasi>() {
        override fun areItemsTheSame(oldItem: Notifikasi, newItem: Notifikasi): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Notifikasi, newItem: Notifikasi): Boolean {
            return oldItem == newItem
        }
    }
}

class NotifikasiViewModelFactory(
    private val application: Application,
    private val apiService: ApiService,
    private val token: String // Tambahkan parameter token
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(NotifikasiViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return NotifikasiViewModel(application, apiService, token) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}