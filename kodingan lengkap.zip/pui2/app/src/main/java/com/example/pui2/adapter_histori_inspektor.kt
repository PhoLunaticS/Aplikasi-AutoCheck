package com.example.pui2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class adapter_histori_inspektor (private val daftarHistoriInspeksi: List<histori_inspektor>) :
    RecyclerView.Adapter<adapter_histori_inspektor.ViewHolderHistoriInspeksi>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolderHistoriInspeksi {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_histori_inspektor, parent, false)
            return ViewHolderHistoriInspeksi(view)
        }

        override fun onBindViewHolder(holder: ViewHolderHistoriInspeksi, position: Int) {
            val historiInspeksi = daftarHistoriInspeksi[position]
            holder.bind(historiInspeksi)
        }

        override fun getItemCount(): Int {
            return daftarHistoriInspeksi.size
        }

        inner class ViewHolderHistoriInspeksi(itemView: View) : RecyclerView.ViewHolder(itemView) {
            private val tvTanggalInspeksi: TextView = itemView.findViewById(R.id.tv_tanggal_inspeksi)
            private val tvNomorKendaraan: TextView = itemView.findViewById(R.id.tv_nomor_kendaraan)
            private val tvHasilInspeksi: TextView = itemView.findViewById(R.id.tv_hasil_inspeksi)

            fun bind(historiInspeksi: histori_inspektor) {
                tvTanggalInspeksi.text = historiInspeksi.tanggalInspeksi
                tvNomorKendaraan.text = historiInspeksi.nomorKendaraan
                tvHasilInspeksi.text = historiInspeksi.hasilInspeksi
            }
        }
    }
