package com.example.pui2

import android.content.Intent
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class pembayaran_inspeksi : AppCompatActivity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pembayaran)

        webView = findViewById(R.id.webView)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.loadWithOverviewMode = true
        webView.settings.useWideViewPort = true

        val paymentUrl = intent.getStringExtra("payment_url") ?: ""
        if (paymentUrl.isNotEmpty()) {
            webView.webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val url = request.url.toString()

                    // Deteksi berbagai kemungkinan URL finish dari Midtrans
                    when {
                        url.contains("payment-finish") -> {
                            handlePaymentSuccess()
                            return true
                        }
                        url.contains("finish") && url.contains("puiapp.com") -> {
                            handlePaymentSuccess()
                            return true
                        }
                        url.contains("status_code=200") -> {
                            handlePaymentSuccess()
                            return true
                        }
                        url.contains("transaction_status=settlement") -> {
                            handlePaymentSuccess()
                            return true
                        }
                        url.contains("cancel") || url.contains("error") -> {
                            handlePaymentFailure()
                            return true
                        }
                    }
                    return false
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)

                    // Optional: Cek juga saat halaman selesai dimuat
                    url?.let {
                        if (it.contains("payment-finish") || it.contains("finish")) {
                            handlePaymentSuccess()
                        }
                    }
                }
            }

            webView.loadUrl(paymentUrl)
        } else {
            Toast.makeText(this, "URL pembayaran tidak valid", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun handlePaymentSuccess() {
        Toast.makeText(this, "Pembayaran berhasil!", Toast.LENGTH_SHORT).show()

        // Kembali ke MainActivity dan navigasi ke menu notifikasi
        val intent = Intent(this, Menu_beranda::class.java).apply {
            putExtra("navigate_to", "notifikasi")
            // Tambahkan flag untuk clear stack dan buat instance baru
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }

        startActivity(intent)
        finish()
    }

    private fun handlePaymentFailure() {
        Toast.makeText(this, "Pembayaran dibatalkan atau gagal", Toast.LENGTH_SHORT).show()

        // Kembali ke MainActivity tanpa navigasi khusus
        val intent = Intent(this, FragmentNotifikasi::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }

        startActivity(intent)
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            // Panggil super.onBackPressed() terlebih dahulu
            super.onBackPressed()

            // Jika user menekan back, kembali ke MainActivity
            val intent = Intent(this, FragmentNotifikasi::class.java)
            startActivity(intent)
            finish()
        }
    }
}