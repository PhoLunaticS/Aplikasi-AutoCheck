package com.example.pui2

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.concurrent.TimeoutException

class LoginInspektorViewModel(
    private val context: Context,
    private val apiService: ApiService // Dependency Injection
) : ViewModel() {
    private val _loginResult = MutableLiveData<ApiResult<LoginResponseInspektor>>()
    val loginResult: LiveData<ApiResult<LoginResponseInspektor>> = _loginResult

    private val _loginState = MutableLiveData<LoginState>()
    val loginState: LiveData<LoginState> = _loginState

    fun loginInspektor(email: String, password: String) {
        // Validasi input
        if (!isValidInput(email, password)) return

        _loginResult.value = ApiResult.Loading
        _loginState.value = LoginState.LOADING

        val loginRequest = LoginRequestInspektor(
            email = email,
            password = password
        )

        apiService.loginInspektor(loginRequest).enqueue(object : Callback<LoginResponseInspektor> {
            override fun onResponse(
                call: Call<LoginResponseInspektor>,
                response: Response<LoginResponseInspektor>
            ) {
                when {
                    response.isSuccessful -> {
                        response.body()?.let { loginResponse ->
                            saveLoginInfo(loginResponse)
                            _loginResult.value = ApiResult.Success(loginResponse)
                            _loginState.value = LoginState.SUCCESS
                        } ?: run {
                            handleError("Respons kosong")
                        }
                    }
                    else -> {
                        val errorMessage = parseError(response.errorBody())
                        handleError(errorMessage)
                    }
                }
            }

            override fun onFailure(call: Call<LoginResponseInspektor>, t: Throwable) {
                val errorMessage = when (t) {
                    is TimeoutException -> "Waktu koneksi habis"
                    else -> "Koneksi gagal: ${t.message}"
                }
                handleError(errorMessage)
            }
        })
    }

    private fun isValidInput(email: String, password: String): Boolean {
        return when {
            email.isEmpty() -> {
                handleError("Email tidak boleh kosong")
                false
            }
            !isValidEmail(email) -> {
                handleError("Format email tidak valid")
                false
            }
            password.isEmpty() -> {
                handleError("Password tidak boleh kosong")
                false
            }
            password.length < 6 -> {
                handleError("Password minimal 6 karakter")
                false
            }
            else -> true
        }
    }

    private fun isValidEmail(email: String): Boolean {
        val emailRegex = Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z|a-z]{2,}\$")
        return email.matches(emailRegex)
    }

    private fun handleError(message: String) {
        _loginResult.value = ApiResult.Error(message)
        _loginState.value = LoginState.ERROR
    }

    private fun saveLoginInfo(loginResponse: LoginResponseInspektor) {
        val prefs = context.getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE)
        prefs.edit().apply {
            putString("TOKEN", loginResponse.token)
            putString("MONGO_ID", loginResponse.user.mongoId)
            putString("USER_ID", loginResponse.user.inspektorId)
            putString("USERNAME", loginResponse.user.username)
            putString("USER_EMAIL", loginResponse.user.email)
            putString("USER_TELP", loginResponse.user.telp)
            putString("USER_LOKASI", loginResponse.user.lokasi)
            putString("LOGIN_TYPE", LoginType.INSPEKTOR.name)
            putBoolean("IS_LOGGED_IN", true)
            apply()
        }
    }

    fun logout() {
        val prefs = context.getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE)
        prefs.edit().clear().apply()
        _loginState.value = LoginState.LOGOUT
    }

    fun checkLoginStatus(): Boolean {
        val prefs = context.getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE)
        return prefs.getBoolean("IS_LOGGED_IN", false)
    }

    fun getLoggedInUserDetails(): UserInspektor? {
        val prefs = context.getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE)
        return if (checkLoginStatus()) {
            UserInspektor(
                mongoId = prefs.getString("MONGO_ID", null),
                inspektorId = prefs.getString("USER_ID", "") ?: "",
                username = prefs.getString("USERNAME", "") ?: "",
                email = prefs.getString("USER_EMAIL", "") ?: "",
                password = "", // Tidak menyimpan password
                telp = prefs.getString("USER_TELP", "") ?: "",
                lokasi = prefs.getString("USER_LOKASI", "") ?: ""
            )
        } else null
    }

    private fun parseError(errorBody: ResponseBody?): String {
        return try {
            val errorResponse = Gson().fromJson(errorBody?.string(), ErrorResponse::class.java)
            errorResponse?.message ?: "Terjadi kesalahan"
        } catch (e: Exception) {
            "Terjadi kesalahan"
        }
    }
}



// Enum untuk status login
enum class LoginState {
    LOADING,
    SUCCESS,
    ERROR,
    LOGOUT
}

// Enum untuk tipe login

// Factory dengan dependency injection
class LoginInspektorViewModelFactory(
    private val context: Context,
    private val apiService: ApiService
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(LoginInspektorViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return LoginInspektorViewModel(context, apiService) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
