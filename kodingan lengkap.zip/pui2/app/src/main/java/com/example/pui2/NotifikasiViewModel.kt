import android.app.Application
import android.content.Context
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.pui2.ApiResult
import com.example.pui2.ApiService
import com.example.pui2.NotificationsApiResponse
import com.example.pui2.Notifikasi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import retrofit2.HttpException
import java.io.IOException

class NotifikasiViewModel(
    application: Application,
    private val apiService: ApiService,
    private val token: String
) : AndroidViewModel(application) {
    private val _notifications = MutableStateFlow<ApiResult<List<Notifikasi>>>(ApiResult.Loading)
    val notifications: StateFlow<ApiResult<List<Notifikasi>>> = _notifications.asStateFlow()

    fun fetchNotifications() {
        // Ambil token dari SharedPreferences
        val token = getTokenFromSharedPreferences()

        // Validasi token
        if (token.isBlank()) {
            Log.e("NotifikasiViewModel", "Token is empty")
            _notifications.value = ApiResult.Error("Token tidak valid")
            return
        }

        viewModelScope.launch {
            _notifications.value = ApiResult.Loading

            try {
                // Log sebelum melakukan request
                Log.d("NotifikasiViewModel", "Attempting to fetch notifications")

                // Gunakan Response<NotificationsApiResponse> dan sertakan token di header
                val response = apiService.getUserNotifications("Bearer $token")

                // Log detail response
                Log.d("NotifikasiViewModel", "Response received: successful=${response.isSuccessful}, code=${response.code()}")

                // Periksa apakah response berhasil
                if (response.isSuccessful) {
                    val apiResponse = response.body()

                    // Periksa apakah body tidak null
                    if (apiResponse != null) {
                        Log.d("NotifikasiViewModel", "Response body: $apiResponse")
                        processNotificationResponse(apiResponse)
                    } else {
                        Log.e("NotifikasiViewModel", "Response body is null")
                        _notifications.value = ApiResult.Error("Respon kosong")
                    }
                } else {
                    // Log error response details
                    val errorBody = response.errorBody()?.string()
                    Log.e("NotifikasiViewModel", "Error response body: $errorBody")

                    // Tangani error HTTP
                    val errorMessage = getHttpErrorMessage(response.code())
                    Log.e("NotifikasiViewModel", "HTTP Error: $errorMessage")
                    _notifications.value = ApiResult.Error(errorMessage)
                }
            } catch (e: Exception) {
                // Log exception details
                Log.e("NotifikasiViewModel", "Exception in fetchNotifications", e)
                handleRequestError(e)
            }
        }
    }

    private fun getTokenFromSharedPreferences(): String {
        val sharedPreferences = getApplication<Application>().getSharedPreferences("MyAppPrefs", Context.MODE_PRIVATE)
        val token = sharedPreferences.getString("user_token", "")
        Log.d("NotifikasiViewModel", "Token retrieved: $token")
        return token ?: ""
    }

    private fun processNotificationResponse(response: NotificationsApiResponse) {
        Log.d("NotifikasiViewModel", "Processing notification response")

        Log.d("NotifikasiViewModel", "Response success: ${response.success}")
        Log.d("NotifikasiViewModel", "Response data size: ${response.data.size}")

        _notifications.value = when {
            response.success && response.data.isNotEmpty() -> {
                Log.d("NotifikasiViewModel", "Notifications loaded successfully")
                ApiResult.Success(response.data)
            }
            response.success && response.data.isEmpty() -> {
                Log.d("NotifikasiViewModel", "No notifications found")
                ApiResult.Error("Tidak ada notifikasi")
            }
            else -> {
                Log.d("NotifikasiViewModel", "Failed to load notifications")
                ApiResult.Error(response.message ?: "Gagal mengambil data")
            }
        }
    }

    private fun handleRequestError(e: Throwable) {
        val errorMessage = when (e) {
            is IOException -> {
                Log.e("NotifikasiViewModel", "Network connection failed", e)
                "Koneksi jaringan gagal. Periksa koneksi internet Anda."
            }
            is HttpException -> {
                val errorCode = e.code()
                Log.e("NotifikasiViewModel", "HTTP Exception: $errorCode", e)
                // Tambahkan detail error dari response body jika tersedia
                val errorBody = e.response()?.errorBody()?.string()
                Log.e("NotifikasiViewModel", "Error Body: $errorBody")

                getHttpErrorMessage(errorCode)
            }
            else -> {
                Log.e("NotifikasiViewModel", "Unknown error", e)
                "Terjadi kesalahan: ${e.message ?: "Tidak dikenal"}"
            }
        }
        _notifications.value = ApiResult.Error(errorMessage)
    }

    private fun getHttpErrorMessage(errorCode: Int): String = when (errorCode) {
        400 -> "Permintaan tidak valid"
        401 -> "Tidak terotorisasi"
        403 -> "Akses ditolak"
        404 -> "Sumber tidak ditemukan"
        500 -> "Kesalahan server internal"
        503 -> "Layanan tidak tersedia"
        else -> "Terjadi kesalahan dengan kode: $errorCode"
    }
}
