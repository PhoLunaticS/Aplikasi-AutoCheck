package com.example.pui2

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object ORSClient {
    private const val BASE_URL = "https://api.openrouteservice.org/"

    val instance: ORSService by lazy {
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        retrofit.create(ORSService::class.java)
    }
}