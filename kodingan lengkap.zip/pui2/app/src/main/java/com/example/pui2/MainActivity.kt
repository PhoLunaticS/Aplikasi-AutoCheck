package com.example.pui2

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var phoneEditText: EditText
    private lateinit var namapengguna: EditText
    private lateinit var btnClick: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        emailEditText = findViewById(R.id.editTextEmail) // Pastikan ID ini sesuai dengan layout Anda
        passwordEditText = findViewById(R.id.editTextPassword) // Pastikan ID ini sesuai dengan layout Anda
        phoneEditText = findViewById(R.id.editTextPhone)
        namapengguna = findViewById(R.id.editTextnama)

        btnClick = findViewById(R.id.btn_regist)
        btnClick.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        if (v != null && v.id == R.id.btn_regist) {
            registerUser ()
        }
    }

    private fun registerUser() {
        val username = namapengguna.text.toString()
        val email = emailEditText.text.toString()
        val password = passwordEditText.text.toString()
        val tlp = phoneEditText.text.toString()

        if (username.isEmpty() || email.isEmpty() || password.isEmpty() || tlp.isEmpty()) {
            Toast.makeText(this, "Semua field harus diisi", Toast.LENGTH_SHORT).show()
            return
        }

        val user = User_register(username, email, password, tlp)

        Log.d("User  Data", "Email: $email, Password: $password") // Log data pengguna

        val retrofit = Retrofit.Builder()
            .baseUrl("http://10.0.2.2:3000") // Make sure this matches your server address
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val apiService = retrofit.create(ApiService::class.java)

        apiService.registerUser(user).enqueue(object : Callback<Void> {
            override fun onResponse(call: Call<Void>, response: Response<Void>) {
                if (response.isSuccessful) {
                    Toast.makeText(this@MainActivity, "Registrasi berhasil", Toast.LENGTH_SHORT).show()
                    val pindahIntent = Intent(this@MainActivity, Menu_beranda::class.java)
                    startActivity(pindahIntent)
                } else {
                    val errorBody = response.errorBody()?.string()
                    Log.e("Registration", "Error: ${response.code()}, Body: $errorBody")
                    Toast.makeText(this@MainActivity, "Registrasi gagal: ${response.code()}", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<Void>, t: Throwable) {
                Log.e("Registration", "Error: ${t.message}", t)
                Toast.makeText(this@MainActivity, "Kesalahan: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}