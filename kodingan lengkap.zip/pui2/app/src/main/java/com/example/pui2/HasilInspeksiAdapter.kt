package com.example.pui2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

//class HasilInspeksiAdapter(private val hasilInspeksi: HasilInspeksi) :
////    RecyclerView.Adapter<RecyclerView.ViewHolder>() {
////
////    private val VIEW_TYPE_HEADER = 0
////    private val VIEW_TYPE_ITEM = 1
////
////    override fun getItemViewType(position: Int): Int {
////        return if (position == 0) VIEW_TYPE_HEADER else VIEW_TYPE_ITEM
////    }
////
////    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
////        return when (viewType) {
////            VIEW_TYPE_HEADER -> {
////                val view = LayoutInflater.from(parent.context)
////                    .inflate(R.layout.item_inspeksi_header, parent, false)
////                HeaderViewHolder(view)
////            }
////            else -> {
////                val view = LayoutInflater.from(parent.context)
////                    .inflate(R.layout.item_inspeksi_komponen, parent, false)
////                KomponenViewHolder(view)
////            }
////        }
////    }
////
////    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
////        when (holder) {
////            is HeaderViewHolder -> {
////                holder.bind(hasilInspeksi)
////            }
////            is KomponenViewHolder -> {
////                val komponen = hasilInspeksi.komponenInspeksi[position - 1]
////                holder.bind(komponen)
////            }
////        }
////    }
////
////    override fun getItemCount(): Int = hasilInspeksi.komponenInspeksi.size + 1
////
////    class HeaderViewHolder(view: View) : RecyclerView.ViewHolder(view) {
////        private val tvTanggal: TextView = view.findViewById(R.id.tvTanggal)
////        private val tvNomorPlat: TextView = view.findViewById(R.id.tvNomorPlat)
////        private val tvNomorRangka: TextView = view.findViewById(R.id.tvNomorRangka)
////        private val tvJarakTempuh: TextView = view.findViewById(R.id.tvJarakTempuh)
////
////        fun bind(hasilInspeksi: HasilInspeksi) {
////            tvTanggal.text = "Tanggal Inspeksi: ${hasilInspeksi.tanggalInspeksi}"
////            tvNomorPlat.text = "Nomor Plat: ${hasilInspeksi.nomorPlat}"
////            tvNomorRangka.text = "Nomor Rangka: ${hasilInspeksi.nomorRangka}"
////            tvJarakTempuh.text = "Jarak Tempuh: ${hasilInspeksi.jarakTempuh}"
////        }
////    }
////
////    class KomponenViewHolder(view: View) : RecyclerView.ViewHolder(view) {
////        private val tvNamaKomponen: TextView = view.findViewById(R.id.tvNamaKomponen)
////        private val tvKondisi: TextView = view.findViewById(R.id.tvKondisi)
////
////        fun bind(komponen: KomponenInspeksi) {
////            tvNamaKomponen.text = komponen.namaKomponen
////            tvKondisi.text = komponen.kondisi
////            tvKondisi.setTextColor(
////                if (komponen.kondisi == "Baik")
////                    ContextCompat.getColor(itemView.context, R.color.green)
////                else
////                    ContextCompat.getColor(itemView.context, R.color.red)
////            )
////        }
////    }
//}