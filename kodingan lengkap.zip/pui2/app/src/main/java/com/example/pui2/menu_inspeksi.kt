package com.example.pui2

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class menu_inspeksi : AppCompatActivity() {
    companion object {
        // Konstanta untuk intent extra
        const val HARGA_INSPEKSI = "HARGA_INSPEKSI"
        const val NAMA_MOBIL = "NAMA_MOBIL"
        const val MERK_MOBIL = "MERK_MOBIL"
        const val NOMOR_PENJUAL = "NOMOR_PENJUAL"
        const val HARGA_MOBIL = "HARGA_MOBIL"
        const val LOKASI_INSPEKSI = "LOKASI_INSPEKSI"
        const val TOTAL_BIAYA = "TOTAL_BIAYA"
        const val JASA = "JASA"
    }

    // Deklarasi view
    private lateinit var hargaMobilInput: EditText
    private lateinit var alamatPenjualInput: EditText
    private lateinit var namaMobilInput: EditText
    private lateinit var nomorPenjualInput: EditText
    private lateinit var spinnerMerk: Spinner
    private lateinit var buttonKirim: Button
    private lateinit var apiService: ApiService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu_inspeksi)

        apiService = RetrofitClient.getInstance(this).getApiService()
        // Inisialisasi view
        initializeViews()

        // Setup listener tombol
        setupButtonListener()
        setupAlamatPenjualListener()
    }
    private fun setupAlamatPenjualListener() {
        alamatPenjualInput.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                cariInspektor(alamatPenjualInput.text.toString())
            }
        }
    }

    private fun showInspektorDialog(inspektors: List<InspektorResponse>) {
        val inspektorItems = inspektors.map {
            "${it.username} (${it.lokasi})"
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Inspektor Tersedia")
            .setItems(inspektorItems) { _, which ->
                val selectedInspektor = inspektors[which]
                Toast.makeText(
                    this,
                    "Dipilih: ${selectedInspektor.username}",
                    Toast.LENGTH_SHORT
                ).show()
            }
            .setNegativeButton("Batal", null)
            .show()
    }
    private fun validasiInspektorDanLanjutkan() {
        val kota = alamatPenjualInput.text.toString().trim()

        // Ambil token dari SharedPreferences
        val sharedPreferences = getSharedPreferences("MyApp", Context.MODE_PRIVATE)
        val token = sharedPreferences.getString("TOKEN", "")

        Log.d("ValidasiInspektor", "Mencoba validasi inspektor di kota: $kota")
        Log.d("ValidasiInspektor", "Token: $token")

        if (token.isNullOrEmpty()) {
            showError("Token tidak tersedia")
            return
        }

        apiService.cariInspektor(kota, token).enqueue(object : Callback<List<InspektorResponse>> {
            override fun onResponse(
                call: Call<List<InspektorResponse>>,
                response: Response<List<InspektorResponse>>
            ) {
                // Log detail response untuk debugging
                Log.d("ValidasiInspektor", "Response Code: ${response.code()}")
                Log.d("ValidasiInspektor", "Response Headers: ${response.headers()}")

                // Coba ambil error body jika ada
                val errorBody = response.errorBody()?.string()
                Log.d("ValidasiInspektor", "Error Body: $errorBody")

                when {
                    response.isSuccessful && response.body() != null -> {
                        val inspektors = response.body()!!

                        // Log detail inspektor
                        inspektors.forEachIndexed { index, inspektor ->
                            Log.d("ValidasiInspektor", "Inspektor $index: ${inspektor.username}, Lokasi: ${inspektor.lokasi}")
                        }

                        if (inspektors.isNotEmpty()) {
                            // Inspektor tersedia, lanjutkan ke proses selanjutnya
                            Log.d("ValidasiInspektor", "Inspektor ditemukan di kota: $kota")

                            // Tampilkan dialog konfirmasi
                            AlertDialog.Builder(this@menu_inspeksi)
                                .setTitle("Inspektor Tersedia")
                                .setMessage("Inspektor tersedia di kota $kota. Lanjutkan proses?")
                                .setPositiveButton("Ya") { _, _ ->
                                    // Lanjutkan ke proses perhitungan dan navigasi
                                    calculateAndProceedInspeksi()
                                }
                                .setNegativeButton("Batal", null)
                                .show()
                        } else {
                            // Tidak ada inspektor di kota tersebut
                            showInspektorTidakTersedia(kota)
                        }
                    }
                    response.code() == 404 -> {
                        // Kota tidak ditemukan
                        Log.d("ValidasiInspektor", "Tidak ada inspektor di kota: $kota")
                        showInspektorTidakTersedia(kota)
                    }
                    else -> {
                        // Gagal mencari inspektor
                        Log.e("ValidasiInspektor", "Gagal mencari inspektor. Kode: ${response.code()}")
                        showError("Gagal mencari inspektor. Silakan coba lagi.")
                    }
                }
            }

            override fun onFailure(call: Call<List<InspektorResponse>>, t: Throwable) {
                // Koneksi gagal
                Log.e("ValidasiInspektor", "Error koneksi", t)
                showError("Gagal terhubung: ${t.message}")
            }
        })
    }

    private fun cariInspektor(kota: String) {
        if (kota.isEmpty()) return

        // Ambil token dari SharedPreferences
        val sharedPreferences = getSharedPreferences("MyApp", Context.MODE_PRIVATE)
        val token = sharedPreferences.getString("TOKEN", "")

        if (token.isNullOrEmpty()) {
            showError("Token tidak tersedia")
            return
        }

        Log.d("CariInspektor", "Mencari inspektor di kota: $kota")

        apiService.cariInspektor(kota, token).enqueue(object : Callback<List<InspektorResponse>> {
            override fun onResponse(
                call: Call<List<InspektorResponse>>,
                response: Response<List<InspektorResponse>>
            ) {
                Log.d("CariInspektor", "Response Code: ${response.code()}")
                Log.d("CariInspektor", "Response Body: ${response.body()}")

                when {
                    response.isSuccessful && response.body() != null -> {
                        val inspektors = response.body()!!

                        // Log detail inspektor
                        inspektors.forEachIndexed { index, inspektor ->
                            Log.d("CariInspektor", "Inspektor $index: ${inspektor.username}, Lokasi: ${inspektor.lokasi}")
                        }

                        if (inspektors.isNotEmpty()) {
                            // Tampilkan dialog atau toast dengan daftar inspektor
                            showInspektorDialog(inspektors)
                        } else {
                            Toast.makeText(
                                this@menu_inspeksi,
                                "Tidak ada inspektor di kota ini",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                    response.code() == 404 -> {
                        Toast.makeText(
                            this@menu_inspeksi,
                            "Tidak ada inspektor di kota ini",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    else -> {
                        Toast.makeText(
                            this@menu_inspeksi,
                            "Gagal mencari inspektor",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }

            override fun onFailure(call: Call<List<InspektorResponse>>, t: Throwable) {
                Toast.makeText(
                    this@menu_inspeksi,
                    "Error: ${t.message}",
                    Toast.LENGTH_SHORT
                ).show()
                Log.e("CariInspektor", "Error", t)
            }
        })
    }
    private fun showInspektorTidakTersedia(kota: String) {
        AlertDialog.Builder(this)
            .setTitle("Inspektor Tidak Tersedia")
            .setMessage("Maaf, tidak ada inspektor tersedia di kota $kota. Silakan pilih kota lain.")
            .setPositiveButton("OK") { _, _ ->
                alamatPenjualInput.requestFocus()
            }
            .setCancelable(false)
            .show()
    }

    private fun initializeViews() {
        hargaMobilInput = findViewById(R.id.harga_mobil)
        alamatPenjualInput = findViewById(R.id.alamat_penjual)
        namaMobilInput = findViewById(R.id.nama_mobil)
        nomorPenjualInput = findViewById(R.id.editTextnomerpenjual)
        spinnerMerk = findViewById(R.id.spinner_merk)
        buttonKirim = findViewById(R.id.btn_kirim)
    }

    private fun setupButtonListener() {
        buttonKirim.setOnClickListener {
            if (validateInputs()) {
                validasiInspektorDanLanjutkan()
            }
        }
    }

    private fun validateInputs(): Boolean {
        val inputs = listOf(
            alamatPenjualInput to "Alamat penjual",
            hargaMobilInput to "Harga mobil",
            namaMobilInput to "Nama mobil",
            nomorPenjualInput to "Nomor penjual"
        )

        for ((input, errorMessage) in inputs) {
            if (input.text.toString().trim().isEmpty()) {
                showError("$errorMessage harus diisi!")
                return false
            }
        }

        return true
    }

    private fun calculateAndProceedInspeksi() {
        val hargaMobil = try {
            hargaMobilInput.text.toString().toDouble()
        } catch (e: NumberFormatException) {
            showError("Masukkan harga mobil yang valid!")
            return
        }

        // Calculate inspection cost based on car price
        val biayaInspeksi = when {
            hargaMobil < 200_000_000.0 -> 300_000.0
            hargaMobil <= 300_000_000.0 -> 300_000.0
            hargaMobil <= 400_000_000.0 -> 600_000.0
            hargaMobil <= 500_000_000.0 -> 800_000.0
            else -> 1_000_000.0
        }

        val jasa = "Inspeksi"
        val totalBiaya = biayaInspeksi

        // Navigate to transaction page
        navigateToTransaksi(biayaInspeksi, totalBiaya, jasa)
    }

    private fun navigateToTransaksi(biayaInspeksi: Double, totalBiaya: Double, jasa: String) {
        Intent(this, menu_transaksi::class.java).apply {
            // Tambahkan data yang diperlukan untuk transaksi
            putExtra(menu_transaksi.MENU_TYPE, menu_transaksi.TYPE_INSPEKSI)
            putExtra(HARGA_INSPEKSI, biayaInspeksi)
            putExtra(LOKASI_INSPEKSI , alamatPenjualInput.text.toString())
            putExtra(NAMA_MOBIL, namaMobilInput.text.toString())
            putExtra(MERK_MOBIL, spinnerMerk.selectedItem.toString())
            putExtra(NOMOR_PENJUAL, nomorPenjualInput.text.toString())
            putExtra(HARGA_MOBIL, hargaMobilInput.text.toString().toDouble())
            putExtra(TOTAL_BIAYA, totalBiaya)
            putExtra(JASA, jasa)

            // Mulai activity
            startActivity(this)
        }
    }

    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}