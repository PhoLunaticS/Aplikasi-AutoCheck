package com.example.pui2

import android.view.SurfaceControl
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Headers
import retrofit2.http.Multipart
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Part
import retrofit2.http.Path
import retrofit2.http.Query
import retrofit2.http.QueryMap

interface ApiService {
    @POST("/login")
    suspend fun loginUser(@Body user: User_login): Response<LoginResponse>
    @POST("/register")
    fun registerUser (@Body user: User_register): Call<Void>
    @POST("/kirim-inspeksi")
    fun kirimisnpeksi(
        @Header("Authorization") token: String,
        @Body hasilinspeksi: hasilinspeksi
    ): Call<Void>

    @POST("transaksi/inspeksi")
    suspend fun saveTransaction(
        @Header("Authorization") token: String,
        @Body transaksiRequest: TransaksiRequest
    ): Response<TransaksiResponse>

    @POST("/notifications")
    suspend fun createNotification(@Body notificationRequest: NotifikasiRequest): Response<BaseResponse>

    @POST("/transaksi/save")
    suspend fun saveTransaksiInspeksi(@Body transaksi: TransaksiInspeksi): Response<BaseResponse>

    @GET("/transaksi/{id}")
    suspend fun getTransaksi(@Path("id") id: String): TransaksiResponse

    @GET("/transaksi")
    suspend fun getSemuaTransaksi(): List<TransaksiResponse>
    @GET("/user")
    suspend fun getUserData(): Response<UserDataResponse>
    @GET("/profile")
    suspend fun getProfile(
        @Header("Authorization") token: String
    ): Response<ProfileResponse>
    @PUT("profile")
    suspend fun updateProfile(
        @Header("Authorization") token: String,
        @Body updateData: UpdateProfileRequest
    ): Response<UpdateProfileResponse>
    @GET("cari_inspektor")
    fun cariInspektor(
        @Query("kota") kota: String,
        @Query("Authorization") token: String
    ): Call<List<InspektorResponse>>

    @GET("/mobil")
    fun getMobilList(): Call<List<Mobil>>

    @GET("/mobil/{id}")
    fun getMobilById(@Path("id") id: Int): Call<Mobil>

    @Multipart
    @POST("jual-mobil")
    suspend fun jualMobil(
        @Part("modelMobil") modelMobil: RequestBody,
        @Part("merkMobil") merkMobil: RequestBody,
        @Part("tahunMobil") tahunMobil: RequestBody,
        @Part("lokasiMobil") lokasiMobil: RequestBody,
        @Part("hargaMobil") hargaMobil: RequestBody,
        @Part("deskripsi") deskripsi: RequestBody,
        @Part image: MultipartBody.Part
    ): Response<JualMobilResponse>
    @GET("/jual-mobil/history")
    fun getJualMobilHistory(@Header("Authorization") token: String): Call<JualMobilHistoryResponse>

    @Headers("Accept: application/json")
    @POST("/titip-beli/save")
    fun saveTransaction(@Body request: TitipBeliRequest): Call<TitipBeliResponse>

    @POST("/titip-beli/update-status")
    fun updateTransactionStatus(@Body request: TransactionStatusUpdate): Call<TitipBeliResponse>

    @POST("login-inspektor")
    fun loginInspektor(
        @Body loginRequest: LoginRequestInspektor
    ): Call<LoginResponseInspektor>

    @GET("notifikasi/user")
    suspend fun getUserNotifications(
        @Header("authorization") token: String
    ): Response<NotificationsApiResponse>

    @GET("jual-mobil/user")
    fun getMobilList(
        @Header("Authorization") token: String
    ): Call<MobilResponse>
    @GET("inspeksi")
    fun getAllTransaksi(): Call<List<Pesananinspektor>>
    @GET("pencarian-mobil")
    fun getAllPencarianMobil(): Call<List<PencarianMobil>>
    @GET("riwayat-pesanan")
    suspend fun getRiwayatPesanan(
        @Query("page") page: Int = 1,
        @Query("limit") limit: Int = 10
    ): Response<PesananResponse>
    @GET("pencarian-mobil/useremail")
    suspend fun getPencarianMobil(
        @Query("email") email: String
    ): Response<PencarianMobilResponse>
    @GET("inspeksi/detail")
    suspend fun getInspeksiDetail(
        @Query("email") email: String,
        @Query("created_at") createdAt: String,
        @Query("nama_mobil") namaMobil: String
    ): Response<InspeksiResponse>

    @POST("titip-beli/save")
    suspend fun createPayment(@Body request: PaymentRequest): Response<PaymentResponse>

    @GET("payment-status/{orderId}")
    fun checkPaymentStatus(@Path("orderId") orderId: String): Call<PaymentStatusResponse>
}







data class InsektorResponse(val message: String)

interface TokenProvider {
    suspend fun getToken(): String
}
