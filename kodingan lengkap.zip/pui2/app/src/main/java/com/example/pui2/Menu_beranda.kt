package com.example.pui2

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

interface NotificationNavigator {
    fun navigateToOrderDetails(orderId: String)
    fun navigateToOrderTracking(orderId: String)
}

class Menu_beranda : AppCompatActivity(), NotificationNavigator {

    private lateinit var bottomNavigationView: BottomNavigationView

    // Simpan fragment dalam variabel untuk mengontrol state
    private val fragmentBeranda by lazy { Fragment_beranda.newInstance("test1", "test2") }
    private val fragmentProfile by lazy { Fragment_profile.newInstance() }
    private val fragmentRiwayat by lazy { Fragment_riwayat.newInstance() }
    private val fragmentNotifikasi by lazy { FragmentNotifikasi.newInstance() }

    // Untuk menyimpan fragment yang aktif
    private var activeFragment: Fragment = fragmentBeranda

    // Implementasi method dari interface NotificationNavigator
    override fun navigateToOrderDetails(orderId: String) {
        // Implementasi navigasi ke detail pesanan
        val fragment = OrderDetailsFragment().apply {
            arguments = Bundle().apply {
                putString("orderId", orderId)
            }
        }
        supportFragmentManager.beginTransaction()
            .replace(R.id.bodi, fragment)
            .addToBackStack(null)
            .commit()
    }

    override fun navigateToOrderTracking(orderId: String) {
        // Implementasi navigasi ke tracking pesanan
        val fragment = OrderTrackingFragment().apply {
            arguments = Bundle().apply {
                putString("orderId", orderId)
            }
        }
        supportFragmentManager.beginTransaction()
            .replace(R.id.bodi, fragment)
            .addToBackStack(null)
            .commit()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.menu_beranda)
        Log.d("Menu_beranda", "onCreate called")

        if (savedInstanceState == null) {
            setupBottomNavigation()
            initializeFragments()
        } else {
            // Restore the active fragment if activity is recreated
            activeFragment = supportFragmentManager.fragments.find { it.isVisible } ?: fragmentBeranda
        }

        // Handle navigation from payment
        handleNavigationFromIntent()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleNavigationFromIntent()
    }

    private fun handleNavigationFromIntent() {
        val navigateTo = intent.getStringExtra("navigate_to")

        when (navigateTo) {
            "notifikasi" -> {
                navigateToNotifikasi()
                // Hapus parameter setelah digunakan agar tidak terus dijalankan
                intent.removeExtra("navigate_to")
            }
        }
    }

    private fun navigateToNotifikasi() {
        try {
            // Switch ke fragment notifikasi
            switchFragment(fragmentNotifikasi)

            // Update bottom navigation
            bottomNavigationView.selectedItemId = R.id.it_notifikasi

            // Tampilkan pesan sukses
            Toast.makeText(this, "Transaksi berhasil! Cek notifikasi untuk detail.", Toast.LENGTH_LONG).show()

            Log.d("Menu_beranda", "Navigated to notification fragment after payment")
        } catch (e: Exception) {
            Log.e("Menu_beranda", "Error navigating to notification: ${e.message}")
            Toast.makeText(this, "Transaksi berhasil!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupBottomNavigation() {
        bottomNavigationView = findViewById(R.id.bottomNavigationView)
        bottomNavigationView.setOnItemSelectedListener { item ->
            Log.d("Menu_beranda", "Navigation item selected: ${item.title}")
            when (item.itemId) {
                R.id.it_home -> switchFragment(fragmentBeranda)
                R.id.it_profile -> switchFragment(fragmentProfile)
                R.id.it_riwayat -> switchFragment(fragmentRiwayat)
                R.id.it_notifikasi -> switchFragment(fragmentNotifikasi)
                else -> false
            }
            true
        }

        // Set item default yang aktif
        bottomNavigationView.post {
            bottomNavigationView.selectedItemId = R.id.it_home
        }
    }

    private fun initializeFragments() {
        try {
            Log.d("Menu_beranda", "Initializing fragments")
            supportFragmentManager.beginTransaction().apply {
                add(R.id.bodi, fragmentNotifikasi).hide(fragmentNotifikasi)
                add(R.id.bodi, fragmentRiwayat).hide(fragmentRiwayat)
                add(R.id.bodi, fragmentProfile).hide(fragmentProfile)
                add(R.id.bodi, fragmentBeranda)
            }.commit()
        } catch (e: Exception) {
            Log.e("Menu_beranda", "Error initializing fragments: ${e.message}")
        }
    }

    private fun switchFragment(fragment: Fragment): Boolean {
        try {
            Log.d("Menu_beranda", "Switching to fragment: ${fragment.javaClass.simpleName}")
            supportFragmentManager.beginTransaction().apply {
                hide(activeFragment)
                show(fragment)
            }.commit()
            activeFragment = fragment
            return true
        } catch (e: Exception) {
            Log.e("Menu_beranda", "Error switching fragments: ${e.message}")
            return false
        }
    }

    override fun onResume() {
        super.onResume()
        Log.d("Menu_beranda", "onResume called")
    }
}