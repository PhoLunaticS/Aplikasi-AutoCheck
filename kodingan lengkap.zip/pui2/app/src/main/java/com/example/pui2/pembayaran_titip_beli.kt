package com.example.pui2

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.webkit.*
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class pembayaran_titip_beli : AppCompatActivity() {

    companion object {
        private const val TAG = "PaymentWebView"
        private const val PAYMENT_TIMEOUT = 300000L // 5 menit timeout
    }

    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private lateinit var toolbar: Toolbar
    private lateinit var apiService: ApiService

    private var paymentToken: String = ""
    private var orderId: String = ""
    private var isPaymentCompleted = false
    private var timeoutHandler: Handler? = null
    private var timeoutRunnable: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pembayaran_titip_beli)

        try {
            initializeViews()
            initializeApiService()
            setupToolbar()
            setupWebView()

            paymentToken = intent.getStringExtra("PAYMENT_TOKEN") ?: ""
            orderId = intent.getStringExtra("ORDER_ID") ?: ""

            Log.d(TAG, "Token diterima: ${paymentToken.take(20)}...")
            Log.d(TAG, "Order ID: $orderId")

            if (paymentToken.isNotEmpty()) {
                startPaymentTimeout()
                loadPaymentPage()
            } else {
                Log.e(TAG, "Token pembayaran kosong")
                showError("Token pembayaran tidak valid")
                finishWithResult("failed")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error dalam onCreate", e)
            showError("Gagal memuat halaman pembayaran")
            finishWithResult("failed")
        }
    }

    private fun initializeViews() {
        webView = findViewById(R.id.webViewPayment)
        progressBar = findViewById(R.id.progressBarPayment)
        toolbar = findViewById(R.id.toolbarPayment)
    }

    private fun initializeApiService() {
        apiService = RetrofitClient.getInstance(this).getApiService()
    }

    private fun setupToolbar() {
        setSupportActionBar(toolbar)
        supportActionBar?.apply {
            setDisplayHomeAsUpEnabled(true)
            setDisplayShowHomeEnabled(true)
            title = "Pembayaran"
        }

        toolbar.setNavigationOnClickListener {
            onBackPressed()
        }
    }

    private fun setupWebView() {
        try {
            webView.settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                loadWithOverviewMode = true
                useWideViewPort = true
                builtInZoomControls = false
                displayZoomControls = false
                setSupportZoom(false)
                cacheMode = WebSettings.LOAD_DEFAULT
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

                // Tambahan setting untuk kompatibilitas
                allowContentAccess = true
                allowFileAccess = true
                javaScriptCanOpenWindowsAutomatically = true
                setSupportMultipleWindows(true)

                // User agent untuk mobile
                val userAgent = "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Mobile Safari/537.36"
                userAgentString = userAgent
            }

            webView.webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    super.onPageStarted(view, url, favicon)
                    progressBar.visibility = View.VISIBLE
                    Log.d(TAG, "Halaman mulai dimuat: $url")
                    checkUrlForCompletion(url)
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    progressBar.visibility = View.GONE
                    Log.d(TAG, "Halaman selesai dimuat: $url")
                    checkUrlForCompletion(url)
                }

                override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                    super.onReceivedError(view, request, error)
                    Log.e(TAG, "WebView error: ${error?.description} pada ${request?.url}")

                    // Jika error pada halaman utama, coba reload
                    if (request?.isForMainFrame == true && !isPaymentCompleted) {
                        Handler(Looper.getMainLooper()).postDelayed({
                            if (!isPaymentCompleted) {
                                Log.d(TAG, "Mencoba reload halaman pembayaran")
                                loadPaymentPage()
                            }
                        }, 2000)
                    }
                }

                override fun onReceivedHttpError(view: WebView?, request: WebResourceRequest?, errorResponse: WebResourceResponse?) {
                    super.onReceivedHttpError(view, request, errorResponse)
                    Log.e(TAG, "HTTP Error: ${errorResponse?.statusCode} pada ${request?.url}")
                }

                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val url = request?.url?.toString()
                    Log.d(TAG, "Navigasi ke URL: $url")

                    // Izinkan navigasi dalam domain Midtrans
                    if (url?.contains("midtrans.com") == true ||
                        url?.contains("veritrans.co.id") == true ||
                        url?.contains("sandbox") == true) {
                        return false // Biarkan WebView menangani
                    }

                    checkUrlForCompletion(url)
                    return false
                }
            }

            webView.webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    super.onProgressChanged(view, newProgress)
                    progressBar.progress = newProgress

                    if (newProgress == 100) {
                        progressBar.visibility = View.GONE
                    }
                }

                override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                    Log.d(TAG, "Console: ${consoleMessage?.message()}")
                    return super.onConsoleMessage(consoleMessage)
                }
            }

        } catch (e: Exception) {
            Log.e(TAG, "Error setting up WebView", e)
            showError("Gagal menyiapkan halaman pembayaran")
            finishWithResult("failed")
        }
    }

    private fun checkUrlForCompletion(url: String?) {
        if (url == null || isPaymentCompleted) return

        Log.d(TAG, "Memeriksa URL: $url")

        when {
            // URL sukses dari Midtrans
            url.contains("transaction_status=settlement", ignoreCase = true) ||
                    url.contains("status=success", ignoreCase = true) ||
                    url.contains("payment_success", ignoreCase = true) ||
                    url.contains("status_code=200", ignoreCase = true) ||
                    url.contains("finish", ignoreCase = true) -> {
                Log.d(TAG, "Pembayaran sukses terdeteksi dari URL")
                handlePaymentSuccess()
            }

            // URL gagal dari Midtrans
            url.contains("transaction_status=cancel", ignoreCase = true) ||
                    url.contains("transaction_status=deny", ignoreCase = true) ||
                    url.contains("transaction_status=expire", ignoreCase = true) ||
                    url.contains("status=failed", ignoreCase = true) ||
                    url.contains("payment_failed", ignoreCase = true) ||
                    url.contains("error", ignoreCase = true) -> {
                Log.d(TAG, "Pembayaran gagal terdeteksi dari URL")
                handlePaymentFailed()
            }

            // URL pending
            url.contains("transaction_status=pending", ignoreCase = true) ||
                    url.contains("status=pending", ignoreCase = true) -> {
                Log.d(TAG, "Pembayaran pending terdeteksi dari URL")
                handlePaymentPending()
            }
        }
    }

    private fun handlePaymentSuccess() {
        if (isPaymentCompleted) return
        isPaymentCompleted = true
        stopTimeout()

        runOnUiThread {
            Toast.makeText(this, "Pembayaran berhasil!", Toast.LENGTH_SHORT).show()
            finishWithResult("success")
        }
    }

    private fun handlePaymentFailed() {
        if (isPaymentCompleted) return
        isPaymentCompleted = true
        stopTimeout()

        runOnUiThread {
            Toast.makeText(this, "Pembayaran gagal atau dibatalkan", Toast.LENGTH_SHORT).show()
            finishWithResult("failed")
        }
    }

    private fun handlePaymentPending() {
        if (isPaymentCompleted) return
        isPaymentCompleted = true
        stopTimeout()

        runOnUiThread {
            Toast.makeText(this, "Pembayaran sedang diproses", Toast.LENGTH_SHORT).show()
            finishWithResult("pending")
        }
    }

    private fun startPaymentTimeout() {
        timeoutHandler = Handler(Looper.getMainLooper())
        timeoutRunnable = Runnable {
            if (!isPaymentCompleted) {
                Log.d(TAG, "Payment timeout reached")
                showError("Waktu pembayaran habis")
                finishWithResult("timeout")
            }
        }
        timeoutHandler?.postDelayed(timeoutRunnable!!, PAYMENT_TIMEOUT)
    }

    private fun stopTimeout() {
        timeoutRunnable?.let { runnable ->
            timeoutHandler?.removeCallbacks(runnable)
        }
        timeoutHandler = null
        timeoutRunnable = null
    }

    private fun loadPaymentPage() {
        try {
            // Gunakan URL yang benar untuk Sandbox Midtrans
            val paymentUrl = "https://app.sandbox.midtrans.com/snap/v4/redirection/$paymentToken"
            Log.d(TAG, "Memuat URL pembayaran: $paymentUrl")

            // Tambahkan headers jika diperlukan
            val headers = mapOf(
                "Accept" to "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Accept-Language" to "id-ID,id;q=0.9,en;q=0.8"
            )

            webView.loadUrl(paymentUrl, headers)

        } catch (e: Exception) {
            Log.e(TAG, "Error loading payment page", e)
            showError("Gagal memuat halaman pembayaran")
            finishWithResult("failed")
        }
    }

    private fun checkPaymentStatusViaAPI() {
        if (orderId.isEmpty() || isPaymentCompleted) return

        CoroutineScope(Dispatchers.Main).launch {
            try {
                apiService.checkPaymentStatus(orderId).enqueue(object : Callback<PaymentStatusResponse> {
                    override fun onResponse(call: Call<PaymentStatusResponse>, response: Response<PaymentStatusResponse>) {
                        if (response.isSuccessful && !isPaymentCompleted) {
                            val status = response.body()?.status?.lowercase()
                            Log.d(TAG, "Status pembayaran dari API: $status")

                            when (status) {
                                "settlement", "capture", "success" -> handlePaymentSuccess()
                                "pending" -> handlePaymentPending()
                                "cancel", "deny", "expire", "failure", "failed" -> handlePaymentFailed()
                            }
                        }
                    }

                    override fun onFailure(call: Call<PaymentStatusResponse>, t: Throwable) {
                        Log.e(TAG, "Gagal cek status pembayaran via API", t)
                    }
                })
            } catch (e: Exception) {
                Log.e(TAG, "Error checking payment status", e)
            }
        }
    }

    private fun finishWithResult(status: String) {
        Log.d(TAG, "Menyelesaikan activity dengan status: $status")
        val resultIntent = Intent().apply {
            putExtra("PAYMENT_STATUS", status)
            putExtra("ORDER_ID", orderId)
        }
        setResult(Activity.RESULT_OK, resultIntent)
        finish()
    }

    private fun showError(message: String) {
        runOnUiThread {
            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack() && !isPaymentCompleted) {
            webView.goBack()
        } else {
            // Jika user menekan back, anggap sebagai pembatalan
            if (!isPaymentCompleted) {
                finishWithResult("cancel")
            } else {
                super.onBackPressed()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        stopTimeout()
        try {
            webView.destroy()
        } catch (e: Exception) {
            Log.e(TAG, "Error destroying WebView", e)
        }
    }
}