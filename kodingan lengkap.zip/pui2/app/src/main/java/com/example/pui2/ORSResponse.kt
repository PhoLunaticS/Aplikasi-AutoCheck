package com.example.pui2

data class ORSResponse(
    val routes: List<Route>
)

data class Route(
    val summary: Summary
)

data class Summary(
    val distance: Double, // distance in meters
    val duration: Double  // duration in seconds
)
