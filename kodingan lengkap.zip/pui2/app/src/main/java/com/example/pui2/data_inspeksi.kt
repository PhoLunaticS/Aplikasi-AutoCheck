package com.example.pui2

data class datainspeksi(
    val date: String,
    val truckNumber: String,
    val vin: String,
    val mileage: String,
    val engineOil: String,
    val headlamps: String,
    val taillights: String,
    val brakeLights: String,
    val turnSignals: String,
    val horn: String,
    val windshieldWipers: String,
    val mirrors: String,
    val tires: String,
    val airFilter: String,
    val beltsAndHoses: String,
    val battery: String,
    val suspension: String,
    val steering: String,
    val exhaustSystem: String,
    val frameAndBody: String,
    val other: String
)
