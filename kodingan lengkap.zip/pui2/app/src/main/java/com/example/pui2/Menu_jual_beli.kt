package com.example.pui2

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.net.ConnectivityManager
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.google.android.material.button.MaterialButton
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.request.target.Target

class Menu_jual_beli : AppCompatActivity() {

    companion object {
        private const val TAG = "Menu_jual_beli_LOG"
    }

    private lateinit var swipeRefreshLayout: SwipeRefreshLayout
    private lateinit var emptyStateTextView: TextView
    private lateinit var mobilContainerLayout: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_menu_jual_beli)

        // Atur insets
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Inisialisasi View
        initializeViews()

        // Setup tombol untuk jual mobil
        setupJualMobilButton()

        // Setup refresh layout
        setupRefreshLayout()

        // Debug token dan panggil API
        debugTokenAndApiCall()

        // Ambil daftar mobil
        getMobilList()
    }

    private fun initializeViews() {
        // Inisialisasi komponen UI
        swipeRefreshLayout = findViewById(R.id.swipe_refresh_layout)
        emptyStateTextView = findViewById(R.id.empty_state_text)
        mobilContainerLayout = findViewById(R.id.mobil_container_layout)
    }

    private fun setupJualMobilButton() {
        val btnJualMobil: MaterialButton = findViewById(R.id.btn_jual_mobil)
        btnJualMobil.setOnClickListener {
            startActivity(Intent(this, menu_jual_mobil::class.java))
        }
    }

    private fun setupRefreshLayout() {
        swipeRefreshLayout.setOnRefreshListener {
            getMobilList()
        }
    }

    private fun debugTokenAndApiCall() {
        val token = getTokenFromSharedPreferences()

        if (token.isBlank()) {
            Log.e(TAG, "ERROR: Token is null or empty!")
            return
        }

        val apiService = RetrofitClient.getInstance(this).getApiService()
        apiService.getMobilList("Bearer $token").enqueue(object : Callback<MobilResponse> {
            override fun onResponse(call: Call<MobilResponse>, response: Response<MobilResponse>) {
                logApiResponse(response)
            }

            override fun onFailure(call: Call<MobilResponse>, t: Throwable) {
                Log.e(TAG, "Network Failure:", t)
            }
        })
    }

    private fun logApiResponse(response: Response<MobilResponse>) {
        Log.e(TAG, "API Response:")
        Log.e(TAG, "- Response Code: ${response.code()}")
        Log.e(TAG, "- Response Success: ${response.isSuccessful}")

        if (!response.isSuccessful) {
            val errorBody = response.errorBody()?.string()
            Log.e(TAG, "Error Body: $errorBody")
        }
    }

    private fun getMobilList() {
        // Periksa koneksi internet
        if (!isNetworkAvailable()) {
            showNetworkError()
            return
        }

        val token = getTokenFromSharedPreferences()

        if (token.isEmpty()) {
            showLoginPrompt()
            return
        }

        // Panggil API
        val apiService = RetrofitClient.getInstance(this).getApiService()
        apiService.getMobilList("Bearer $token").enqueue(object : Callback<MobilResponse> {
            override fun onResponse(call: Call<MobilResponse>, response: Response<MobilResponse>) {
                swipeRefreshLayout.isRefreshing = false

                if (response.isSuccessful) {
                    handleSuccessfulResponse(response.body())
                } else {
                    handleErrorResponse(response)
                }
            }

            override fun onFailure(call: Call<MobilResponse>, t: Throwable) {
                handleNetworkFailure(t)
            }
        })
    }

    private fun handleSuccessfulResponse(mobilResponse: MobilResponse?) {
        try {
            if (mobilResponse != null && mobilResponse.success) {
                Log.d(TAG, "Jumlah Mobil: ${mobilResponse.data.size}")

                if (mobilResponse.data.isNotEmpty()) {
                    displayMobil(mobilResponse.data)
                } else {
                    showEmptyState()
                }
            } else {
                Log.e(TAG, "Gagal mendapatkan data mobil: ${mobilResponse?.message}")
                Toast.makeText(this, "Gagal mendapatkan data mobil", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error processing mobil response", e)
            Toast.makeText(this, "Terjadi kesalahan", Toast.LENGTH_SHORT).show()
        }
    }

    private fun displayMobil(mobilList: List<Mobil>) {
        // Bersihkan layout sebelumnya
        mobilContainerLayout.removeAllViews()

        // Sembunyikan empty state
        emptyStateTextView.visibility = View.GONE

        // Tambahkan CardView untuk setiap mobil
        mobilList.forEach { mobil ->
            val cardView = createMobilCardView(mobil)
            mobilContainerLayout.addView(cardView)
        }
    }

    private fun createMobilCardView(mobil: Mobil): CardView {
        val cardView = CardView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = resources.getDimensionPixelSize(R.dimen.card_margin)
            }
            cardElevation = 4f
            radius = resources.getDimensionPixelSize(R.dimen.card_corner_radius).toFloat()
        }

        val linearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(
                resources.getDimensionPixelSize(R.dimen.card_padding),
                resources.getDimensionPixelSize(R.dimen.card_padding),
                resources.getDimensionPixelSize(R.dimen.card_padding),
                resources.getDimensionPixelSize(R.dimen.card_padding)
            )
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val imageView = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                resources.getDimensionPixelSize(R.dimen.image_width),
                resources.getDimensionPixelSize(R.dimen.image_height)
            ).apply {
                marginEnd = resources.getDimensionPixelSize(R.dimen.image_margin)
            }
            scaleType = ImageView.ScaleType.CENTER_CROP
        }

        // Gunakan langsung URL dari ImgBB
        loadImage(mobil.fotoMobil, imageView)

        val textView = TextView(this).apply {
            text = "${mobil.merkMobil} ${mobil.modelMobil}"
            setTextColor(Color .BLACK)
            textSize = 18f
            setTypeface(null, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        linearLayout.addView(imageView)
        linearLayout.addView(textView)
        cardView.addView(linearLayout)

        cardView.setOnClickListener {
            showMobilDetails(mobil)
        }

        return cardView
    }

    private fun loadImage(imageUrl: String?, imageView: ImageView) {
        // Pastikan URL benar-benar valid
        val cleanUrl = cleanImageUrl(imageUrl)

        Log.d(TAG, "Original URL: $imageUrl")
        Log.d(TAG, "Cleaned URL: $cleanUrl")

        if (!cleanUrl.isNullOrEmpty()) {
            Glide.with(this)
                .load(cleanUrl)
                .placeholder(R.drawable.placeholder_image)
                .error(R.drawable.error_image)
                .into(imageView)
        } else {
            imageView.setImageResource(R.drawable.placeholder_image)
        }
    }

    private fun cleanImageUrl(originalUrl: String?): String? {
        if (originalUrl.isNullOrEmpty()) return null

        // Hapus prefix "/uploads/mobil/" jika ada
        var cleanUrl = originalUrl.replace("/uploads/mobil/", "")

        // Pastikan URL adalah URL lengkap
        if (!cleanUrl.startsWith("http")) {
            // Jika menggunakan ImgBB, gunakan URL lengkap
            if (cleanUrl.contains("i.ibb.co")) {
                cleanUrl = "https://$cleanUrl"
            }
        }

        return cleanUrl
    }

    private fun loadImageFromNetwork(fileName: String?, imageView: ImageView) {
        if (!fileName.isNullOrEmpty()) {
            val imageUrl = "http://10.0.2.2:3000/uploads/mobil/$fileName"
            Glide.with(this)
                .load(imageUrl)
                .placeholder(R.drawable.placeholder_image)
                .error(R.drawable.error_image)
                .into(imageView)
        } else {
            imageView.setImageResource(R.drawable.placeholder_image)
        }
    }

    private fun showMobilDetails(mobil: Mobil) {
        val intent = Intent(this, activity_detail_mobil::class.java)
        intent.putExtra("MOBIL", mobil)
        startActivity(intent)
    }

    private fun showEmptyState() {
        emptyStateTextView.visibility = View.VISIBLE
        emptyStateTextView.text = "Anda belum menjual mobil apapun"
    }

    private fun handleApiError(response: Response<MobilResponse>) {
        val errorMessage = when (response.code()) {
            401 -> "Sesi login habis. Silakan login ulang"
            403 -> "Anda tidak memiliki akses"
            404 -> "Data tidak ditemukan"
            500 -> "Kesalahan server"
            else -> "Gagal mendapatkan data mobil"
        }
        Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show()
    }

    private fun handleErrorResponse(response: Response<MobilResponse>) {
        try {
            val errorBody = response.errorBody()?.string()
            Log.e(TAG, "Error Body: $errorBody")
        } catch (e: Exception) {
            Log.e(TAG, "Gagal membaca error body", e)
        }
        handleApiError(response)
    }

    private fun handleNetworkFailure(t: Throwable) {
        Toast.makeText(this, "Error: ${t.message}", Toast.LENGTH_SHORT).show()
    }

    private fun showNetworkError() {
        Toast.makeText(this, "Tidak ada koneksi internet", Toast.LENGTH_SHORT).show()
        swipeRefreshLayout.isRefreshing = false
    }

    private fun showLoginPrompt() {
        Toast.makeText(this, "Silakan login ulang", Toast.LENGTH_SHORT).show()
        swipeRefreshLayout.isRefreshing = false
    }

    private fun isNetworkAvailable(): Boolean {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetworkInfo = connectivityManager.activeNetworkInfo
        return activeNetworkInfo != null && activeNetworkInfo.isConnected
    }

    private fun getTokenFromSharedPreferences(): String {
        val sharedPreferences = getSharedPreferences("MyApp", Context.MODE_PRIVATE)
        return sharedPreferences.getString("TOKEN", "") ?: ""
    }

}