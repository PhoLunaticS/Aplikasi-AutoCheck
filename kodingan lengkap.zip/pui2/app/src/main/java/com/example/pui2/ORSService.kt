package com.example.pui2

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface ORSService {
    @GET("v2/directions/driving-car")
    fun getDistance(
        @Query("api_key") apiKey: String,
        @Query("start") start: String,
        @Query("end") end: String
    ): Call<ORSResponse>
}