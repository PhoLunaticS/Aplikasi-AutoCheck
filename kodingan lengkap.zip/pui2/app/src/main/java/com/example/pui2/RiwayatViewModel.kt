package com.example.pui2

import android.app.Application import androidx.lifecycle.AndroidViewModel import androidx.lifecycle.LiveData import androidx.lifecycle.MutableLiveData import androidx.lifecycle.viewModelScope import kotlinx.coroutines.launch

class RiwayatViewModel(application: Application) : AndroidViewModel(application) {
    private val _riwayatPesanan = MutableLiveData<Result<PesananResponse>>()
    val riwayatPesanan: LiveData<Result<PesananResponse>> = _riwayatPesanan
    private val _totalPages = MutableLiveData<Int>(1)
    val totalPages: Int get() = _totalPages.value ?: 1

    private val apiService = RetrofitClient.getInstance(application.applicationContext).getApiService()

    fun getRiwayatPesanan(page: Int) {
        viewModelScope.launch {
            _riwayatPesanan.value = Result.Loading
            try {
                val response = apiService.getRiwayatPesanan(page)
                if (response.isSuccessful) {
                    response.body()?.let { responseBody ->
                        // Update total pages dari response
                        _totalPages.value = responseBody.pagination.totalPages
                        _riwayatPesanan.value = Result.Success(responseBody)
                    }
                } else {
                    _riwayatPesanan.value = Result.Error("Gagal memuat data")
                }
            } catch (e: Exception) {
                _riwayatPesanan.value = Result.Error(e.message ?: "Terjadi kesalahan")
            }
        }
    }
}

sealed class Result<out T> { data class Success<out T>(val data: T) : Result<T>() data class Error(val error: String) : Result<Nothing>() object Loading : Result<Nothing>() }