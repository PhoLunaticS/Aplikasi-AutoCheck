package com.example.pui2

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import android.content.SharedPreferences
import com.google.gson.Gson
import okhttp3.OkHttpClient

class activity_menu_inspeksi_inspektor : AppCompatActivity() {
    private lateinit var editTextDate: EditText
    private lateinit var editTextTruckNumber: EditText
    private lateinit var editTextVIN: EditText
    private lateinit var editTextMileage: EditText
    private lateinit var sharedPreferences: SharedPreferences

    // Deklarasi radio groups
    private lateinit var radioGroupEngineOil: RadioGroup
    private lateinit var radioGroupHeadlamps: RadioGroup
    private lateinit var radioGroupTaillights: RadioGroup
    private lateinit var radioGroupBrakeLights: RadioGroup
    private lateinit var radioGroupTurnSignals: RadioGroup
    private lateinit var radioGroupHorn: RadioGroup
    private lateinit var radioGroupWindshieldWipers: RadioGroup
    private lateinit var radioGroupMirrors: RadioGroup
    private lateinit var radioGroupTires: RadioGroup
    private lateinit var radioGroupAirFilter: RadioGroup
    private lateinit var radioGroupBeltsAndHoses: RadioGroup
    private lateinit var radioGroupBattery: RadioGroup
    private lateinit var radioGroupSuspension: RadioGroup
    private lateinit var radioGroupSteering: RadioGroup
    private lateinit var radioGroupExhaustSystem: RadioGroup
    private lateinit var radioGroupFrameAndBody: RadioGroup
    private lateinit var radioGroupOther: RadioGroup

    private lateinit var apiService: ApiService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_menu_inspeksi_inspektor)

        // Inisialisasi window insets
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        // Ubah ke "InspektorApp"
        sharedPreferences = getSharedPreferences("InspektorApp", Context.MODE_PRIVATE)

        // Inisialisasi view
        initializeViews()
// Log semua SharedPreferences untuk debugging
        val allPrefs = sharedPreferences.all
        Log.d("InspeksiActivity", "Semua SharedPreferences: $allPrefs")

        // Ubah ke "TOKEN"
        val authToken = sharedPreferences.getString("TOKEN", "") ?: ""
        Log.d("InspeksiActivity", "Token dari SharedPreferences: $authToken")

        val client = OkHttpClient.Builder()
            .addInterceptor { chain ->
                val originalRequest = chain.request()
                val requestWithToken = originalRequest.newBuilder()
                    .header("Authorization", "Bearer $authToken")
                    .build()
                chain.proceed(requestWithToken)
            }
            .build()

        val retrofit = Retrofit.Builder()
            .baseUrl("http://10.0.2.2:3000")
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        apiService = retrofit.create(ApiService::class.java)

        // Set tanggal dari intent
        val tanggalDariJadwal = intent.getStringExtra("TANGGAL")
        tanggalDariJadwal?.let {
            editTextDate.setText(it)
            editTextDate.isEnabled = false
        }

        // Set listener untuk tombol submit
        findViewById<Button>(R.id.btnSubmit).setOnClickListener {
            kirim_data_inspeksi()
        }
    }

    private fun initializeViews() {
        // Inisialisasi EditText
        editTextDate = findViewById(R.id.editTextDate)
        editTextTruckNumber = findViewById(R.id.editTextTruckNumber)
        editTextVIN = findViewById(R.id.editTextVIN)
        editTextMileage = findViewById(R.id.editTextMileage)

        // Inisialisasi Radio Groups
        radioGroupEngineOil = findViewById(R.id.radioGroupEngineOil)
        radioGroupHeadlamps = findViewById(R.id.radioGroupHeadlamps)
        radioGroupTaillights = findViewById(R.id.radioGroupTaillights)
        radioGroupBrakeLights = findViewById(R.id.radioGroupBrakeLights)
        radioGroupTurnSignals = findViewById(R.id.radioGroupTurnSignals)
        radioGroupHorn = findViewById(R.id.radioGroupHorn)
        radioGroupWindshieldWipers = findViewById(R.id.radioGroupWindshieldWipers)
        radioGroupMirrors = findViewById(R.id.radioGroupMirrors)
        radioGroupTires = findViewById(R.id.radioGroupTires)
        radioGroupAirFilter = findViewById(R.id.radioGroupAir_Filter)
        radioGroupBeltsAndHoses = findViewById(R.id.radioGroupBelts_and_Hoses)
        radioGroupBattery = findViewById(R.id.radioGroupBattery)
        radioGroupSuspension = findViewById(R.id.radioGroupSuspension)
        radioGroupSteering = findViewById(R.id.radioGroupSteering)
        radioGroupExhaustSystem = findViewById(R.id.radioGroupExhaust)
        radioGroupFrameAndBody = findViewById(R.id.radioGroupFrame_And_Body)
        radioGroupOther = findViewById(R.id.radioGroupOther)
    }

    private fun kirim_data_inspeksi() {
        try {
            val date = editTextDate.text.toString().trim()
            val truckNumber = editTextTruckNumber.text.toString().trim()
            val vin = editTextVIN.text.toString().trim()
            val mileage = editTextMileage.text.toString().trim()

            fun getRadioButtonValue(radioGroup: RadioGroup, fieldName: String): String {
                val selectedId = radioGroup.checkedRadioButtonId
                return if (selectedId != -1) {
                    findViewById<RadioButton>(selectedId).text.toString()
                } else {
                    Toast.makeText(this, "Pilih opsi untuk $fieldName", Toast.LENGTH_SHORT).show()
                    throw IllegalStateException("Tidak ada pilihan untuk $fieldName")
                }
            }

            if (date.isEmpty() || truckNumber.isEmpty() || vin.isEmpty() || mileage.isEmpty()) {
                Toast.makeText(this, "Harap isi semua field", Toast.LENGTH_SHORT).show()
                return
            }

            val komponenInspeksi = KomponenInspeksi(
                oli = getRadioButtonValue(radioGroupEngineOil, "Engine Oil"),
                lampu_depan = getRadioButtonValue(radioGroupHeadlamps, "Headlamps"),
                lampu_belakang = getRadioButtonValue(radioGroupTaillights, "Taillights"),
                lampu_rem = getRadioButtonValue(radioGroupBrakeLights, "Brake Lights"),
                lampu_sein = getRadioButtonValue(radioGroupTurnSignals, "Turn Signals"),
                klakson = getRadioButtonValue(radioGroupHorn, "Horn"),
                wiper = getRadioButtonValue(radioGroupWindshieldWipers, "Windshield Wipers"),
                kaca_spion = getRadioButtonValue(radioGroupMirrors, "Mirrors"),
                ban = getRadioButtonValue(radioGroupTires, "Tires"),
                filter_udara = getRadioButtonValue(radioGroupAirFilter, "Air Filter"),
                sabuk_dan_selang = getRadioButtonValue(radioGroupBeltsAndHoses, "Belts and Hoses"),
                baterai = getRadioButtonValue(radioGroupBattery, "Battery"),
                suspensi = getRadioButtonValue(radioGroupSuspension, "Suspension"),
                kemudi = getRadioButtonValue(radioGroupSteering, "Steering"),
                sistem_knalpot = getRadioButtonValue(radioGroupExhaustSystem, "Exhaust System"),
                rangka_dan_bodi = getRadioButtonValue(radioGroupFrameAndBody, "Frame and Body"),
                lainnya = getRadioButtonValue(radioGroupOther, "Other")
            )

            val hasilinspeksi = hasilinspeksi(
                tanggal = date,
                nomorKendaraan = truckNumber,
                nomorVIN = vin,
                kilometer = mileage,
                komponenInspeksi = komponenInspeksi
            )

            // Dapatkan token dari SharedPreferences
            val authToken = getSharedPreferences("InspektorApp", Context.MODE_PRIVATE)
                .getString("TOKEN", "") ?: ""

            Log.d("InspeksiActivity", "Token yang akan dikirim: $authToken")
            // Kirim dengan token
            apiService.kirimisnpeksi("Bearer $authToken", hasilinspeksi)
                .enqueue(object : Callback<Void> {
                    override fun onResponse(call: Call<Void>, response: Response<Void>) {
                        Log.d("InspeksiActivity", "Response code: ${response.code()}")

                        val errorBody = response.errorBody()?.string()
                        Log.e("InspeksiActivity", "Error body: $errorBody")

                        when (response.code()) {
                            201 -> {
                                Toast.makeText(
                                    this@activity_menu_inspeksi_inspektor,
                                    "Data berhasil dikirim",
                                    Toast.LENGTH_SHORT
                                ).show()
                                finish()
                            }

                            400 -> {
                                val errorMessage = try {
                                    val errorResponse = Gson().fromJson(
                                        errorBody,
                                        ErrorResponse::class.java
                                    )
                                    errorResponse.message ?: "Data tidak valid"
                                } catch (e: Exception) {
                                    "Data tidak valid"
                                }

                                Toast.makeText(
                                    this@activity_menu_inspeksi_inspektor,
                                    errorMessage,
                                    Toast.LENGTH_LONG
                                ).show()
                            }

                            401 -> {
                                Toast.makeText(
                                    this@activity_menu_inspeksi_inspektor,
                                    "Sesi telah berakhir. Silakan login ulang.",
                                    Toast.LENGTH_SHORT
                                ).show()

                                // Hapus token
                                getSharedPreferences("InspektorApp", Context.MODE_PRIVATE)
                                    .edit()
                                    .remove("TOKEN")
                                    .apply()
                            }

                            else -> {
                                Toast.makeText(
                                    this@activity_menu_inspeksi_inspektor,
                                    "Gagal mengirim data: ${response.code()}",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    }

                    override fun onFailure(call: Call<Void>, t: Throwable) {
                        Toast.makeText(
                            this@activity_menu_inspeksi_inspektor,
                            "Gagal mengirim data: ${t.message}",
                            Toast.LENGTH_SHORT
                        ).show()
                        Log.e("InspeksiActivity", "Network error", t)
                    }
                })

        } catch (e: Exception) {
            Log.e("InspeksiActivity", "Error dalam proses kirim data", e)
        }
    }
}