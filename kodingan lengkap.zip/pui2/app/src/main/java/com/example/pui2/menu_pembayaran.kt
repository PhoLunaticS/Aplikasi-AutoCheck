package com.example.pui2

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class menu_pembayaran : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_menu_pembayaran)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
            val tvInvoiceNumber: TextView = findViewById(R.id.tvInvoiceNumber)
            val tvTanggalTransaksi: TextView = findViewById(R.id.tvTanggalTransaksi)
            val tvJumlahBayar: TextView = findViewById(R.id.tvJumlahBayar)
            val tvStatusPembayaran: TextView = findViewById(R.id.tvStatusPembayaran)
            val btnKonfirmasiPembayaran: Button = findViewById(R.id.btnKonfirmasiPembayaran)

            // Data Transaksi
            val invoiceNumber = "INV-12345"
            val tanggalTransaksi = "03 Oktober 2024"
            val jumlahBayar = "Rp 500.000"
            var statusPembayaran = "Belum Dibayar"

            // Set Text View
            tvInvoiceNumber.text = "Invoice No: $invoiceNumber"
            tvTanggalTransaksi.text = "Tanggal: $tanggalTransaksi"
            tvJumlahBayar.text = "Jumlah Bayar: $jumlahBayar"
            tvStatusPembayaran.text = "Status: $statusPembayaran"

            // Tombol Konfirmasi Pembayaran
            btnKonfirmasiPembayaran.setOnClickListener {
                // Ubah status pembayaran
                statusPembayaran = "Sudah Dibayar"
                tvStatusPembayaran.text = "Status: $statusPembayaran"
                tvStatusPembayaran.setTextColor(getColor(R.color.green)) // Mengubah warna status jadi hijau
                Toast.makeText(this, "Pembayaran berhasil dikonfirmasi!", Toast.LENGTH_LONG).show()
            }
        }
    }
