package com.example.pui2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ProgressTimelineAdapter(private val progressList: List<ProgressItem>) :
    RecyclerView.Adapter<ProgressTimelineAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_progress_timeline, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = progressList[position]
        holder.apply {
            tvStatus.text = item.status
            tvDeskripsi.text = item.deskripsi
            tvTimestamp.text = formatDate(item.timestamp)
        }
    }

    override fun getItemCount() = progressList.size

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvStatus: TextView = view.findViewById(R.id.tvStatus)
        val tvDeskripsi: TextView = view.findViewById(R.id.tvDeskripsi)
        val tvTimestamp: TextView = view.findViewById(R.id.tvTimestamp)
    }

    private fun formatDate(timestamp: Long): String {
        val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }
}