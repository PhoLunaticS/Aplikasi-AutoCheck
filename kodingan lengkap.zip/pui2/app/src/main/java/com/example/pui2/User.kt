package com.example.pui2
import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import java.io.Serializable
import java.util.Date
import kotlinx.parcelize.Parcelize
import okhttp3.Address

data class User_login(
    val email: String,
    val password: String
)
data class User_register(
    val username: String,
    val email: String,
    val password: String,
    val tlp: String
)
data class TransactionStatus(
    val transactionId: String,
    val status: String
)

data class LoginResponse(
    val message: String,
    val user: UserData,
    val token: String,
    val loginType: LoginType? = null,
    val success: Boolean = true
)

data class UserDetails(
    val email: String,
    val username: String,
    val tlp: String
)
data class NominatimResponse(
    val lat: String,
    val lon: String,
    val display_name: String
)
data class InspectionHistory(
    val id: String,
    val carName: String,
    val date: String,
    val status: String
)

data class ProsesNotifikasi(
    val id: String,
    val inspectionId: String,
    val status: String,
    val createdAt: String,
    val updatedAt: String
)
data class Transaction(
    val id: String,
    val status: String,
    val inspectionResult: String?
)

data class StatusPesanan(
    val pesan: String,
    val waktu: String
)
data class Pesanan(
    val id: String = "",
    val jenisLayanan: String = "",
    val tanggalPesan: Long = 0L,
    val status: String = "",
    val detailProgress: List<ProgressItem> = emptyList(),
    val nomorKendaraan: String = "",
    val jenisKendaraan: String = "",
    val pemilik: String = "",
    val tanggal: String = "",
    val lokasi: String = ""
)

data class ProgressItem(
    val timestamp: Long,
    val status: String,
    val deskripsi: String
)

data class hasilinspeksi(
    val tanggal: String,
    val nomorKendaraan: String,
    val nomorVIN: String,
    val kilometer: String,
    val komponenInspeksi: KomponenInspeksi
)

data class KomponenInspeksi(
    val oli: String,
    val lampu_depan: String,
    val lampu_belakang: String,
    val lampu_rem: String,
    val lampu_sein: String,
    val klakson: String,
    val wiper: String,
    val kaca_spion: String,
    val ban: String,
    val filter_udara: String,
    val sabuk_dan_selang: String,
    val baterai: String,
    val suspensi: String,
    val kemudi: String,
    val sistem_knalpot: String,
    val rangka_dan_bodi: String,
    val lainnya: String
)
data class InspectionNotification(
    val id: String = "",
    val title: String = "",
    val description: String = "",
    val timestamp: Long = 0L,
    val status: String = "",
    val type: String = "",
    val detailPesanan: DetailPesananInspection? = null
)
data class DetailPesananInspection(
    val orderId: String?,
    val totalPembayaran: Double?,
    val metodePembayaran: String?
)
data class Notifikasi(
    val id: String,
    val userId: String,
    val type: String,
    val title: String,
    val description: String,
    val details: DetailPesanan,
    val status: String,
    val createdAt: String,
    val updatedAt: String
)
data class DetailInspeksi(
    val lokasiInspeksi: String,
    val namaMobil: String,
    val merkMobil: String,
    val nomorPenjual: String,
    val hargaInspeksi: Double
)
data class TransaksiInspeksi(
    @SerializedName("nama_mobil") val namaMobil: String,
    @SerializedName("merk_mobil") val merkMobil: String,
    @SerializedName("harga_mobil") val hargaMobil: Double,
    @SerializedName("jasa") val jasa: String,
    @SerializedName("alamat") val alamat: String,
    @SerializedName("nomor_penjual") val nomorPenjual: String,
    @SerializedName("total_biaya") val totalBiaya: Double
)
data class NotifikasiRequest(
    val judul: String,
    val deskripsi: String,
    val tipeNotifikasi: String,
    val detailPesanan: DetailPesananRequest?
)
data class DetailPesananRequest(
    val orderId: String,
    val totalPembayaran: Double,
    val metodePembayaran: String
)
// Enum untuk tipe notifikasi
enum class TipeNotifikasi {
    PEMBAYARAN_BERHASIL,
    PESANAN_DIPROSES
}
data class TransaksiResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("message") val message: String? = null,
    val data: TransaksiData
)
data class NotificationsApiResponse(
    val success: Boolean,
    val total: Int = 0,  // Tambahkan default value jika perlu
    val data: List<Notifikasi> = emptyList(),
    val message: String? = null  // Opsional, untuk pesan error
)
data class DetailProduk(
    val idProduk: String,
    val namaProduk: String,
    val hargaSatuan: Double,
    val jumlah: Int,
    val gambarUrl: String? = null
)

data class DetailPembayaran(
    val nomorPembayaran: String,
    val metodePembayaran: String,
    val status: String,
    val waktuPembayaran: Long,
    val totalBayar: Double
)
data class inspeksiRequest(
    val username: String,
    val email: String,
    val nama_mobil: String,
    val harga_mobil: Double,
    val alamat: String,
    val jasa: String = "Inspeksi Standar",
    val harga: Double,
    val status: String = "pending",
    val merk_mobil: String,
    val nomor_penjual: String
)
data class BaseResponse(
    val success: Boolean,
    val message: String,
    val data: Any? = null
)


// Model untuk detail pesanan
data class DetailPesanan(
    val orderId: String,
    val namaMobil: String,
    val merkMobil: String,
    val totalPembayaran: Int,
    val hargaMobil: Long,
    val status: String,
    val metodePembayaran: String,
    val alamat: String,
    val nomorPenjual: String
)
data class NotifikasiResponse(
    val _id: String,
    val userId: String,
    val type: String,
    val title: String,
    val description: String,
    val status: String,
    val createdAt: String,
    val updatedAt: String,
    val detailPesanan: DetailPesananResponse?,
    val detailInspeksi: DetailInspeksiResponse?,
    val hasilInspeksi: HasilInspeksiResponse?
)
data class DetailInspeksiResponse(
    // sesuaikan dengan response API
    // contoh:
    val inspectionId: String,
    val tanggalInspeksi: String,
    val lokasi: String
    // ... properti lainnya
)

data class HasilInspeksiResponse(
    // sesuaikan dengan response API
    // contoh:
    val status: String,
    val keterangan: String,
    val rekomendasi: String
    // ... properti lainnya
)
data class DetailPesananResponse(
    val orderId: String,
    val totalPembayaran: Double,
    val metodePembayaran: String
)
data class UserDataResponse(
    val username: String,
    val email: String
)
data class UserData(
    val id: Int,
    val email: String,
    val username: String,
    val tlp: String? = null,
    val nama: String? = null
)
data class Transaksi(
    val namaMobil: String,
    val merkMobil: String,
    val hargaInspeksi: Double,
    val nomorPenjual: String,
    val lokasiInspeksi: String,
    val totalHarga: Double
    // parameter lainnya
)
data class ProfileResponse(
    val id: String,
    val name: String,
    val email: String,
    val phoneNumber: String?,
    val address: String?,
    val success: Boolean,
    val message: String,
    val data: ProfileData
)
data class ProfileData(
    val username: String,
    val email: String,
    val tlp: String?
)
data class ProfileUpdateRequest(
    val name: String?,
    val phoneNumber: String?,
    val address: String?
)
data class NotificationResponse(
    val _id: String,
    val userId: String,
    val type: String,
    val title: String,
    val description: String,
    val detailPesanan: DetailPesananResponse?,
    val status: String,
    val createdAt: String,
    val updatedAt: String
)
// Data class untuk request
data class JualMobilRequest(
    val lokasiMobil: String,
    val hargaMobil: Double
)

// Data class untuk response
data class JualMobilResponse(
    val success: Boolean = false,
    val message: String = "",
    val data: JualMobilData? = null  // Opsional
)

data class JualMobilData(
    val userEmail: String? = null,
    val modelMobil: String? = null,
    val merkMobil: String? = null,
    val tahunMobil: String? = null,
    val lokasiMobil: String? = null,
    val hargaMobil: Double? = null,
    val deskripsi: String? = null,
    val fotoMobil: String? = null,
    val statusPenjualan: String? = null
)

// JualMobilHistoryResponse.kt
data class JualMobilHistoryResponse(
    val success: Boolean,
    val data: List<JualMobilData>
)
data class TitipBeliResponse(
    val success: Boolean,
    val message: String,
    val data: TransactionData? = null
)
data class TransactionStatusUpdate(
    val orderId: String,
    val status: String
)
data class LoginRequest(
    val email: String,
    val password: String,
    val loginType: LoginType? = null
)
data class Inspektor(
    val id: String,
    val nama: String
)
data class Notification(
    val id: String,
    val userId: String,
    val type: String,
    val title: String,
    val description: String,
    val details: NotificationDetails,
    val status: String,
    val createdAt: Date,
    val updatedAt: Date
)

data class NotificationDetails(
    val orderId: String,
    val namaMobil: String,
    val merkMobil: String,
    val totalPembayaran: Double,
    val hargaMobil: Double,
    val status: String,
    val metodePembayaran: String,
    val alamat: String,
    val nomorPenjual: String
)

data class LoginRequestInspektor(
    @SerializedName("email")
    val email: String,
    @SerializedName("password")
    val password: String
)
data class LoginResponseInspektor(
    @SerializedName("token")
    val token: String,
    @SerializedName("user")
    val user: UserInspektor
)
data class UserInspektor(
    @SerializedName("_id")
    val mongoId: String? = null,

    @SerializedName("id")
    val inspektorId: String,

    @SerializedName("username")
    val username: String,

    @SerializedName("email")
    val email: String,

    @SerializedName("password")
    val password: String,

    @SerializedName("telp")
    val telp: String,

    @SerializedName("lokasi")
    val lokasi: String,

    @SerializedName("__v")
    val version: Int = 0
)

data class ErrorResponse(
    @SerializedName("message")
    val message: String? = null,
    @SerializedName("errors")
    val errors: List<String>? = null
)

data class TransaksiResult(
    val id: String,
    val status: String,
    val pesan: String
)
enum class MetodePembayaran {
    TUNAI,
    TRANSFER_BANK,
    E_WALLET
    // Tambahkan metode pembayaran lain sesuai kebutuhan
}
data class ApiResponse(
    @SerializedName("success") val success: Boolean? = null,
    @SerializedName("message") val message: String? = null,
    @SerializedName("data") val data: Any? = null
)
data class TransaksiData(
    val payment_url: String,
    val order_id: String,
    // tambahkan field lain yang diperlukan
)
data class TransaksiRequest(
    @SerializedName("nama_mobil") val namaMobil: String,
    @SerializedName("merk_mobil") val merkMobil: String,
    @SerializedName("harga_mobil") val hargaMobil: Double,
    @SerializedName("jasa") val jasa: String,
    @SerializedName("alamat") val alamat: String,
    @SerializedName("nomor_penjual") val nomorPenjual: String,
    @SerializedName("total_biaya") val totalBiaya: Double
)
@Parcelize
data class Mobil(
    @SerializedName("_id") val id: String = "",
    @SerializedName("userEmail") val userEmail: String,
    @SerializedName("modelMobil") val modelMobil: String = "",
    @SerializedName("merkMobil") val merkMobil: String = "",
    @SerializedName("tahunMobil") val tahunMobil: String = "",
    @SerializedName("lokasiMobil") val lokasiMobil: String = "",
    @SerializedName("hargaMobil") val hargaMobil: Double = 0.0,
    @SerializedName("deskripsi") val deskripsi: String = "",
    @SerializedName("fotoMobil") val fotoMobil: String = "",
    @SerializedName("statusPenjualan") val statusPenjualan: String,
    @SerializedName("createdAt") val createdAt: String? = null,
    @SerializedName("updatedAt") val updatedAt: String? = null
) : Parcelable

data class MobilResponse(
    val success: Boolean,
    val message: String? = null,  // Tambahkan properti message
    val data: List<Mobil> = emptyList()
)
enum class LoginType {
    USER,
    INSPEKTOR
}
// Model Transaksi
data class Pesananinspektor(
    val id: String,
    val username: String,
    val email: String,
    val nama_mobil: String,
    val merk_mobil: String,
    val harga_mobil: Double,
    val jasa: String,
    val harga_inspeksi: Double,
    val alamat: String,
    val status: String,
    val total_biaya: Double,
    val created_at: String
)

// Model PencarianMobil
data class PencarianMobil(
    val id: String,
    val modal: Double,
    val mobilDicek: Int,
    val jarakPencarian: String,
    val totalCost: Double,
    val baseCost: Double,
    val searchCost: Double,
    val deliveryCost: Double,
    val status: String,
    val paymentStatus: String,
    val createdAt: String
)
data class SnapRequest(
    val transaction_details: TransactionDetails,
    val customer_details: CustomerDetails
)

data class TransactionDetails(
    val mobilDicek: Int,
    val jarakPencarian: String,
    val baseCost: Double,
    val searchCost: Double,
    val deliveryCost: Double
)

data class CustomerDetails(
    val first_name: String,
    val lastName: String = "", // Midtrans might expect this even if empty
    val email: String,
    val phone: String,
    val billingAddress: Address? = null,
    val shippingAddress: Address? = null
)

// Model untuk response
data class SnapResponse(
    val token: String,
    val redirect_url: String
)
data class TitipBeliRequest(
    val orderId: String,
    val totalCost: Double,
    val modal: Double,
    val mobilDicek: Int,
    val jarakPencarian: String,
    val baseCost: Double,
    val searchCost: Double,
    val deliveryCost: Double,
    val email: String, // Tambahkan email
    val customerDetails: CustomerDetails // Perbolehkan null untuk diisi backend
)

data class TransactionData(
    val transactionId: String,
    val orderId: String,
    val midtransToken: String
)
data class InspektorResponse(
    val _id: String,
    val id: String,
    val username: String,
    val email: String,
    val telp: String,
    val lokasi: String
)
data class PesananResponse(
    val success: Boolean,
    val data: List<pesanantransaksi>,
    val pagination: Pagination
)
data class Pagination(
    val currentPage: Int,
    val totalPages: Int,
    val totalItems: Int
)
data class pesanantransaksi(
    val _id: String,
    val username: String,
    val email: String,
    val nama_mobil: String,
    val merk_mobil: String,
    val jasa: String,
    val status: String,
    val created_at: String,
    val status_history: List<StatusHistory>,
    val inspeksi_details: InspeksiDetails?
)

data class InspeksiDetails(
    val tanggal_inspeksi: String?,
    val inspektor: Inspektor?,
    val catatan_tambahan: String?
)
data class StatusUpdateRequest(
    val status: String,
    val catatan: String? = null
)

data class StatusUpdateResponse(
    val success: Boolean,
    val message: String,
    val data: JadwalInspeksi?
)

data class JadwalResponse(
    val success: Boolean,
    val message: String,
    val data: JadwalInspeksi?
)
// Model data untuk request dan response
data class PermintaanStatus(
    val status: String,
    val catatan: String? = null
)

data class ResponStatus(
    val success: Boolean,
    val message: String,
    val data: DetailTransaksi? = null
)

data class DetailTransaksi(
    val id: String,
    val status: String,
    val status_history: List<StatusHistory>,
    val inspeksi_details: DetailInspeksi?
)

data class StatusHistory(
    val status: String,
    val timestamp: String,
    val catatan: String
)

data class DetailInspeksiInspektor(
    val inspektor: DetailInspektor?
)

data class DetailInspektor(
    val nama: String,
    val email: String
)
data class Response<T>(
    val success: Boolean,
    val message: String,
    val data: T? = null,
    val error: String? = null
)
data class TransaksiInspektorResponse(
    val id: String,
    val status: String,
    val status_history: List<StatusHistory>,
    val inspeksi_details: InspeksiDetails
)
data class InspektorInfo(
    val nama: String,
    val email: String
)

// Request Body
data class UpdateStatusRequest(
    val status: String,
    val catatan: String
)
data class JadwalInspeksi(
    val id: Int = 0,
    val namaInspeksi: String,
    val tanggal: String,
    val waktu: String,
    val lokasi: String
)
data class PencarianMobilResponse(
    val success: Boolean,
    val data: List<PencarianMobil>
)
data class InspeksiResponse(
    val success: Boolean,
    val data: InspeksiData?,
    val message: String?
)
data class InspeksiData(
    val _id: String,
    val tanggal: String,
    val nomorKendaraan: String,
    val nomorVIN: String,
    val kilometer: String,
    val komponenInspeksi: KomponenInspeksi,
    val status: String,
    val createdAt: String,
    val __v: Int
)

// Data classes untuk request dan response
data class PaymentRequest(
    val orderId: String,
    val totalCost: Int,
    val email: String,
    val modal: Int,
    val mobilDicek: Int,
    val jarakPencarian: String,
    val baseCost: Int,
    val searchCost: Int,
    val deliveryCost: Int
)

data class PaymentResponse(
    val success: Boolean,
    val message: String,
    val data: PaymentData
)

data class PaymentData(
    val transactionId: String,
    val orderId: String,
    val midtransToken: String,
    val redirectUrl: String
)

data class UserProfileData(
    val email: String,
    // tambahkan field lainnya jika diperlukan
)

data class MidtransResponse(
    val success: Boolean,
    val message: String,
    val data: MidtransData
)

data class MidtransData(
    val id: String,
    val status: String,
    val total_biaya: Double,
    val payment_token: String,
    val payment_url: String
)

data class UpdateProfileRequest(
    val username: String,
    val tlp: String
)

data class UpdateProfileResponse(
    val success: Boolean,
    val message: String,
    val data: UserData? = null

)
data class PaymentStatusResponse(
    val success: Boolean,
    val status: String,
    val transactionStatus: String,
    val orderId: String
)