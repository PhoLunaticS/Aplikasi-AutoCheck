package com.example.pui2

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST

class menu_titip_beli : AppCompatActivity(), View.OnClickListener {

    private lateinit var editTextmodal: EditText
    private lateinit var spinner_jumlah_mobil: Spinner
    private lateinit var spinner_jarak_pencarian_mobil: Spinner
    private lateinit var btnClick: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu_titip_beli)

        editTextmodal = findViewById(R.id.editTextmodal)
        spinner_jumlah_mobil = findViewById(R.id.spinner_jumlah_mobil)
        spinner_jarak_pencarian_mobil = findViewById(R.id.spinner_jarak_pencarian_mobil)
        btnClick = findViewById(R.id.btn_kirim2)

        setupSpinners()
        btnClick.setOnClickListener(this)
    }

    private fun setupSpinners() {
        val adapterJumlahMobil = ArrayAdapter.createFromResource(
            this,
            R.array.jumlah_mobil,
            android.R.layout.simple_spinner_item
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        spinner_jumlah_mobil.adapter = adapterJumlahMobil

        val adapterJarakMobil = ArrayAdapter.createFromResource(
            this,
            R.array.jarak_pencarian_mobil,
            android.R.layout.simple_spinner_item
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        spinner_jarak_pencarian_mobil.adapter = adapterJarakMobil
    }

    override fun onClick(v: View?) {
        if (v?.id == R.id.btn_kirim2) {
            calculateCost_menu_titip_beli()
        }
    }

    private fun calculateCost_menu_titip_beli() {
        val modal = editTextmodal.text.toString().toDoubleOrNull()
        val mobilDicek = spinner_jumlah_mobil.selectedItem.toString().toIntOrNull()
        val jarakPencarian = spinner_jarak_pencarian_mobil.selectedItem.toString()

        if (modal == null || mobilDicek == null || jarakPencarian.isEmpty()) {
            Toast.makeText(this, "Pastikan semua input terisi dengan benar!", Toast.LENGTH_SHORT).show()
            return
        }

        val baseCost = calculateBaseCost(modal)
        val searchCost = mobilDicek * 200_000.0
        val deliveryCost = calculateDeliveryCost(jarakPencarian)
        val totalCost = baseCost + searchCost + deliveryCost

        // Panggil fungsi untuk mengarahkan ke menu transaksi
        navigateToTransaksi(modal, mobilDicek, jarakPencarian, totalCost, baseCost, searchCost, deliveryCost)
    }

    private fun calculateBaseCost(modal: Double): Double = when {
        modal < 300_000_000 -> 300_000.0
        modal in 300_000_000.0..400_000_000.0 -> 600_000.0
        modal > 500_000_000 -> 1_000_000.0
        else -> 0.0
    }

    private fun calculateDeliveryCost(jarakPencarian: String): Double = when (jarakPencarian) {
        "kurang dari 50km" -> 0.0
        "50 hingga 100km" -> 200_000.0
        else -> 0.0
    }

    private fun navigateToTransaksi(modal: Double, mobilDicek: Int, jarakPencarian: String, totalCost: Double, baseCost: Double, searchCost: Double, deliveryCost: Double) {
        // Kirim data ke menu transaksi
        val intent = Intent(this, transaksi_titipbeli::class.java).apply {
            putExtra(menu_transaksi.MENU_TYPE, transaksi_titipbeli.TYPE_TITIP_BELI)
            putExtra("HARGA_Total_Titip_Beli", totalCost)
            putExtra("modal", modal)
            putExtra("mobilDicek", mobilDicek)
            putExtra("jarakPencarian", jarakPencarian)
            putExtra("baseCost ", baseCost)
            putExtra("searchCost", searchCost)
            putExtra("deliveryCost", deliveryCost)
        }
        startActivity(intent)
    }
}