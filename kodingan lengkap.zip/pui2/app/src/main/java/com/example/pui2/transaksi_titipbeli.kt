package com.example.pui2

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import com.midtrans.sdk.corekit.core.MidtransSDK
import com.midtrans.sdk.corekit.core.themes.CustomColorTheme
import com.midtrans.sdk.corekit.models.snap.TransactionResult
import com.midtrans.sdk.uikit.SdkUIFlowBuilder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class transaksi_titipbeli : AppCompatActivity() {

    companion object {
        const val MENU_TYPE = "MENU_TYPE"
        const val TYPE_TITIP_BELI = "TITIP_BELI"
        const val TYPE_INSPEKSI = "INSPEKSI"
        const val TYPE_JUAL_MOBIL = "JUAL_MOBIL"
        private const val PAYMENT_REQUEST_CODE = 1001
        private const val TAG = "TransaksiTitipBeli"
        private const val PAYMENT_CHECK_INTERVAL = 3000L // 3 detik
        private const val MAX_PAYMENT_CHECK_ATTEMPTS = 60 // 3 menit maksimal
    }

    private lateinit var apiService: ApiService
    private lateinit var tvDetail: TextView
    private lateinit var tvTotalBiaya: TextView
    private lateinit var btnKonfirmasi: Button
    private var currentOrderId: String = ""
    private var paymentCheckAttempts = 0
    private var paymentCheckHandler: Handler? = null
    private var paymentCheckRunnable: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_transaksi_titipbeli)

        initializeViews()
        initializeApiService()
        initializeMidtrans()
        displayTransactionDetails()
        setupClickListeners()

        val token = getSharedPreferences("MyApp", Context.MODE_PRIVATE).getString("TOKEN", "")
        if (!token.isNullOrEmpty()) {
            fetchUserProfile(token) { email ->
                saveEmailToSession(email)
            }
        } else {
            showError("Token tidak ditemukan. Harap login kembali.")
        }
    }

    override fun onResume() {
        super.onResume()
        // Cek apakah ada pembayaran yang tertunda
        checkPendingPayment()
    }

    override fun onPause() {
        super.onPause()
        stopPaymentStatusCheck()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopPaymentStatusCheck()
    }

    private fun initializeViews() {
        tvDetail = findViewById(R.id.tvDetailInspeksi)
        tvTotalBiaya = findViewById(R.id.tvTotalBiaya)
        btnKonfirmasi = findViewById(R.id.btnKonfirmasiPembayaran)
    }

    private fun initializeApiService() {
        apiService = RetrofitClient.getInstance(this).getApiService()
    }

    private fun initializeMidtrans() {
        SdkUIFlowBuilder.init()
            .setClientKey("SB-Mid-client-wFzCEBq97m70Dz5k")
            .setContext(applicationContext)
            .setTransactionFinishedCallback(::handleTransactionResult)
            .setMerchantBaseUrl("https://api.sandbox.midtrans.com")
            .enableLog(true)
            .setLanguage("id")
            .setColorTheme(CustomColorTheme("#FFE51255", "#B61548", "#FFE51255"))
            .buildSDK()
    }

    private fun handleTransactionResult(result: TransactionResult) {
        Log.d(TAG, "Hasil transaksi diterima: ${result.status}")

        when (result.status) {
            TransactionResult.STATUS_SUCCESS -> {
                Log.d(TAG, "Pembayaran berhasil")
                showSuccess("Pembayaran berhasil!")
                savePaymentState(false)
                navigateToHome()
            }

            TransactionResult.STATUS_PENDING -> {
                Log.d(TAG, "Pembayaran tertunda")
                showInfo("Pembayaran sedang diproses...")
                // Mulai pengecekan status pembayaran secara berkala
                startPaymentStatusCheck()
            }

            TransactionResult.STATUS_FAILED -> {
                Log.d(TAG, "Pembayaran gagal")
                showError("Pembayaran gagal")
                savePaymentState(false)
            }

            TransactionResult.STATUS_INVALID -> {
                Log.d(TAG, "Transaksi tidak valid")
                showError("Transaksi tidak valid")
                savePaymentState(false)
            }

            else -> {
                Log.d(TAG, "Status pembayaran tidak dikenal: ${result.status}")
                // Periksa jika status mengandung kata "cancel" atau "batal"
                if (result.status.lowercase().contains("cancel") ||
                    result.status.lowercase().contains("batal")) {
                    Log.d(TAG, "Pembayaran dibatalkan")
                    showInfo("Pembayaran dibatalkan")
                    savePaymentState(false)
                } else {
                    showError("Status pembayaran tidak dikenali: ${result.status}")
                    savePaymentState(false)
                }
            }
        }
    }

    private fun setupClickListeners() {
        btnKonfirmasi.setOnClickListener {
            initiatePaymentProcess()
        }
    }

    private fun checkUserData(): Boolean {
        val sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE)
        val username = sharedPreferences.getString("username", "")
        val email = sharedPreferences.getString("email", "")
        val phone = sharedPreferences.getString("phone", "")

        if (username.isNullOrEmpty() || email.isNullOrEmpty() || phone.isNullOrEmpty()) {
            showError("Data pengguna tidak lengkap. Silakan login kembali")
            return false
        }
        return true
    }

    private fun initiatePaymentProcess() {
        if (!checkUserData()) {
            return
        }

        currentOrderId = "TITIP_BELI_${System.currentTimeMillis()}"
        val request = createTitipBeliRequest()
        Log.d(TAG, "Request yang akan dikirim: ${Gson().toJson(request)}")

        apiService.saveTransaction(request).enqueue(object : Callback<TitipBeliResponse> {
            override fun onResponse(call: Call<TitipBeliResponse>, response: Response<TitipBeliResponse>) {
                if (response.isSuccessful && response.body()?.success == true) {
                    val transactionData = response.body()?.data
                    if (transactionData != null) {
                        startMidtransPayment(transactionData.midtransToken)
                    } else {
                        showError("Data transaksi tidak valid")
                    }
                } else {
                    val errorBody = response.errorBody()?.string()
                    showError("Gagal membuat transaksi")
                    Log.e(TAG, "Error response: $errorBody")
                }
            }

            override fun onFailure(call: Call<TitipBeliResponse>, t: Throwable) {
                showError("Gagal terhubung ke server: ${t.message}")
                Log.e(TAG, "Network failure", t)
            }
        })
    }

    private fun createTitipBeliRequest(): TitipBeliRequest {
        val email: String = getEmailFromSession() ?: throw IllegalStateException("Email tidak ditemukan")
        val sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE)
        val userName = sharedPreferences.getString("username", "") ?: ""
        val userPhone = sharedPreferences.getString("phone", "") ?: ""

        val customerDetails = CustomerDetails(
            first_name = userName,
            lastName = "",
            email = email,
            phone = userPhone.let {
                if (!it.startsWith("+62") && !it.startsWith("62")) {
                    if (it.startsWith("0")) "62${it.substring(1)}"
                    else "62$it"
                } else it
            }
        )
        return TitipBeliRequest(
            email = email,
            orderId = currentOrderId,
            totalCost = intent.getDoubleExtra("HARGA_Total_Titip_Beli", 0.0),
            modal = intent.getDoubleExtra("modal", 0.0),
            mobilDicek = intent.getIntExtra("mobilDicek", 0),
            jarakPencarian = intent.getStringExtra("jarakPencarian") ?: "",
            baseCost = intent.getDoubleExtra("baseCost", 0.0),
            searchCost = intent.getDoubleExtra("searchCost", 0.0),
            deliveryCost = intent.getDoubleExtra("deliveryCost", 0.0),
            customerDetails = customerDetails
        )
    }

    private fun saveEmailToSession(email: String) {
        val sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString("email", email)
        editor.apply()
    }

    private fun getEmailFromSession(): String? {
        val sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE)
        return sharedPreferences.getString("email", null)
    }

    private fun startPaymentStatusCheck() {
        paymentCheckAttempts = 0
        paymentCheckHandler = Handler(Looper.getMainLooper())

        paymentCheckRunnable = object : Runnable {
            override fun run() {
                checkPaymentStatus()
                if (paymentCheckAttempts < MAX_PAYMENT_CHECK_ATTEMPTS) {
                    paymentCheckHandler?.postDelayed(this, PAYMENT_CHECK_INTERVAL)
                } else {
                    Log.d(TAG, "Payment check timeout")
                }
            }
        }

        paymentCheckHandler?.post(paymentCheckRunnable!!)
    }

    private fun stopPaymentStatusCheck() {
        paymentCheckRunnable?.let { runnable ->
            paymentCheckHandler?.removeCallbacks(runnable)
        }
        paymentCheckHandler = null
        paymentCheckRunnable = null
    }

    private fun checkPaymentStatus() {
        if (currentOrderId.isEmpty()) return

        paymentCheckAttempts++
        Log.d(TAG, "Checking payment status for order: $currentOrderId (attempt: $paymentCheckAttempts)")

        apiService.checkPaymentStatus(currentOrderId).enqueue(object : Callback<PaymentStatusResponse> {
            override fun onResponse(call: Call<PaymentStatusResponse>, response: Response<PaymentStatusResponse>) {
                if (response.isSuccessful) {
                    val paymentStatus = response.body()
                    Log.d(TAG, "Payment status response: ${paymentStatus?.status}")

                    when (paymentStatus?.status?.lowercase()) {
                        "success", "settlement", "capture" -> {
                            stopPaymentStatusCheck()
                            showSuccess("Pembayaran berhasil!")
                            navigateToHome()
                        }
                        "pending" -> {
                            Log.d(TAG, "Payment still pending...")
                        }
                        "failed", "deny", "cancel", "expire" -> {
                            stopPaymentStatusCheck()
                            showError("Pembayaran gagal atau dibatalkan")
                        }
                    }
                }
            }

            override fun onFailure(call: Call<PaymentStatusResponse>, t: Throwable) {
                Log.e(TAG, "Failed to check payment status", t)
            }
        })
    }

    private fun displayTransactionDetails() {
        when (intent.getStringExtra(MENU_TYPE)) {
            TYPE_TITIP_BELI -> displayTitipBeliDetails()
            TYPE_INSPEKSI -> displayInspeksiDetails()
            else -> {
                showError("Tipe transaksi tidak dikenali")
                finish()
            }
        }
    }

    private fun displayTitipBeliDetails() {
        val details = """
            Detail Transaksi Titip Beli:
            Modal Awal: Rp ${formatCurrency(intent.getDoubleExtra("modal", 0.0))}
            Jumlah Mobil Dicek: ${intent.getIntExtra("mobilDicek", 0)}
            Jarak Pencarian: ${intent.getStringExtra("jarakPencarian") ?: "Tidak diketahui"}
            
            Rincian Biaya:
            - Biaya Dasar: Rp ${formatCurrency(intent.getDoubleExtra("baseCost", 0.0))}
            - Biaya Pencarian: Rp ${formatCurrency(intent.getDoubleExtra("searchCost", 0.0))}
            - Biaya Pengiriman: Rp ${formatCurrency(intent.getDoubleExtra("deliveryCost", 0.0))}
            
            Total Biaya: Rp ${formatCurrency(intent.getDoubleExtra("HARGA_Total_Titip_Beli", 0.0))}
        """.trimIndent()

        tvDetail.text = details
        tvTotalBiaya.text = "Total Biaya: Rp ${formatCurrency(intent.getDoubleExtra("HARGA_Total_Titip_Beli", 0.0))}"
    }

    private fun displayInspeksiDetails() {
        val details = """
            Detail Inspeksi Mobil:
            Nama Mobil: ${intent.getStringExtra("NAMA_MOBIL") ?: "Tidak diketahui"}
            Merk Mobil: ${intent.getStringExtra("MERK_MOBIL") ?: "Tidak diketahui"}
            Biaya Inspeksi: Rp ${formatCurrency(intent.getDoubleExtra("HARGA_INSPEKSI", 0.0))}
            Nomor Penjual: ${intent.getStringExtra("NOMOR_PENJUAL") ?: "Tidak diketahui"}
            Lokasi Inspeksi: ${intent.getStringExtra("LOKASI_INSPEKSI") ?: "Tidak diketahui"}
            Total Biaya: Rp ${formatCurrency(intent.getDoubleExtra("TOTAL_BIAYA", 0.0))}
        """.trimIndent()

        tvDetail.text = details
        tvTotalBiaya.text = "Total Biaya: Rp ${formatCurrency(intent.getDoubleExtra("TOTAL_BIAYA", 0.0))}"
    }

    private fun formatCurrency(amount: Double): String {
        return String.format("%,.2f", amount)
    }

    private fun startMidtransPayment(token: String) {
        try {
            Log.d(TAG, "Memulai proses pembayaran")
            if (token.isBlank()) {
                showError("Token pembayaran tidak valid")
                return
            }

            // Simpan status bahwa pembayaran sedang berlangsung
            savePaymentState(true)

            // Buka WebView internal atau browser untuk pembayaran
            val intent = Intent(this, pembayaran_titip_beli::class.java).apply {
                putExtra("PAYMENT_TOKEN", token)
                putExtra("ORDER_ID", currentOrderId)
            }
            startActivityForResult(intent, PAYMENT_REQUEST_CODE)

        } catch (e: Exception) {
            Log.e(TAG, "Error fatal saat memulai pembayaran", e)
            showError("Terjadi kesalahan: ${e.message}")
        }
    }

    private fun navigateToHome() {
        val intent = Intent(this, Menu_beranda::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        startActivity(intent)
        finish()
    }

    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun showSuccess(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun showInfo(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun fetchUserProfile(token: String, callback: (String) -> Unit) {
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val response = apiService.getProfile("Bearer $token")

                if (response.isSuccessful) {
                    val email = response.body()?.data?.email
                    if (email != null) {
                        callback(email)
                    } else {
                        showError("Email tidak ditemukan dalam profil pengguna")
                    }
                } else {
                    showError("Gagal memuat profil pengguna")
                }
            } catch (e: Exception) {
                showError("Gagal memuat profil pengguna: ${e.message}")
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == PAYMENT_REQUEST_CODE) {
            val paymentStatus = data?.getStringExtra("PAYMENT_STATUS") ?: "unknown"
            val orderId = data?.getStringExtra("ORDER_ID") ?: ""

            Log.d(TAG, "Payment result received: $paymentStatus for order: $orderId")

            when (paymentStatus) {
                "success", "settlement" -> {
                    showSuccess("Pembayaran berhasil!")
                    savePaymentState(false)
                    navigateToHome()
                }
                "pending" -> {
                    showInfo("Pembayaran sedang diproses...")
                    startPaymentStatusCheck()
                }
                "failed", "cancel" -> {
                    showError("Pembayaran gagal atau dibatalkan")
                    savePaymentState(false)
                }
                else -> {
                    // Jika tidak ada status yang jelas, mulai pengecekan otomatis
                    startPaymentStatusCheck()
                }
            }
        }
    }

    private fun savePaymentState(isInProgress: Boolean) {
        val sharedPreferences = getSharedPreferences("PaymentState", MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putBoolean("payment_in_progress", isInProgress)
        editor.putString("current_order_id", if (isInProgress) currentOrderId else "")
        editor.apply()
    }

    private fun checkPendingPayment() {
        val sharedPreferences = getSharedPreferences("PaymentState", MODE_PRIVATE)
        val paymentInProgress = sharedPreferences.getBoolean("payment_in_progress", false)
        val savedOrderId = sharedPreferences.getString("current_order_id", "")

        if (paymentInProgress && !savedOrderId.isNullOrEmpty()) {
            currentOrderId = savedOrderId
            Log.d(TAG, "Resuming payment check for order: $currentOrderId")
            startPaymentStatusCheck()
        }
    }
}