package com.example.pui2

data class histori_inspektor(
    val tanggalInspeksi: String,
    val nomorKendaraan: String,
    val hasilInspeksi: String
)