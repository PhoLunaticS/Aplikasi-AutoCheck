package com.example.pui2

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class menu_role : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_menu_role)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val btnPengguna: Button = findViewById(R.id.btn_pengguna)
        btnPengguna.setOnClickListener(this)
        val btnInspektor: Button = findViewById(R.id.btn_inspektor)
        btnInspektor.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        if (v != null){
            when(v.id){
                R.id.btn_pengguna -> {
                    val pindahIntent = Intent(this, Menu_login::class.java)
                    startActivity(pindahIntent)
                }
                R.id.btn_inspektor -> {
                    val pindahIntent2 = Intent(this, menu_login_inspektor::class.java)
                    startActivity(pindahIntent2)
                }
            }
        }
    }
    }




