package com.example.pui2

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Response

class menu_transaksi : AppCompatActivity() {
    companion object {
        const val MENU_TYPE = "MENU_TYPE"
        const val TYPE_TITIP_BELI = "TITIP_BELI"
        const val TYPE_INSPEKSI = "INSPEKSI"
        const val TYPE_JUAL_MOBIL = "JUAL_MOBIL"

        const val EXTRA_HARGA_TOTAL_TITIP_BELI = "HARGA_Total_Titip_Beli"
    }

    private lateinit var tvDetail: TextView
    private lateinit var tvTotalBiaya: TextView
    private lateinit var btnKonfirmasi: Button
    private lateinit var apiService: ApiService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu_transaksi)

        // Inisialisasi komponen UI
        tvDetail = findViewById(R.id.tvDetailInspeksi)
        tvTotalBiaya = findViewById(R.id.tvTotalBiaya)
        btnKonfirmasi = findViewById(R.id.btnKonfirmasiPembayaran)

        // Buat instance ApiService
        apiService = RetrofitClient.getInstance(this).getApiService()

        // Tampilkan detail transaksi
        displayTransactionDetails()
        handleNavigationFromIntent()
        // Setup tombol konfirmasi
        btnKonfirmasi.setOnClickListener {
            if (validateTransactionData()) {
                saveTransaction()
            } else {
                Toast.makeText(this, "Data transaksi tidak valid", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun displayTransactionDetails() {
        // Ambil data dari intent

        val namaMobil = intent.getStringExtra("NAMA_MOBIL") ?: "Tidak diketahui"
        val merkMobil = intent.getStringExtra("MERK_MOBIL") ?: "Tidak diketahui"
        val hargaInspeksi = intent.getDoubleExtra("HARGA_INSPEKSI", 0.0)
        val nomorPenjual = intent.getStringExtra("NOMOR_PENJUAL") ?: "Tidak diketahui"
        val lokasiInspeksi = intent.getStringExtra("LOKASI_INSPEKSI") ?: "Tidak diketahui"
        val totalBiaya = intent.getDoubleExtra("TOTAL_BIAYA", 0.0)
        Log.d("MenuTransaksi", "Total Biaya diterima: $totalBiaya")

        // Tampilkan total biaya
        tvTotalBiaya.text = "Total Harga: Rp ${String.format("%,.2f", totalBiaya)}"

        val jasa = intent.getStringExtra("JASA") ?: "Tidak diketahui"

        // Tampilkan detail
        val details = """
            Detail Inspeksi Mobil:
            Nama Mobil: $namaMobil
            Merk Mobil: $merkMobil
            Biaya Inspeksi: Rp ${String.format("%,.2f", hargaInspeksi)}
            Nomor Penjual: $nomorPenjual
            Lokasi Inspeksi: $lokasiInspeksi
            Jasa: $jasa
            Total Biaya: Rp ${String.format("%,.2f", totalBiaya)}
        """.trimIndent()

        tvDetail.text = details
        tvTotalBiaya.text = "Total Harga: Rp ${String.format("%,.2f", totalBiaya)}"
    }

    private fun validateTransactionData(): Boolean {
        val namaMobil = intent.getStringExtra("NAMA_MOBIL")
        val merkMobil = intent.getStringExtra("MERK_MOBIL")
        val hargaMobil = intent.getDoubleExtra("HARGA_MOBIL", 0.0)
        val jasa = intent.getStringExtra("JASA")
        val alamat = intent.getStringExtra("LOKASI_INSPEKSI ") ?: "Tidak diketahui"
        val nomorPenjual = intent.getStringExtra("NOMOR_PENJUAL")
        val totalBiaya = intent.getDoubleExtra("TOTAL_BIAYA", 0.0)

        val isValid = !namaMobil.isNullOrBlank() &&
                !merkMobil.isNullOrBlank() &&
                hargaMobil > 0 &&
                !jasa.isNullOrBlank() &&
                !alamat.isNullOrBlank() &&
                !nomorPenjual.isNullOrBlank() &&
                totalBiaya > 0

        if (!isValid) {
            // Log detail mengapa validasi gagal
            Log.e("TransaksiValidasi", "Validasi Gagal:")
            Log.e("TransaksiValidasi", "Nama Mobil: ${namaMobil ?: "KOSONG"}")
            Log.e("TransaksiValidasi", "Merk Mobil: ${merkMobil ?: "KOSONG"}")
            Log.e("TransaksiValidasi", "Harga Mobil: $hargaMobil")
            Log.e("TransaksiValidasi", "Jasa: ${jasa ?: "KOSONG"}")
            Log.e("TransaksiValidasi", "Alamat: ${alamat ?: "KOSONG"}")
            Log.e("TransaksiValidasi", "Nomor Penjual: ${nomorPenjual ?: "KOSONG"}")
            Log.e("TransaksiValidasi", "Total Biaya: $totalBiaya")
        }

        return isValid
    }

    private fun saveTransaction() {
        val sharedPreferences = getSharedPreferences("MyAppPrefs", Context.MODE_PRIVATE)
        val token = sharedPreferences.getString("user_token", null)

        if (token.isNullOrBlank()) {
            Toast.makeText(this@menu_transaksi, "Sesi habis. Silakan login ulang.", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this@menu_transaksi, Menu_login::class.java))
            finish()
            return
        }

        val transaksiRequest = TransaksiRequest(
            namaMobil = intent.getStringExtra("NAMA_MOBIL") ?: "",
            merkMobil = intent.getStringExtra("MERK_MOBIL") ?: "",
            hargaMobil = intent.getDoubleExtra("HARGA_MOBIL", 0.0),
            jasa = intent.getStringExtra("JASA") ?: "Inspeksi Mobil",
            alamat = intent.getStringExtra("LOKASI_INSPEKSI") ?: "",
            nomorPenjual = intent.getStringExtra("NOMOR_PENJUAL") ?: "",
            totalBiaya = intent.getDoubleExtra("TOTAL_BIAYA", 0.0)
        )

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val response = apiService.saveTransaction("Bearer $token", transaksiRequest)

                withContext(Dispatchers.Main) {
                    if (response.isSuccessful) {
                        val responseBody = response.body()
                        if (responseBody?.success == true) {
                            // Buka WebView untuk payment URL
                            val intent = Intent(this@menu_transaksi, pembayaran_inspeksi::class.java)
                            intent.putExtra("payment_url", responseBody.data.payment_url)
                            startActivity(intent)
                        } else {
                            Toast.makeText(
                                this@menu_transaksi,
                                responseBody?.message ?: "Gagal membuat transaksi",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    } else {
                        handleApiError(response)
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Log.e("TransaksiError", "Error: ${e.message}", e)
                    Toast.makeText(
                        this@menu_transaksi,
                        "Gagal: ${e.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    private fun handleApiError(response: Response<*>) {
        val errorBody = response.errorBody()?.string()
        val errorMessage = when (response.code()) {
            400 -> "Bad Request: Periksa data yang dikirim"
            401 -> "Unauthorized: Token tidak valid"
            403 -> "Forbidden: Anda tidak memiliki izin"
            404 -> "Not Found: Sumber tidak ditemukan"
            500 -> "Server Error: Terjadi kesalahan di server "
            else -> "Kesalahan tidak dikenal"
        }

        Log.e("ApiError", "Code: ${response.code()}, Message: $errorMessage")
        Log.e("ApiError", "Error Body: $errorBody")

        Toast.makeText(
            this,
            "$errorMessage\n${errorBody ?: ""}",
            Toast.LENGTH_LONG
        ).show()
    }
    // Update bagian navigasi di menu_transaksi.kt
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleNavigationFromIntent()
    }

    private fun handleNavigationFromIntent() {
        val navigateTo = intent.getStringExtra("navigate_to")

        when (navigateTo) {
            "notifikasi" -> {
                navigateToNotifikasi()
            }
        }
    }

    private fun navigateToNotifikasi() {
        // Navigasi ke Menu_beranda dengan parameter notifikasi
        val intent = Intent(this, FragmentNotifikasi::class.java).apply {
            putExtra("navigate_to", "notifikasi")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        startActivity(intent)

        Toast.makeText(this, "Transaksi berhasil! Mengarahkan ke notifikasi...", Toast.LENGTH_SHORT).show()
        finish()
    }
}

