package com.example.pui2

import android.app.Application
import android.content.Context
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class LoginViewModel(application: Application) : AndroidViewModel(application) {
    private val apiService: ApiService

    init {
        Log.d("LoginViewModel", "Initializing ViewModel")
        try {
            Class.forName("com.example.pui2.Transaksi")
            Log.d("LoginViewModel", "Transaksi class found")
        } catch (e: ClassNotFoundException) {
            Log.e("LoginViewModel", "Transaksi class not found", e)
        }

        // Gunakan RetrofitClient untuk mendapatkan ApiService
        apiService = RetrofitClient.getInstance(application).getApiService()
    }

    private val _loginResult = MutableLiveData<ApiResult<LoginResponse>>()
    val loginResult: LiveData<ApiResult<LoginResponse>> = _loginResult

    fun login(email: String, password: String) {
        // Log input credentials (be careful not to log in production)
        Log.d("LoginViewModel", "Login attempt started")
        Log.d("LoginViewModel", "Email: $email")
        // Never log password in production for security reasons

        viewModelScope.launch {
            _loginResult.value = ApiResult.Loading

            try {
                // Log request object creation
                val loginRequest = User_login(email, password)
                Log.d("LoginViewModel", "Login Request Object Created")
                Log.d("LoginViewModel", "Login Request Details: ${loginRequest}")

                // Log before making API call
                Log.d("LoginViewModel", "Attempting to call login API")

                val response = apiService.loginUser (loginRequest)

                // Log raw response details
                Log.d("LoginViewModel", "API Response Received")
                Log.d("LoginViewModel", "Response Successful: ${response.isSuccessful}")
                Log.d("LoginViewModel", "Response Code: ${response.code()}")

                if (response.isSuccessful) {
                    val loginResponse = response.body()

                    // Log response body
                    Log.d("LoginViewModel", "Response Body: $loginResponse")

                    if (loginResponse != null) {
                        // Log token and user info before saving
                        Log.d("LoginViewModel", "Token received: ${loginResponse.token}")
                        Log.d("LoginViewModel", "User  Info: ${loginResponse.user}")

                        saveToken(loginResponse.token)
                        saveUserInfo(loginResponse.user)

                        _loginResult.value = ApiResult.Success(loginResponse)

                        Log.d("LoginViewModel", "Login successful")
                    } else {
                        Log.e("LoginViewModel", "Login response body is null")
                        _loginResult.value = ApiResult.Error("Response body is null")
                    }
                } else {
                    // Parse and log error body
                    val errorBody = response.errorBody()?.string()
                    Log.e("LoginViewModel", "Login failed. Error body: $errorBody")
                    _loginResult.value = ApiResult.Error("Login failed: $errorBody")
                }
            } catch (e: Exception) {
                // Log any exceptions
                Log.e("LoginViewModel", "Login exception", e)
                _loginResult.value = ApiResult.Error("Error: ${e.message}")
            }
        }
    }

    private fun saveToken(token: String) {
        val sharedPreferences = getApplication<Application>().getSharedPreferences("MyAppPrefs", Context.MODE_PRIVATE)

        // Validasi token tidak kosong
        if (token.isBlank()) {
            Log.e("LoginViewModel", "Attempted to save empty token")
            return
        }

        // Log token saving process dengan lebih detail
        Log.d("LoginViewModel", "Saving token to SharedPreferences")
        Log.d("LoginViewModel", "Full Token: $token")
        Log.d("LoginViewModel", "Token Length: ${token.length}")
        Log.d("LoginViewModel", "Token First 10 chars: ${token.take(10)}...")

        // Gunakan edit().commit() untuk sinkron
        val editor = sharedPreferences.edit()
        editor.putString("user_token", token)

        // Tambahkan timestamp token untuk referensi
        editor.putLong("token_timestamp", System.currentTimeMillis())

        // Commit untuk memastikan penyimpanan
        val saveResult = editor.commit()

        Log.d("LoginViewModel", "Token save result: $saveResult")

        // Verifikasi token tersimpan
        val savedToken = sharedPreferences.getString("user_token", null)
        Log.d("LoginViewModel", "Saved token verification:")
        Log.d("LoginViewModel", "Token retrieved: $savedToken")
        Log.d("LoginViewModel", "Token retrieved length: ${savedToken?.length}")

        // Tambahan pengecekan
        if (savedToken.isNullOrBlank()) {
            Log.e("LoginViewModel", "Failed to save token to SharedPreferences")
        }
    }

    private fun saveUserInfo(user: UserData) {
        val sharedPreferences = getApplication<Application>().getSharedPreferences("MyAppPrefs", Context.MODE_PRIVATE)

        Log.d("LoginViewModel", "Saving user info")
        Log.d("LoginViewModel", "User Details: $user")

        with(sharedPreferences.edit()) {
            putString("user_id", user.id.toString())
            putString("user_email", user.email)
            putString("user_username", user.username)
            putString("user_tlp", user.tlp)
            putString("user_nama", user.nama)
            apply()
        }

        // Log saved user info for verification
        Log.d("LoginViewModel", "User info saved")
        Log.d("LoginViewModel", "Saved User ID: ${user.id}")
        Log.d("LoginViewModel", "Saved User Email: ${user.email}")
    }

    // Fungsi tambahan untuk mengecek token
    fun checkTokenStorage() {
        val sharedPreferences = getApplication<Application>().getSharedPreferences("MyAppPrefs", Context.MODE_PRIVATE)

        val token = sharedPreferences.getString("user_token", null)
        val tokenTimestamp = sharedPreferences.getLong("token_timestamp", 0)

        Log.d("LoginViewModel", "Token Check:")
        Log.d("LoginViewModel", "Token Exists: ${!token.isNullOrBlank()}")
        Log.d("LoginViewModel", "Token Length: ${token?.length}")
        Log.d("LoginViewModel", "Token Timestamp: $tokenTimestamp")

        if (token != null) {
            Log.d("LoginViewModel", "Token First 10 chars: ${token.take(10)}...")
        }
    }
}

class LoginViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(LoginViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return LoginViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}