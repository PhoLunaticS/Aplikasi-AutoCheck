package com.example.pui2

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.PUT
import retrofit2.http.Path

class menu_pesanan : AppCompatActivity() {
    private lateinit var apiService: ApiService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_menu_pesanan)

        initializeApiService()
        setupWindowInsets()
        displayPendingTransactions()
    }

    private fun initializeApiService() {
        val retrofit = Retrofit.Builder()
            .baseUrl("http://10.0.2.2:3000")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        apiService = retrofit.create(ApiService::class.java)
    }

    private fun setupWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun displayPendingTransactions() {
        lifecycleScope.launch {
            try {
                val transactions = fetchPendingTransactions()
                transactions.forEach { transaction ->
                    addTransactionToList(transaction)
                }
            } catch (e: Exception) {
                Toast.makeText(this@menu_pesanan, "Gagal memuat transaksi", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private suspend fun fetchPendingTransactions(): List<Transaction> {
        return try {
            apiService.getPendingTransactions()
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun addTransactionToList(transaction: Transaction) {
        // Implementasi UI untuk menampilkan transaksi
    }

    fun acceptTransaction(transactionId: String) {
        val status = UpdateTransactionRequest(
            status = "Pesanan sedang diproses oleh inspektor"
        )

        lifecycleScope.launch {
            try {
                apiService.updateTransactionStatus(transactionId, status)
                Toast.makeText(this@menu_pesanan, "Pesanan diterima", Toast.LENGTH_SHORT).show()
                navigateToInspection()
            } catch (e: Exception) {
                Toast.makeText(this@menu_pesanan, "Gagal menerima pesanan.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun navigateToInspection() {
        val intent = Intent(this@menu_pesanan, menu_inspeksi::class.java)
        startActivity(intent)
    }

    fun completeInspection(transactionId: String, result: String) {
        val status = UpdateTransactionRequest(
            status = "Inspeksi selesai",
            inspectionResult = result
        )

        lifecycleScope.launch {
            try {
                apiService.updateTransactionStatus(transactionId, status)
                Toast.makeText(this@menu_pesanan, "Inspeksi selesai", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this@menu_pesanan, "Gagal menyelesaikan inspeksi.", Toast.LENGTH_SHORT).show()
            }
        }
    }
    // Data classes
    data class Transaction(
        val id: String,
        val status: String,
        val inspectionResult: String? = null
        // Tambahkan field lain yang diperlukan
    )

    data class UpdateTransactionRequest(
        val status: String,
        val inspectionResult: String? = null
    )

    // Interface ApiService
    interface ApiService {
        @GET("pending-transactions")
        suspend fun getPendingTransactions(): List<Transaction>

        @PUT("transactions/{id}/status")
        suspend fun updateTransactionStatus(
            @Path("id") transactionId: String,
            @Body request: UpdateTransactionRequest
        ): Response<Void>
    }
}