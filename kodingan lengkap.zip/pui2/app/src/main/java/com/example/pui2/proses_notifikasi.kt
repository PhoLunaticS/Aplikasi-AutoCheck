package com.example.pui2

data class proses_notifikasi(
    val id: String? = null,
    val inspectionId: String,
    val status: String,
    val createdAt: String? = null,
    val updatedAt: String? = null
)
