package com.example.pui2

import android.content.Context
import android.util.Log
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class RetrofitClient private constructor(private val context: Context) {

    companion object {
        private const val BASE_URL = "http://192.168.18.41:3000/"
        @Volatile // Pastikan visibilitas di thread yang berbeda
        private var instance: RetrofitClient? = null
        private var retrofit: Retrofit? = null

        fun getInstance(context: Context): RetrofitClient {
            if (instance == null) {
                instance = RetrofitClient(context.applicationContext)
            }
            return instance!!
        }
    }

    private fun getRetrofit(): Retrofit {
        if (retrofit == null) {
            val loggingInterceptor = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BASIC
            }

            val client = OkHttpClient.Builder()
                .addInterceptor(loggingInterceptor) // Menambahkan interceptor logging
                .addInterceptor { chain ->
                    val original = chain.request()

                    // Ambil token dari SharedPreferences
                    val sharedPreferences = context.getSharedPreferences("MyApp", Context.MODE_PRIVATE)
                    val token = sharedPreferences.getString("TOKEN", null)

                    // Log token yang akan digunakan
                    Log.d("RetrofitClient", "Token retrieved: ${token?.take(10)}...")

                    // Jika token tidak ada, log dan kirim permintaan tanpa token
                    if (token.isNullOrBlank()) {
                        Log.d("RetrofitClient", "Token is null or blank, sending request without token")
                    } else {
                        // Menambahkan header Authorization dengan Bearer token
                        Log.d("RetrofitClient", "Adding Authorization header with Bearer token")
                    }

                    val request = original.newBuilder()
                        .header("Authorization", "Bearer $token") // Menggunakan token Bearer
                        .method(original.method, original.body)
                        .build()

                    chain.proceed(request)
                }
                .build()

            retrofit = Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build()
        }
        return retrofit!!
    }

    fun updateToken(newToken: String) {
        val sharedPreferences = context.getSharedPreferences("MyApp", Context.MODE_PRIVATE)
        sharedPreferences.edit().putString("TOKEN", newToken).apply()

        // Reset retrofit instance agar menggunakan token baru
        retrofit = null
    }

    fun getApiService(): ApiService = getRetrofit().create(ApiService::class.java)
}