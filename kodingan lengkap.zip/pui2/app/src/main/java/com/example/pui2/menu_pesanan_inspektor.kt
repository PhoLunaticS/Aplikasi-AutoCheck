package com.example.pui2

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class menu_pesanan_inspektor : AppCompatActivity() {
    private lateinit var recyclerViewPesanan: RecyclerView
    private lateinit var loadingProgress: ProgressBar
    private lateinit var emptyStateLayout: LinearLayout
    private lateinit var toolbar: Toolbar

    // Adapter dan list pesanan
    private lateinit var pesananAdapter: PesananAdapter
    private val pesananList = mutableListOf<Pesanan>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_menu_pesanan_inspektor)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        // Inisialisasi view
        initializeViews()

        // Setup RecyclerView
        setupRecyclerView()

        // Load Pesanan
        loadPesanan()
    }

    private fun initializeViews() {
        // Temukan view berdasarkan ID
        recyclerViewPesanan = findViewById(R.id.recyclerViewPesanan)
        loadingProgress = findViewById(R.id.loadingProgress)
        emptyStateLayout = findViewById(R.id.emptyStateLayout)
        toolbar = findViewById(R.id.toolbar)

        // Set up toolbar
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(true)
        supportActionBar?.title = "Pesanan Inspektor"
    }

    private fun setupRecyclerView() {
        pesananAdapter = PesananAdapter(pesananList) { pesanan ->
            // Aksi ketika item pesanan diklik
            bukaPesananDetail(pesanan)
        }

        recyclerViewPesanan.layoutManager = LinearLayoutManager(this)
        recyclerViewPesanan.adapter = pesananAdapter
    }

    private fun loadPesanan() {
        // Tampilkan loading
        loadingProgress.visibility = View.VISIBLE

        // Simulasi data pesanan (contoh data statis)
        val dummyPesanan = listOf(
            Pesanan(
                id = "P001",
                nomorKendaraan = "B 1234 ABC",
                jenisKendaraan = "Mobil",
                pemilik = "John Doe",
                status = "Menunggu",
                tanggal = "2023-06-15",
                lokasi = "Jakarta"
            ),
            Pesanan(
                id = "P002",
                nomorKendaraan = "B 5678 DEF",
                jenisKendaraan = "Motor",
                pemilik = "Jane Smith",
                status = "Diproses",
                tanggal = "2023-06-16",
                lokasi = "Bandung"
            )
        )

        // Simulasi delay untuk efek loading
        Handler(Looper.getMainLooper()).postDelayed({
            // Bersihkan list sebelumnya
            pesananList.clear()

            // Tambahkan data dummy
            pesananList.addAll(dummyPesanan)

            // Sembunyikan loading
            loadingProgress.visibility = View.GONE

            // Update adapter
            pesananAdapter.notifyDataSetChanged()

            // Tampilkan empty state jika tidak ada pesanan
            emptyStateLayout.visibility =
                if (pesananList.isEmpty()) View.VISIBLE
                else View.GONE
        }, 1000) // Delay 1 detik untuk simulasi loading
    }

    private fun bukaPesananDetail(pesanan: Pesanan) {
        val intent = Intent(this, DetailPesananActivity::class.java).apply {
            putExtra("PESANAN_ID", pesanan.id)
        }
        startActivity(intent)
    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_pesanan, menu)
        return true
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_refresh -> {
                // Refresh data pesanan
                loadPesanan()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}