package com.example.pui2

import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class SnapWebViewActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this).apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowContentAccess = true
                allowFileAccess = true
            }

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean {
                    val url = request?.url?.toString() ?: return false
                    return handleUrlLoading(url)
                }

                override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                    url?.let {
                        return handleUrlLoading(it)
                    }
                    return false
                }
            }
        }

        setContentView(webView)

        // Ambil URL dari intent
        val snapUrl = intent.getStringExtra("snap_url")
        snapUrl?.let {
            webView.loadUrl(it)
        } ?: run {
            // Jika URL tidak ada, tutup aktivitas
            setResult(RESULT_CANCELED)
            finish()
        }
    }

    private fun handleUrlLoading(url: String): Boolean {
        val uri = Uri.parse(url)
        return when {
            // Berhasil
            url.contains("transaction_status=success") ||
                    url.contains("/success") -> {
                setResult(RESULT_OK)
                finish()
                true
            }

            // Gagal
            url.contains("transaction_status=failed") ||
                    url.contains("/failed") ||
                    url.contains("/error") -> {
                setResult(RESULT_CANCELED)
                finish()
                true
            }

            // Pending
            url.contains("transaction_status=pending") ||
                    url.contains("/pending") -> {
                // Opsional: Tambahkan penanganan khusus untuk status pending
                setResult(RESULT_FIRST_USER)
                finish()
                true
            }

            // Biarkan WebView memuat URL lain
            else -> false
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            setResult(RESULT_CANCELED)
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        // Bersihkan WebView untuk mencegah memory leak
        webView.clearHistory()
        webView.clearCache(true)
        super.onDestroy()
    }
}