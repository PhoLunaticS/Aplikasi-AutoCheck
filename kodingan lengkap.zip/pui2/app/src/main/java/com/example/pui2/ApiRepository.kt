package com.example.pui2


//class ApiRepository(private val apiService: ApiService) {
//    suspend fun login(email: String, password: String): Result<LoginResponse> {
//        return try {
//            val response = apiService.loginUser(User_login(email, password))
//            if (response.isSuccessful) {
//                response.body()?.let { loginResponse ->
//                    Result.success(loginResponse)
//                } ?: Result.failure(Exception("Response body is null"))
//            } else {
//                val errorBody = response.errorBody()?.string()
//                Result.failure(Exception(errorBody ?: "Unknown error"))
//            }
//        } catch (e: Exception) {
//            Result.failure(e)
//        }
//    }
//}