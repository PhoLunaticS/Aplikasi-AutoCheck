package com.example.pui2

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import com.example.pui2.ApiService

class pembayaran : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var apiService: ApiService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pembayaran)

        webView = findViewById(R.id.webView)

        // Konfigurasi WebView
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                // Handle ketika pembayaran selesai
                if (url?.contains("payment-success") == true) {
                    // Pembayaran sukses
                    finish()
                } else if (url?.contains("payment-failed") == true) {
                    // Pembayaran gagal
                    finish()
                }
            }
        }

        // Ambil data dari intent
        val paymentData = PaymentRequest(
            orderId = "TITIP_BELI_${System.currentTimeMillis()}",
            totalCost = intent.getIntExtra("totalCost", 0),
            email = intent.getStringExtra("email") ?: "",
            modal = intent.getIntExtra("modal", 0),
            mobilDicek = intent.getIntExtra("mobilDicek", 0),
            jarakPencarian = intent.getStringExtra("jarakPencarian") ?: "",
            baseCost = intent.getIntExtra("baseCost", 0),
            searchCost = intent.getIntExtra("searchCost", 0),
            deliveryCost = intent.getIntExtra("deliveryCost", 0)
        )

        // Lakukan request ke backend
        createPayment(paymentData)
    }

    private fun createPayment(paymentData: PaymentRequest) {
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val response = apiService.createPayment(paymentData)
                if (response.isSuccessful && response.body() != null) {
                    val paymentResponse = response.body()!!
                    // Buka URL pembayaran di WebView
                    webView.loadUrl(paymentResponse.data.redirectUrl)
                } else {
                    // Handle error response
                    android.widget.Toast.makeText(
                        this@pembayaran,
                        "Error: ${response.errorBody()?.string()}",
                        android.widget.Toast.LENGTH_SHORT
                    ).show()
                }
            } catch (e: Exception) {
                e.printStackTrace()
                // Handle error
                android.widget.Toast.makeText(
                    this@pembayaran,
                    "Error: ${e.message}",
                    android.widget.Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
