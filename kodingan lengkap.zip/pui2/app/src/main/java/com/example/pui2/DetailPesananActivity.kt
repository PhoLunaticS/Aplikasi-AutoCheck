package com.example.pui2

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.cardview.widget.CardView
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class DetailPesananActivity : AppCompatActivity() {
    private lateinit var progressBar: ProgressBar
    private lateinit var cardInspeksi: CardView
    private lateinit var tvDetailKendaraan: TextView
    private lateinit var tableInspeksi: TableLayout
    private lateinit var retrofitClient: RetrofitClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_pesanan)

        retrofitClient = RetrofitClient.getInstance(this)
        initViews()

        val email = intent.getStringExtra("email") ?: ""
        val createdAt = intent.getStringExtra("created_at") ?: ""
        val namaMobil = intent.getStringExtra("nama_mobil") ?: ""

        fetchInspeksiDetail(email, createdAt, namaMobil)
    }

    private fun initViews() {
        progressBar = findViewById(R.id.progressBar)
        cardInspeksi = findViewById(R.id.cardInspeksi)
        tvDetailKendaraan = findViewById(R.id.tvDetailKendaraan)
        tableInspeksi = findViewById(R.id.tableInspeksi)
    }

    private fun showInspeksiData(inspeksi: InspeksiData?) {
        cardInspeksi.visibility = View.VISIBLE
        progressBar.visibility = View.GONE

        inspeksi?.let { data ->
            // Menampilkan detail kendaraan
            val detailText = """
                Detail Kendaraan:
                Tanggal: ${formatDate(data.tanggal)}
                Nomor Kendaraan: ${data.nomorKendaraan}
                Nomor VIN: ${data.nomorVIN}
                Kilometer: ${data.kilometer}
                Status: ${data.status}
                Waktu Dibuat: ${formatDate(data.createdAt)}
            """.trimIndent()

            tvDetailKendaraan.text = detailText

            // Bersihkan tabel sebelum menambahkan data baru
            tableInspeksi.removeAllViews()

            // Tambahkan header untuk hasil inspeksi
            addTableHeader()

            // Menampilkan hasil inspeksi
            with(data.komponenInspeksi) {
                addTableRow("Oli", oli)
                addTableRow("Lampu Depan", lampu_depan)
                addTableRow("Lampu Belakang", lampu_belakang)
                addTableRow("Lampu Rem", lampu_rem)
                addTableRow("Lampu Sein", lampu_sein)
                addTableRow("Klakson", klakson)
                addTableRow("Wiper", wiper)
                addTableRow("Kaca Spion", kaca_spion)
                addTableRow("Ban", ban)
                addTableRow("Filter Udara", filter_udara)
                addTableRow("Sabuk dan Selang", sabuk_dan_selang)
                addTableRow("Baterai", baterai)
                addTableRow("Suspensi", suspensi)
                addTableRow("Kemudi", kemudi)
                addTableRow("Sistem Knalpot", sistem_knalpot)
                addTableRow("Rangka dan Bodi", rangka_dan_bodi)
                addTableRow("Lainnya", lainnya)
            }
        }
    }

    private fun addTableHeader() {
        val headerRow = TableRow(this).apply {
            setBackgroundColor(Color.LTGRAY)
            layoutParams = TableRow.LayoutParams(
                TableRow.LayoutParams.MATCH_PARENT,
                TableRow.LayoutParams.WRAP_CONTENT
            )
        }

        TextView(this).apply {
            text = "Komponen"
            setTypeface(null, Typeface.BOLD)
            setPadding(16, 12, 16, 12)
            setTextColor(Color.BLACK)
            headerRow.addView(this)
        }

        TextView(this).apply {
            text = "Kondisi"
            setTypeface(null, Typeface.BOLD)
            setPadding(16, 12, 16, 12)
            setTextColor(Color.BLACK)
            headerRow.addView(this)
        }

        tableInspeksi.addView(headerRow)
    }

    private fun addTableRow(komponen: String, status: String) {
        val tableRow = TableRow(this).apply {
            layoutParams = TableRow.LayoutParams(
                TableRow.LayoutParams.MATCH_PARENT,
                TableRow.LayoutParams.WRAP_CONTENT
            )
            setBackgroundColor(Color.WHITE)
        }

        TextView(this).apply {
            text = komponen
            setPadding(16, 12, 16, 12)
            setTextColor(Color.BLACK)
            tableRow.addView(this)
        }

        TextView(this).apply {
            text = status
            setPadding(16, 12, 16, 12)
            setTextColor(when (status.toLowerCase()) {
                "baik" -> Color.parseColor("#4CAF50")  // Hijau
                "rusak" -> Color.parseColor("#F44336")  // Merah
                else -> Color.BLACK
            })
            tableRow.addView(this)
        }

        tableInspeksi.addView(tableRow)
        addDivider()
    }

    private fun addDivider() {
        View(this).apply {
            setBackgroundColor(Color.LTGRAY)
            layoutParams = TableRow.LayoutParams(
                TableRow.LayoutParams.MATCH_PARENT,
                1
            )
            tableInspeksi.addView(this)
        }
    }

    private fun fetchInspeksiDetail(email: String, createdAt: String, namaMobil: String) {
        progressBar.visibility = View.VISIBLE
        cardInspeksi.visibility = View.GONE

        lifecycleScope.launch {
            try {
                val response = retrofitClient.getApiService().getInspeksiDetail(email, createdAt, namaMobil)
                Log.d("InspeksiDetail", "Response: ${response.body()}")

                if (response.isSuccessful && response.body()?.success == true) {
                    val inspeksi = response.body()?.data
                    showInspeksiData(inspeksi)
                } else {
                    val errorMessage = response.body()?.message ?: "Data inspeksi tidak ditemukan"
                    showError(errorMessage)
                }
            } catch (e: Exception) {
                Log.e("InspeksiDetail", "Error: ${e.message}", e)
                showError("Terjadi kesalahan: ${e.message}")
            } finally {
                progressBar.visibility = View.GONE
            }
        }
    }

    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        progressBar.visibility = View.GONE
    }

    private fun formatDate(dateString: String): String {
        return try {
            val inputFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.getDefault())
            val outputFormat = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("id"))
            inputFormat.timeZone = TimeZone.getTimeZone("UTC")
            outputFormat.timeZone = TimeZone.getDefault()
            val date = inputFormat.parse(dateString)
            outputFormat.format(date!!)
        } catch (e: Exception) {
            dateString
        }
    }
}