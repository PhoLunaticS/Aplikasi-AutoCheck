package com.example.pui2

import android.content.Intent
import android.graphics.Color
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RiwayatAdapter(
    private val onItemClick: (pesanantransaksi) -> Unit
) : RecyclerView.Adapter<RiwayatAdapter.ViewHolder>() {

    private val transaksiList = mutableListOf<pesanantransaksi>()

    fun clearData() {
        transaksiList.clear()
        notifyDataSetChanged()
    }
    fun updateData(newData: List<pesanantransaksi>) {
        val startPosition = transaksiList.size
        transaksiList.addAll(newData)
        notifyItemRangeInserted(startPosition, newData.size)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_riwayat, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(transaksiList[position])  // Gunakan transaksiList
    }

    override fun getItemCount() = transaksiList.size

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvJenisLayanan: TextView = itemView.findViewById(R.id.tvJenisLayanan)
        private val tvMobilInfo: TextView = itemView.findViewById(R.id.tvMobilInfo)
        private val tvStatus: TextView = itemView.findViewById(R.id.tvStatus)
        private val tvTanggal: TextView = itemView.findViewById(R.id.tvTanggal)

        fun bind(transaksi: pesanantransaksi) {
            tvJenisLayanan.text = transaksi.jasa
            tvMobilInfo.text = "${transaksi.merk_mobil} ${transaksi.nama_mobil}"
            tvStatus.text = getStatusText(transaksi.status)
            tvTanggal.text = formatDate(transaksi.created_at)

            tvStatus.setTextColor(getStatusColor(transaksi.status))

            itemView.setOnClickListener {
                val intent = Intent(itemView.context, DetailPesananActivity::class.java).apply {
                    putExtra("email", transaksi.email)
                    putExtra("created_at", transaksi.created_at)
                    putExtra("nama_mobil", transaksi.nama_mobil)
                }
                itemView.context.startActivity(intent)
            }
        }
        }

        private fun getStatusText(status: String): String = when (status) {
            "pending" -> "Menunggu"
            "processing" -> "Sedang Diproses"
            "completed" -> "Selesai"
            "cancelled" -> "Dibatalkan"
            else -> status
        }

        private fun getStatusColor(status: String): Int = when (status) {
            "pending" -> Color.BLUE
            "processing" -> Color.GREEN
            "completed" -> Color.parseColor("#4CAF50")
            "cancelled" -> Color.RED
            else -> Color.GRAY
        }

        private fun formatDate(dateString: String): String {
            return try {
                val inputFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.getDefault())
                val outputFormat = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("id"))
                val date = inputFormat.parse(dateString)
                outputFormat.format(date!!)
            } catch (e: Exception) {
                dateString
            }
        }
    }
