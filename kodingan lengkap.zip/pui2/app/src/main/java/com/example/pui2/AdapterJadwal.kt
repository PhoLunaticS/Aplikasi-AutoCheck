package com.example.pui2

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView

class JadwalAdapter(
    var jadwalList: List<JadwalInspeksi>
) : RecyclerView.Adapter<JadwalAdapter.ViewHolder>() {

    // Tambahkan variabel untuk listener
    private var onItemClickListener: ((JadwalInspeksi) -> Unit)? = null

    // Inner class ViewHolder
    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        // Pastikan ID di layout XML sesuai
        val namaInspeksi: TextView = itemView.findViewById(R.id.namaInspeksi)
        val tanggalInspeksi: TextView = itemView.findViewById(R.id.tanggalInspeksi)
        val waktuInspeksi: TextView = itemView.findViewById(R.id.waktuInspeksi)
        val lokasiInspeksi: TextView = itemView.findViewById(R.id.lokasiInspeksi)
    }

    // Implementasi method wajib RecyclerView.Adapter
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // Inflate layout item
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_jadwal_inspektor, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = jadwalList.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val jadwal = jadwalList[position]

        // Set data ke view
        holder.namaInspeksi.text = jadwal.namaInspeksi
        holder.tanggalInspeksi.text = jadwal.tanggal
        holder.waktuInspeksi.text = jadwal.waktu
        holder.lokasiInspeksi.text = jadwal.lokasi

        // Set click listener
        holder.itemView.setOnClickListener {
            Log.d("JadwalAdapter", "Item clicked: ${jadwal.namaInspeksi}")
            onItemClickListener?.invoke(jadwal)
        }
    }

    // Fungsi untuk set listener
    fun setOnItemClickListener(listener: (JadwalInspeksi) -> Unit) {
        onItemClickListener = listener
    }

    // Metode untuk update list
    fun updateList(newList: List<JadwalInspeksi>) {
        jadwalList = newList
        notifyDataSetChanged()
    }
}