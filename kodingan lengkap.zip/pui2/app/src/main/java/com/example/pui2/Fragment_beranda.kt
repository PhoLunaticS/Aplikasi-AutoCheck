package com.example.pui2

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.cardview.widget.CardView

private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

class Fragment_beranda : Fragment() {
    private var param1: String? = null
    private var param2: String? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
        Log.d("FragmentBeranda", "onCreate called")

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        Log.d("FragmentBeranda", "onCreateView called")
        val view = inflater.inflate(R.layout.fragment_beranda, container, false)
        setupClickListeners(view)
        return view
    }

    private fun setupClickListeners(view: View) {
        Log.d("FragmentBeranda", "Setting up click listeners")

        view.findViewById<CardView>(R.id.cardView_inspeksi)?.apply {
            Log.d("FragmentBeranda", "Found cardView_inspeksi")
            setOnClickListener {
                Log.d("FragmentBeranda", "Inspeksi clicked")
                navigateTo(menu_inspeksi::class.java)
            }
        }

        view.findViewById<CardView>(R.id.cardView_jual_beli)?.apply {
            Log.d("FragmentBeranda", "Found cardView_jual_beli")
            setOnClickListener {
                Log.d("FragmentBeranda", "Jual Beli clicked")
                navigateTo(Menu_jual_beli::class.java)
            }
        }

        view.findViewById<CardView>(R.id.cardView_titip_beli)?.apply {
            Log.d("FragmentBeranda", "Found cardView_titip_beli")
            setOnClickListener {
                Log.d("FragmentBeranda", "Titip Beli clicked")
                navigateTo(menu_titip_beli::class.java)
            }
        }
    }

    private fun navigateTo(activityClass: Class<*>) {
        try {
            val intent = Intent(requireActivity(), activityClass)
            startActivity(intent)
        } catch (e: Exception) {
            Log.e("FragmentBeranda", "Error navigating to ${activityClass.simpleName}: ${e.message}")
            // Add error handling here, such as showing a Toast to the user
        }
    }

    companion object {
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            Fragment_beranda().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }

    override fun onResume() {
        super.onResume()
        Log.d("FragmentBeranda", "onResume called")

        // Handling intent if it has "goToNotification" extra
        activity?.intent?.getBooleanExtra("goToNotification", false)?.let { goToNotification ->
            if (goToNotification) {
                parentFragmentManager.beginTransaction()
                    .replace(R.id.bodi, FragmentNotifikasi.newInstance()) // Use the correct container ID here
                    .commit()
            }
        }
    }

}
