package com.example.pui2

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class menu_form_pengisian_hasil_inspeksi : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_menu_form_pengisian_hasil_inspeksi)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val editTextNamaMobil: EditText = findViewById(R.id.editTextNamaMobil)
        val editTextTahun: EditText = findViewById(R.id.editTextTahun)
        val editTextKondisiMesin: EditText = findViewById(R.id.editTextKondisiMesin)
        val editTextKondisiInterior: EditText = findViewById(R.id.editTextKondisiInterior)
        val editTextKondisiEksterior: EditText = findViewById(R.id.editTextKondisiEksterior)
        val editTextHarga: EditText = findViewById(R.id.editTextHarga)
        val buttonSubmit: Button = findViewById(R.id.buttonSubmit)

        buttonSubmit.setOnClickListener {
            val namaMobil = editTextNamaMobil.text.toString()
            val tahun = editTextTahun.text.toString()
            val kondisiMesin = editTextKondisiMesin.text.toString()
            val kondisiInterior = editTextKondisiInterior.text.toString()
            val kondisiEksterior = editTextKondisiEksterior.text.toString()
            val harga = editTextHarga.text.toString()

            if (namaMobil.isNotEmpty() && tahun.isNotEmpty() && kondisiMesin.isNotEmpty() &&
                kondisiInterior.isNotEmpty() && kondisiEksterior.isNotEmpty() && harga.isNotEmpty()
            ) {
                // Handle the form submission
                Toast.makeText(this, "Form submitted successfully!", Toast.LENGTH_LONG).show()
                // You can add code to save the data or send it to a server here
            } else {
                Toast.makeText(this, "Please fill out all fields", Toast.LENGTH_LONG).show()
            }
        }
    }
}