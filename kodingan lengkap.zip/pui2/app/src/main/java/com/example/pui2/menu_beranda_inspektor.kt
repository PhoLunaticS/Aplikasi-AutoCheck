package com.example.pui2

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.Toast

class menu_beranda_inspektor : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_menu_beranda_inspektor)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        // Memastikan tampilan edge-to-edge
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Menghubungkan CardViews dengan tampilan di layout
        val cardViewStatus = findViewById<CardView>(R.id.cardViewStatus)
        val cardViewHistori = findViewById<CardView>(R.id.cardViewHistori)

        // Listener untuk Status
        cardViewStatus.setOnClickListener {
            val intent = Intent(this, activity_jadwal_inspektor::class.java)
            startActivity(intent)
        }

        // Listener untuk Histori
        cardViewHistori.setOnClickListener {
            val intent = Intent(this, menu_histori_inspektor::class.java)
            startActivity(intent)
        }
    }
}

