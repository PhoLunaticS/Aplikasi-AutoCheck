package com.example.pui2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PesananAdapter(
    private val pesananList: List<Pesanan>,
    private val onItemClick: (Pesanan) -> Unit
) : RecyclerView.Adapter<PesananAdapter.PesananViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PesananViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_pesanan, parent, false)
        return PesananViewHolder(view)
    }

    override fun onBindViewHolder(holder: PesananViewHolder, position: Int) {
        val pesanan = pesananList[position]
        holder.bind(pesanan)
    }

    override fun getItemCount() = pesananList.size

    inner class PesananViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvNomorPesanan: TextView = itemView.findViewById(R.id.tvNomorPesanan)
        private val tvNomorKendaraan: TextView = itemView.findViewById(R.id.tvNomorKendaraan)
        private val tvStatus: TextView = itemView.findViewById(R.id.tvStatus)

        fun bind(pesanan: Pesanan) {
            tvNomorPesanan.text = "Nomor Pesanan: ${pesanan.id}"
            tvNomorKendaraan.text = "Nomor Kendaraan: ${pesanan.nomorKendaraan}"
            tvStatus.text = "Status: ${pesanan.status}"

            itemView.setOnClickListener { onItemClick(pesanan) }
        }
    }
}