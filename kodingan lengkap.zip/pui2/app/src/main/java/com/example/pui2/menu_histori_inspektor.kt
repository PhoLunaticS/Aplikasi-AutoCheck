package com.example.pui2

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class menu_histori_inspektor : AppCompatActivity() {
    private lateinit var rvHistoriInspeksi: RecyclerView
    private lateinit var adapterHistoriInspeksi: adapter_histori_inspektor
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_menu_histori_inspektor)
        rvHistoriInspeksi = findViewById(R.id.rv_histori_inspeksi)

        // Setel adapter dan RecyclerView
        adapterHistoriInspeksi = adapter_histori_inspektor(getDaftarHistoriInspeksi())
        rvHistoriInspeksi.adapter = adapterHistoriInspeksi

        // Setel layout manager untuk RecyclerView
        rvHistoriInspeksi.layoutManager = LinearLayoutManager(this)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets

        }

        }

        private fun getDaftarHistoriInspeksi(): List<histori_inspektor> {
            // Mengembalikan daftar data riwayat inspeksi (bisa diganti dengan query ke database atau API)
            return listOf(
                histori_inspektor("2022-01-01", "B 1234 ABC", "Lulus"),
                histori_inspektor("2022-01-15", "B 5678 DEF", "Tidak Lulus"),
                histori_inspektor("2022-02-01", "B 9012 GHI", "Lulus")
            )
        }
    }
