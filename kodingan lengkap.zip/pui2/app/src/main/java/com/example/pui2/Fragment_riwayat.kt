package com.example.pui2

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.Toast
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class Fragment_riwayat : Fragment() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var adapter: RiwayatAdapter
    private val viewModel: RiwayatViewModel by viewModels()

    private var currentPage = 1
    private var isLoading = false

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_riwayat, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recyclerView = view.findViewById(R.id.recyclerViewRiwayat)
        progressBar = view.findViewById(R.id.progressBar)

        setupRecyclerView()
        setupObservers()
        loadData()
    }

    override fun onResume() {
        super.onResume()
        // Refresh data setiap kali fragment muncul
        refreshData()
    }

    private fun refreshData() {
        // Reset data
        currentPage = 1
        adapter.clearData() // Tambahkan fungsi clearData di adapter
        loadData()
    }

    private fun setupRecyclerView() {
        adapter = RiwayatAdapter { transaksi ->
            showDetailPesanan(transaksi)
        }

        recyclerView.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = this@Fragment_riwayat.adapter
            addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    super.onScrolled(recyclerView, dx, dy)
                    val layoutManager = recyclerView.layoutManager as LinearLayoutManager
                    val visibleItemCount = layoutManager.childCount
                    val totalItemCount = layoutManager.itemCount
                    val firstVisibleItemPosition = layoutManager.findFirstVisibleItemPosition()

                    if (!isLoading &&
                        (visibleItemCount + firstVisibleItemPosition) >= totalItemCount &&
                        firstVisibleItemPosition >= 0
                    ) {
                        loadMoreData()
                    }
                }
            })
        }
    }

    private fun setupObservers() {
        viewModel.riwayatPesanan.observe(viewLifecycleOwner) { result ->
            when (result) {
                is Result.Success -> {
                    showLoading(false)
                    Log.d("RiwayatFragment", "Response data: ${result.data}")
                    adapter.updateData(result.data.data)
                }

                is Result.Error -> {
                    showLoading(false)
                    showError(result.error)
                }

                is Result.Loading -> showLoading(true)
            }
        }
    }

    private fun loadData() {
        viewModel.getRiwayatPesanan(currentPage)
    }

    private fun loadMoreData() {
        if (!isLoading) {
            // Tambahkan pengecekan totalPages
            if (currentPage < viewModel.totalPages) {  // Tambahkan property totalPages di ViewModel
                currentPage++
                isLoading = true
                viewModel.getRiwayatPesanan(currentPage)
            }
        }
    }

    private fun showDetailPesanan(transaksi: pesanantransaksi) {
        val intent = Intent(context, DetailPesananActivity::class.java).apply {
            putExtra("transaksi_id", transaksi._id)
        }
        startActivity(intent)
    }

    private fun showLoading(isShow: Boolean) {
        progressBar.visibility = if (isShow) View.VISIBLE else View.GONE
        isLoading = isShow
    }

    private fun showError(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

    companion object {
        @JvmStatic
        fun newInstance() = Fragment_riwayat()
    }
}