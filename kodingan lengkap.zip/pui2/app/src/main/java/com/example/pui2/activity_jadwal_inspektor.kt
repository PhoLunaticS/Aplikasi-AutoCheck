package com.example.pui2

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class activity_jadwal_inspektor : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var apiService: ApiService
    private lateinit var jadwalAdapter: JadwalAdapter

    // Inisialisasi ViewModel
    private val viewModel: JadwalInspektorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_menu_jadwal_inspektor)

        // Edge to Edge setup
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // RecyclerView setup
        recyclerView = findViewById(R.id.recyclerViewJadwal)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Inisialisasi Adapter dengan click listener
        jadwalAdapter = JadwalAdapter(emptyList())
        jadwalAdapter.setOnItemClickListener { jadwal ->
            // Contoh validasi sederhana
            if (jadwal.tanggal.isNotBlank()) {
                navigateToMenuInspeksi(jadwal)
            } else {
                Toast.makeText(this, "Jadwal tidak valid", Toast.LENGTH_SHORT).show()
            }
        }
        recyclerView.adapter = jadwalAdapter

        // Inisialisasi Retrofit
        val retrofit = Retrofit.Builder()
            .baseUrl("http://10.0.2.2:3000/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        apiService = retrofit.create(ApiService::class.java)

        // Load data
        loadTransaksiData()
        loadPencarianMobilData()

        // Observer data
        observeData()
    }

    private fun observeData() {
        // Observer untuk transaksi
        viewModel.transaksiList.observe(this) { transaksiList ->
            val jadwalList = transaksiList.map { transaksi ->
                JadwalInspeksi(
                    namaInspeksi = "Inspeksi ${transaksi.nama_mobil}",
                    tanggal = transaksi.created_at.substringBefore('T'),
                    waktu = "Status: ${transaksi.status}",
                    lokasi = transaksi.alamat
                )
            }
            updateAdapterData(jadwalList)
        }

        // Observer untuk pencarian mobil
        viewModel.pencarianMobilList.observe(this) { pencarianMobilList ->
            val additionalJadwalList = pencarianMobilList.map { pencarian ->
                JadwalInspeksi(
                    namaInspeksi = "Pencarian Mobil",
                    tanggal = pencarian.createdAt.substringBefore('T'),
                    waktu = "Status: ${pencarian.status}",
                    lokasi = "Jarak: ${pencarian.jarakPencarian}"
                )
            }
            updateAdapterData(additionalJadwalList)
        }
    }

    private fun loadTransaksiData() {
        apiService.getAllTransaksi().enqueue(object : Callback<List<Pesananinspektor>> {
            override fun onResponse(
                call: Call<List<Pesananinspektor>>,
                response: Response<List<Pesananinspektor>>
            ) {
                if (response.isSuccessful) {
                    val transaksiList = response.body() ?: emptyList()
                    viewModel.setTransaksiList(transaksiList)
                } else {
                    Toast.makeText(
                        this@activity_jadwal_inspektor,
                        "Gagal memuat data",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onFailure(call: Call<List<Pesananinspektor>>, t: Throwable) {
                Toast.makeText(
                    this@activity_jadwal_inspektor,
                    "Error: ${t.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }

    private fun loadPencarianMobilData() {
        apiService.getAllPencarianMobil().enqueue(object : Callback<List<PencarianMobil>> {
            override fun onResponse(
                call: Call<List<PencarianMobil>>,
                response: Response<List<PencarianMobil>>
            ) {
                if (response.isSuccessful) {
                    val pencarianMobilList = response.body() ?: emptyList()
                    viewModel.setPencarianMobilList(pencarianMobilList)
                } else {
                    Toast.makeText(
                        this@activity_jadwal_inspektor,
                        "Gagal memuat data pencarian",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onFailure(call: Call<List<PencarianMobil>>, t: Throwable) {
                Toast.makeText(
                    this@activity_jadwal_inspektor,
                    "Error: ${t.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }

    // Metode untuk navigasi ke Menu Inspeksi
    private fun navigateToMenuInspeksi(jadwal: JadwalInspeksi) {
        Log.d("JadwalInspektor", "Navigating with date: ${jadwal.tanggal}")
        val intent = Intent(this, activity_menu_inspeksi_inspektor::class.java).apply {
            putExtra("TANGGAL", jadwal.tanggal)
        }
        startActivity(intent)
    }

    // Metode untuk memperbarui data adapter
    private fun updateAdapterData(newList: List<JadwalInspeksi>) {
        // Gabungkan data baru dengan data yang sudah ada
        val currentList = jadwalAdapter.jadwalList.toMutableList()
        currentList.addAll(newList)

        // Update list di adapter
        jadwalAdapter.updateList(currentList)
    }
}