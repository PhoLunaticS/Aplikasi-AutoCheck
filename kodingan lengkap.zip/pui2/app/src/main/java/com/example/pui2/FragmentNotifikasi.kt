package com.example.pui2

import NotifikasiViewModel
import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class FragmentNotifikasi : Fragment() {
    private lateinit var apiService: ApiService
    private lateinit var viewModel: NotifikasiViewModel
    private lateinit var adapter: NotifikasiAdapter
    private var navigator: NotificationNavigator? = null

    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var emptyTextView: TextView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var errorLayout: LinearLayout
    private lateinit var errorMessage: TextView
    private lateinit var buttonRetry: Button

    override fun onAttach(context: Context) {
        super.onAttach(context)
        Log.d("FragmentNotifikasi", "onAttach called")
        try {
            navigator = context as? NotificationNavigator
                ?: throw RuntimeException("$context must implement NotificationNavigator")
        } catch (e: Exception) {
            Log.e("FragmentNotifikasi", "Error in onAttach", e)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d("FragmentNotifikasi", "onCreate called")
        try {
            // Dapatkan ApiService dari RetrofitClient
            apiService = RetrofitClient.getInstance(requireContext()).getApiService()

            // Ambil token dari SharedPreferences
            val token = getTokenFromSharedPreferences()

            // Gunakan ViewModelFactory dengan token
            val factory = NotifikasiViewModelFactory(
                requireActivity().application,
                apiService,
                token // Pastikan token diteruskan
            )
            viewModel = ViewModelProvider(this, factory)[NotifikasiViewModel::class.java]
        } catch (e: Exception) {
            Log.e("FragmentNotifikasi", "Error initializing API service", e)
        }
    }

    // Fungsi untuk mengambil token dari SharedPreferences
    private fun getTokenFromSharedPreferences(): String {
        val sharedPreferences = requireContext().getSharedPreferences("MyAppPreferences", Context.MODE_PRIVATE)
        return sharedPreferences.getString("access_token", "") ?: ""
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_notifikasi, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews(view)
        setupRecyclerView()
        setupSwipeRefresh()
        setupErrorHandling()
        observeData()

        // Panggil fetch notifications
        Log.d("FragmentNotifikasi", "Fetching notifications...")
        viewModel.fetchNotifications()
    }

    private fun initViews(view: View) {
        recyclerView = view.findViewById(R.id.recyclerViewNotifications)
        progressBar = view.findViewById(R.id.progressBar)
        emptyTextView = view.findViewById(R.id.emptyTextView)
        swipeRefresh = view.findViewById(R.id.swipeRefresh)
        errorLayout = view.findViewById(R.id.errorLayout)
        errorMessage = view.findViewById(R.id.errorMessage)
        buttonRetry = view.findViewById(R.id.buttonRetry)
    }

    private fun setupRecyclerView() {
        adapter = NotifikasiAdapter { notifikasi ->
            handleNotificationClick(notifikasi)
        }
        recyclerView.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = this@FragmentNotifikasi.adapter
            setHasFixedSize(true)
        }
    }

    private fun setupSwipeRefresh() {
        swipeRefresh.apply {
            setOnRefreshListener { viewModel.fetchNotifications() }
            setColorSchemeResources(R.color.kuning)
        }
    }

    private fun setupErrorHandling() {
        buttonRetry.setOnClickListener { viewModel.fetchNotifications() }
    }

    private fun observeData() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.notifications.collect { result ->
                    swipeRefresh.isRefreshing = false

                    when (result) {
                        is ApiResult.Loading -> {
                            showLoadingState()
                        }
                        is ApiResult.Success -> {
                            showSuccessState(result.data)
                        }
                        is ApiResult.Error -> {
                            showErrorState(result.message)
                        }
                    }
                }
            }
        }
    }

    private fun showLoadingState() {
        progressBar.isVisible = true
        recyclerView.isVisible = false
        errorLayout.isVisible = false
        emptyTextView.isVisible = false
    }

    private fun showSuccessState(data: List<Notifikasi>) {
        progressBar.isVisible = false
        errorLayout.isVisible = false

        if (data.isEmpty()) {
            emptyTextView.isVisible = true
            recyclerView.isVisible = false
        } else {
            emptyTextView.isVisible = false
            recyclerView.isVisible = true
            adapter.submitList(data)
        }
    }

    private fun showErrorState(message: String) {
        progressBar.isVisible = false
        recyclerView.isVisible = false
        errorLayout.isVisible = true
        errorMessage.text = message
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

    private fun handleNotificationClick(notification: Notifikasi) {
        when (notification.type) {
            "PEMBAYARAN_BERHASIL" -> {
                notification.details.orderId.let {
                    navigator?.navigateToOrderDetails(it)
                }
            }
            "PESANAN_DIPROSES" -> {
                notification.details.orderId.let {
                    navigator?.navigateToOrderTracking(it)
                }
            }
            else -> {
                Toast.makeText(context, R.string.unknown_notification_type, Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDetach() {
        super.onDetach()
        navigator = null
    }

    companion object {
        fun newInstance() = FragmentNotifikasi()
    }

    // Interface untuk navigasi
    interface NotificationNavigator {
        fun navigateToOrderDetails(orderId: String)
        fun navigateToOrderTracking(orderId: String)
    }
}