package com.example.pui2

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*
import android.graphics.drawable.Drawable
import android.util.Log
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target

class activity_detail_mobil : AppCompatActivity() {

    private lateinit var tvNamaMobil: TextView
    private lateinit var tvHargaMobil: TextView
    private lateinit var tvLokasiMobil: TextView
    private lateinit var ivMobilDetail: ImageView
    private lateinit var tvTahunMobil: TextView
    private lateinit var tvMerkMobil: TextView
    private lateinit var tvDeskripsiMobil: TextView
    private lateinit var tvStatusPenjualan: TextView
    private lateinit var tvTanggalDipost: TextView
    private lateinit var tvEmailPenjual: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_mobil)

        // Inisialisasi views
        initializeViews()

        // Ambil data dari intent
        val mobil = intent.getParcelableExtra<Mobil>("MOBIL")

        mobil?.let {
            displayMobilDetails(it)
        } ?: run {
            Toast.makeText(this, "Data mobil tidak ditemukan", Toast.LENGTH_SHORT).show()
            finish()
        }

        // Tambahkan tombol kembali di ActionBar
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    private fun initializeViews() {
        ivMobilDetail = findViewById(R.id.ivMobil)
        tvNamaMobil = findViewById(R.id.tvNamaMobil)
        tvHargaMobil = findViewById(R.id.tvHargaMobil)
        tvTahunMobil = findViewById(R.id.tvTahunMobil)
        tvMerkMobil = findViewById(R.id.tvMerkMobil)
        tvDeskripsiMobil = findViewById(R.id.tvDeskripsiMobil)
        tvLokasiMobil = findViewById(R.id.tvLokasiMobil)
        tvStatusPenjualan = findViewById(R.id.tvStatusPenjualan)
        tvTanggalDipost = findViewById(R.id.tvTanggalDipost)
        tvEmailPenjual = findViewById(R.id.tvEmailPenjual)
    }

    private fun formatTanggal(tanggalIso: String): String {
        return try {
            val inputFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.getDefault())
            val outputFormat = SimpleDateFormat("dd MMMM yyyy HH:mm", Locale("id", "ID"))
            val date = inputFormat.parse(tanggalIso)
            date?.let { outputFormat.format(it) } ?: tanggalIso
        } catch (e: Exception) {
            tanggalIso
        }
    }

    private fun displayMobilDetails(mobil: Mobil) {
        // Format harga dengan rupiah
        val formatRupiah = NumberFormat.getCurrencyInstance(Locale("id", "ID"))
        val hargaFormatted = formatRupiah.format(mobil.hargaMobil)

        // Format tanggal
        val tanggalDipost = mobil.createdAt?.let { formatTanggal(it) } ?: "Tanggal tidak tersedia"

        // Set data ke view
        tvNamaMobil.text = "${mobil.merkMobil} ${mobil.modelMobil}"
        tvHargaMobil.text = hargaFormatted
        tvTahunMobil.text = "Tahun ${mobil.tahunMobil}"
        tvMerkMobil.text = mobil.merkMobil

        // Deskripsi
        tvDeskripsiMobil.text = mobil.deskripsi.ifEmpty { "Tidak ada deskripsi" }

        // Lokasi
        tvLokasiMobil.text = mobil.lokasiMobil.ifEmpty { "Lokasi tidak tersedia" }

        // Status Penjualan
        tvStatusPenjualan.text = "Status: ${mobil.statusPenjualan}"

        // Tanggal Dipost
        tvTanggalDipost.text = "Dipost pada: $tanggalDipost"

        // Email Penjual
        tvEmailPenjual.text = "Penjual: ${mobil.userEmail}"

        // Load gambar dengan metode yang lebih robust
        loadImage(mobil.fotoMobil, ivMobilDetail)
    }

    private fun loadImage(imageUrl: String?, imageView: ImageView) {
        // Log URL asli untuk debugging
        Log.d("DetailMobil", "Original URL: $imageUrl")

        val cleanUrl = when {
            imageUrl.isNullOrEmpty() -> null
            imageUrl.startsWith("/uploads/mobil/") -> {
                // Ekstrak URL aktual
                val extractedUrl = imageUrl.replace("/uploads/mobil/", "")
                if (extractedUrl.contains("i.ibb.co")) {
                    // Pastikan hanya satu https://
                    extractedUrl.replace("https://", "").let {
                        "https://$it"
                    }
                } else {
                    null
                }
            }
            imageUrl.startsWith("https://i.ibb.co") -> imageUrl
            imageUrl.contains("i.ibb.co") -> {
                // Pastikan hanya satu https://
                imageUrl.replace("https://", "").let {
                    "https://$it"
                }
            }
            else -> null
        }

        // Log URL yang sudah diproses
        Log.d("DetailMobil", "Processed URL: $cleanUrl")

        if (cleanUrl != null) {
            Glide.with(this)
                .load(cleanUrl)
                .placeholder(R.drawable.placeholder_image)
                .error(R.drawable.error_image)
                .listener(object : RequestListener<Drawable> {
                    override fun onLoadFailed(
                        e: GlideException?,
                        model: Any?,
                        target: Target<Drawable>?,
                        isFirstResource: Boolean
                    ): Boolean {
                        // Log error terperinci
                        Log.e("DetailMobil", "Image load failed: $cleanUrl", e)
                        return false
                    }

                    override fun onResourceReady(
                        resource: Drawable?,
                        model: Any?,
                        target: Target<Drawable>?,
                        dataSource: DataSource?,
                        isFirstResource: Boolean
                    ): Boolean {
                        Log.d("DetailMobil", "Image loaded successfully")
                        return false
                    }
                })
                .into(imageView)
        } else {
            // Set placeholder jika URL tidak valid
            imageView.setImageResource(R.drawable.placeholder_image)
            Log.w("DetailMobil", "Could not process image URL: $imageUrl")
        }
    }

    // Tambahkan method untuk kembali
    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}