package com.example.pui2

import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import de.hdodenhof.circleimageview.CircleImageView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Response

class Fragment_profile : Fragment() {
    private lateinit var textViewName: TextView
    private lateinit var textViewEmail: TextView
    private lateinit var textViewPhone: TextView
    private lateinit var textViewRole: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var profileImage: CircleImageView

    // Mode Edit Components
    private lateinit var fabEditProfile: FloatingActionButton
    private lateinit var nameInputLayout: TextInputLayout
    private lateinit var phoneInputLayout: TextInputLayout
    private lateinit var editTextName: TextInputEditText
    private lateinit var editTextPhone: TextInputEditText
    private lateinit var buttonSave: Button
    private lateinit var buttonCancel: Button
    private lateinit var editButtonsLayout: LinearLayout
    private lateinit var emailViewLayout: LinearLayout
    private lateinit var phoneViewLayout: LinearLayout

    private lateinit var apiService: ApiService
    private var isEditMode = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_profile, container, false)

        // Initialize views - view mode
        textViewName = view.findViewById(R.id.textViewName)
        textViewEmail = view.findViewById(R.id.textViewEmail)
        textViewPhone = view.findViewById(R.id.textViewPhone)
        textViewRole = view.findViewById(R.id.textViewRole)
        progressBar = view.findViewById(R.id.progressBar)
        profileImage = view.findViewById(R.id.profileImage)

        // Initialize views - edit mode
        fabEditProfile = view.findViewById(R.id.fabEditProfile)
        nameInputLayout = view.findViewById(R.id.nameInputLayout)
        phoneInputLayout = view.findViewById(R.id.phoneInputLayout)
        editTextName = view.findViewById(R.id.editTextName)
        editTextPhone = view.findViewById(R.id.editTextPhone)
        buttonSave = view.findViewById(R.id.buttonSave)
        buttonCancel = view.findViewById(R.id.buttonCancel)
        editButtonsLayout = view.findViewById(R.id.editButtonsLayout)
        emailViewLayout = view.findViewById(R.id.emailViewLayout)
        phoneViewLayout = view.findViewById(R.id.phoneViewLayout)

        // Initialize API service
        apiService = RetrofitClient.getInstance(requireContext()).getApiService()

        // Set click listeners
        fabEditProfile.setOnClickListener {
            toggleEditMode(true)
        }

        buttonCancel.setOnClickListener {
            toggleEditMode(false)
        }

        buttonSave.setOnClickListener {
            saveProfileChanges()
        }

        // Load profile data immediately
        loadProfile()

        return view
    }

    private fun loadProfile() {
        progressBar.visibility = View.VISIBLE
        val sharedPref = requireActivity().getSharedPreferences("MyApp", Context.MODE_PRIVATE)
        val token = sharedPref.getString("TOKEN", "")

        if (token.isNullOrEmpty()) {
            updateUIOnError("Token not found. Please login again.")
        } else {
            // Panggil fungsi getUserProfile dalam coroutine
            viewLifecycleOwner.lifecycleScope.launch {
                getUserProfile(token)
            }
        }
    }

    private suspend fun getUserProfile(token: String) {
        try {
            // Panggil API untuk mendapatkan data profil
            val response = apiService.getProfile("Bearer $token")

            if (response.isSuccessful && response.body() != null) {
                val userProfile = response.body()!!.data
                updateUIOnSuccess(userProfile.username, userProfile.email, userProfile.tlp)
            } else {
                updateUIOnError("Failed to get profile")
            }
        } catch (e: Exception) {
            Log.e("ProfileFragment", "Error fetching profile", e)
            updateUIOnError("Network error: ${e.message}")
        }
    }

    private fun updateUIOnSuccess(name: String, email: String, phoneNumber: String?) {
        progressBar.visibility = View.GONE
        textViewName.text = name
        textViewEmail.text = email
        textViewPhone.text = phoneNumber ?: "Not Available"

        // Set data to edit fields too
        editTextName.setText(name)
        editTextPhone.setText(phoneNumber ?: "")
    }

    private fun updateUIOnError(message: String) {
        progressBar.visibility = View.GONE
        textViewName.text = "Error: $message"
        textViewEmail.text = ""
        textViewPhone.text = ""
        Toast.makeText(context, message, Toast.LENGTH_LONG).show()
    }

    private fun toggleEditMode(isEdit: Boolean) {
        isEditMode = isEdit

        // Toggle visibility based on mode
        if (isEdit) {
            // Switch to Edit mode
            textViewName.visibility = View.GONE
            nameInputLayout.visibility = View.VISIBLE
            phoneViewLayout.visibility = View.GONE
            phoneInputLayout.visibility = View.VISIBLE
            editButtonsLayout.visibility = View.VISIBLE
            fabEditProfile.visibility = View.GONE
        } else {
            // Switch to View mode
            textViewName.visibility = View.VISIBLE
            nameInputLayout.visibility = View.GONE
            phoneViewLayout.visibility = View.VISIBLE
            phoneInputLayout.visibility = View.GONE
            editButtonsLayout.visibility = View.GONE
            fabEditProfile.visibility = View.VISIBLE
        }
    }

    private fun saveProfileChanges() {
        val name = editTextName.text.toString().trim()
        val phone = editTextPhone.text.toString().trim()

        // Validate input
        if (name.isEmpty()) {
            editTextName.error = "Nama tidak boleh kosong"
            return
        }

        // Show progress
        progressBar.visibility = View.VISIBLE
        editButtonsLayout.visibility = View.GONE

        // Get token
        val sharedPref = requireActivity().getSharedPreferences("MyApp", Context.MODE_PRIVATE)
        val token = sharedPref.getString("TOKEN", "") ?: ""

        // Create update data
        val updateData = UpdateProfileRequest(name, phone)

        // Call API to update profile
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val response = apiService.updateProfile("Bearer $token", updateData)

                if (response.isSuccessful && response.body() != null) {
                    val result = response.body()!!
                    if (result.success) {
                        // Update UI with new data
                        updateUIOnSuccess(result.data?.username ?: name,
                            result.data?.email ?: textViewEmail.text.toString(),
                            result.data?.tlp ?: phone)

                        // Switch back to view mode
                        toggleEditMode(false)

                        Toast.makeText(context, "Profil berhasil diperbarui", Toast.LENGTH_SHORT).show()
                    } else {
                        showError("Gagal memperbarui profil: ${result.message}")
                    }
                } else {
                    showError("Error: ${response.code()} - ${response.message()}")
                }
            } catch (e: Exception) {
                Log.e("ProfileFragment", "Error updating profile", e)
                showError("Network error: ${e.message}")
            } finally {
                progressBar.visibility = View.GONE
                if (isEditMode) {
                    editButtonsLayout.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun showError(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_LONG).show()
    }

    companion object {
        @JvmStatic
        fun newInstance() = Fragment_profile()
    }
}

