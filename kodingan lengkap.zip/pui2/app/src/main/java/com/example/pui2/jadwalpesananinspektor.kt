package com.example.pui2

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class JadwalInspektorViewModel : ViewModel() {
    // Simpan data transaksi dan pencarian mobil
    private val _transaksiList = MutableLiveData<List<Pesananinspektor>>()
    val transaksiList: LiveData<List<Pesananinspektor>> = _transaksiList

    private val _pencarianMobilList = MutableLiveData<List<PencarianMobil>>()
    val pencarianMobilList: LiveData<List<PencarianMobil>> = _pencarianMobilList

    // Method untuk memperbarui data transaksi
    fun setTransaksiList(transaksi: List<Pesananinspektor>) {
        _transaksiList.value = transaksi
    }

    // Method untuk memperbarui data pencarian mobil
    fun setPencarianMobilList(pencarianMobil: List<PencarianMobil>) {
        _pencarianMobilList.value = pencarianMobil
    }
}