package com.example.pui2

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider

class Menu_login : AppCompatActivity(), View.OnClickListener {
    private lateinit var loginViewModel: LoginViewModel
    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu_login)

        // Inisialisasi ViewModel
        val factory = LoginViewModelFactory(application)
        loginViewModel = ViewModelProvider(this, factory)[LoginViewModel::class.java]

        // Inisialisasi EditText
        emailEditText = findViewById(R.id.editTextTextEmailAddress)
        passwordEditText = findViewById(R.id.editTextTextPassword)

        // Set OnClickListener
        findViewById<Button>(R.id.btn_Login).setOnClickListener(this)
        findViewById<TextView>(R.id.registrasi).setOnClickListener(this)

        // Observe hasil login
        observeLoginResult()
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.btn_Login -> loginUser ()
            R.id.registrasi -> {
                startActivity(Intent(this, MainActivity::class.java))
            }
        }
    }

    private fun loginUser () {
        val email = emailEditText.text.toString()
        val password = passwordEditText.text.toString()

        if (!isValidInput(email, password)) return

        loginViewModel.login(email, password)
    }

    private fun isValidInput(email: String, password: String): Boolean {
        return when {
            email.isEmpty() || password.isEmpty() -> {
                showToast("Email dan Password tidak boleh kosong")
                false
            }
            !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches() -> {
                showToast("Format email tidak valid")
                false
            }
            password.length < 6 -> {
                showToast("Password harus minimal 6 karakter")
                false
            }
            else -> true
        }
    }

    private fun observeLoginResult() {
        loginViewModel.loginResult.observe(this) { result ->
            when (result) {
                is ApiResult.Loading -> {
                    // Tampilkan loading jika diperlukan
                }
                is ApiResult.Success -> {
                    showToast("Login berhasil!")
                    saveToken(result.data.token)

                    // Simpan data user untuk Midtrans
                    val userData = result.data.user
                    saveUserDataToSession(
                        username = userData.username ?: "",
                        email = userData.email ?: "",
                        phone = userData.tlp ?: ""  // Jika null, gunakan string kosong
                    )

                    startActivity(Intent(this, Menu_beranda::class.java))
                    finish()
                }
                is ApiResult.Error -> showToast(result.message)
            }
        }
    }

    private fun saveToken(token: String) {
        getSharedPreferences("MyApp", Context.MODE_PRIVATE)
            .edit()
            .putString("TOKEN", token)
            .apply()
    }
    private fun saveUserDataToSession(username: String, email: String, phone: String) {
        val sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString("username", username)
        editor.putString("email", email)
        editor.putString("phone", phone)
        editor.apply()
    }
    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}